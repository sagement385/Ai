"""
sudden_spike_filter.py

단기 급등·거래량 폭발 제거.
Mandelbrot/Cont의 fat-tail 관점은 급등을 기회 신호가 아니라 장기 스윙 후보의 위험 신호로 사용한다.
"""
from __future__ import annotations
import pandas as pd


def latest_spike_flags(prices: pd.DataFrame, max_return_20: float = 0.35, max_return_60: float = 0.70, max_volume_ratio: float = 5.0) -> pd.DataFrame:
    df = prices.sort_values(["stock_code", "date"]).copy()
    g = df.groupby("stock_code")
    df["ret_20"] = g["close"].pct_change(20)
    df["ret_60"] = g["close"].pct_change(60)
    df["avg_vol_20"] = g["volume"].transform(lambda s: s.rolling(20, min_periods=5).mean())
    df["volume_ratio"] = df["volume"] / df["avg_vol_20"].replace(0, pd.NA)
    latest = df.groupby("stock_code").tail(1)[["stock_code", "ret_20", "ret_60", "volume_ratio"]].copy()
    latest["spike_flag"] = (latest["ret_20"].fillna(0) > max_return_20) | (latest["ret_60"].fillna(0) > max_return_60) | (latest["volume_ratio"].fillna(0) > max_volume_ratio)
    latest["spike_penalty"] = latest["spike_flag"].map(lambda x: 25 if x else 0)
    latest["spike_reason"] = ""
    latest.loc[latest["ret_20"].fillna(0) > max_return_20, "spike_reason"] += "20일 급등;"
    latest.loc[latest["ret_60"].fillna(0) > max_return_60, "spike_reason"] += "60일 급등;"
    latest.loc[latest["volume_ratio"].fillna(0) > max_volume_ratio, "spike_reason"] += "거래량 폭발;"
    return latest
