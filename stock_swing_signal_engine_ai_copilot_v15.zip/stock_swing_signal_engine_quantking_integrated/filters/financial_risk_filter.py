"""
financial_risk_filter.py

재무 위험 제거. 논문 기반 기술 시그널이 좋아도 재무적으로 버티지 못하면 장기 스윙 후보에서 제외/감점한다.
"""
from __future__ import annotations
import pandas as pd


def financial_risk_flags(financials: pd.DataFrame, max_debt_ratio: float = 300.0, min_market_cap: float = 50_000_000_000) -> pd.DataFrame:
    if financials is None or financials.empty:
        return pd.DataFrame(columns=["stock_code", "financial_risk_flag", "financial_penalty", "financial_risk_reason"])
    df = financials.copy()
    for col in ["debt_ratio", "operating_profit", "net_income", "market_cap"]:
        if col not in df.columns:
            df[col] = pd.NA
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["financial_risk_flag"] = False
    reason = []
    for _, r in df.iterrows():
        rs = []
        if pd.notna(r.get("debt_ratio")) and r["debt_ratio"] > max_debt_ratio:
            rs.append("부채비율 과다")
        if pd.notna(r.get("operating_profit")) and r["operating_profit"] < 0:
            rs.append("영업적자")
        if pd.notna(r.get("net_income")) and r["net_income"] < 0:
            rs.append("순손실")
        if pd.notna(r.get("market_cap")) and r["market_cap"] < min_market_cap:
            rs.append("시가총액 부족")
        reason.append(";".join(rs))
    df["financial_risk_reason"] = reason
    df["financial_risk_flag"] = df["financial_risk_reason"].str.len() > 0
    df["financial_penalty"] = df["financial_risk_flag"].map(lambda x: 15 if x else 0)
    return df[["stock_code", "financial_risk_flag", "financial_penalty", "financial_risk_reason"]]
