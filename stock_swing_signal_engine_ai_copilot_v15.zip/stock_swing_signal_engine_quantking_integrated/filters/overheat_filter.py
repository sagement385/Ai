"""
overheat_filter.py

고점권·과열 종목 제거. 장기 스윙 프로그램에서 과열은 추천 신호가 아니라 제외 신호다.
"""
from __future__ import annotations
import pandas as pd


def latest_overheat_flags(prices: pd.DataFrame, high_position_threshold: float = 0.85) -> pd.DataFrame:
    df = prices.sort_values(["stock_code", "date"]).copy()
    g = df.groupby("stock_code")
    df["high_120"] = g["high"].transform(lambda s: s.rolling(120, min_periods=30).max())
    df["low_120"] = g["low"].transform(lambda s: s.rolling(120, min_periods=30).min())
    df["range_pos_120"] = (df["close"] - df["low_120"]) / (df["high_120"] - df["low_120"]).replace(0, pd.NA)
    # 최근 장대양봉/윗꼬리 위험
    body = (df["close"] - df["open"]).abs()
    upper_tail = df["high"] - df[["open", "close"]].max(axis=1)
    df["upper_tail_ratio"] = upper_tail / body.replace(0, pd.NA)
    df["tail_risk_10"] = g["upper_tail_ratio"].transform(lambda s: (s > 1.5).rolling(10, min_periods=3).sum())
    latest = df.groupby("stock_code").tail(1)[["stock_code", "range_pos_120", "tail_risk_10"]].copy()
    latest["overheat_flag"] = (latest["range_pos_120"].fillna(0) > high_position_threshold) & (latest["tail_risk_10"].fillna(0) >= 2)
    latest["overheat_penalty"] = latest["overheat_flag"].map(lambda x: 20 if x else 0)
    latest["overheat_reason"] = latest["overheat_flag"].map(lambda x: "고점권 윗꼬리 반복" if x else "")
    return latest
