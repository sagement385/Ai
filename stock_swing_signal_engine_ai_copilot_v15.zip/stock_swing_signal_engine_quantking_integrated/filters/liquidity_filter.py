"""
liquidity_filter.py

유동성 부족 종목 제거.
Chordia et al.의 liquidity/order imbalance 관점상 수급 신호는 충분한 거래대금이 있어야 해석 가능하다.
"""
from __future__ import annotations
import pandas as pd


def latest_liquidity_flags(prices: pd.DataFrame, min_avg_turnover_20: float = 1_000_000_000) -> pd.DataFrame:
    df = prices.sort_values(["stock_code", "date"]).copy()
    df["avg_turnover_20"] = df.groupby("stock_code")["trading_value"].transform(lambda s: s.rolling(20, min_periods=5).mean())
    latest = df.groupby("stock_code").tail(1)[["stock_code", "avg_turnover_20"]].copy()
    latest["liquidity_ok"] = latest["avg_turnover_20"].fillna(0) >= min_avg_turnover_20
    latest["liquidity_penalty"] = latest["liquidity_ok"].map(lambda x: 0 if x else 20)
    latest["liquidity_reason"] = latest["liquidity_ok"].map(lambda x: "" if x else "20일 평균 거래대금 부족")
    return latest
