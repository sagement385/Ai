"""performance_metrics.py - 추천 후보 사후 성과 지표."""
from __future__ import annotations
import pandas as pd
import numpy as np


def max_drawdown(series: pd.Series) -> float:
    s = series.dropna()
    if s.empty: return 0.0
    cummax = s.cummax()
    dd = s / cummax - 1
    return float(dd.min())


def summarize_returns(returns: pd.Series) -> dict:
    r = returns.dropna()
    if r.empty:
        return {"count": 0, "mean_return": np.nan, "median_return": np.nan, "win_rate": np.nan}
    return {"count": int(len(r)), "mean_return": float(r.mean()), "median_return": float(r.median()), "win_rate": float((r > 0).mean())}
