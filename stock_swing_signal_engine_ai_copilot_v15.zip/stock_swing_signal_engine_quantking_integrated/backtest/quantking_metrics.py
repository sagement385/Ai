"""
quantking_metrics.py

QuantKing 실행파일 내부에서 확인된 백테스트 관점(MDD, 월별/연도별 성과표)을
파이썬 엔진에서도 재사용하기 위한 성과 지표 모듈.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def equity_curve_from_returns(returns: pd.Series, start_value: float = 1.0) -> pd.Series:
    r = pd.to_numeric(returns, errors="coerce").fillna(0.0)
    return start_value * (1.0 + r).cumprod()


def max_drawdown_pct(equity: pd.Series) -> float:
    eq = pd.to_numeric(equity, errors="coerce").dropna()
    if eq.empty:
        return np.nan
    peak = eq.cummax()
    dd = eq / peak - 1.0
    return float(dd.min() * 100.0)


def profit_factor(returns: pd.Series) -> float:
    r = pd.to_numeric(returns, errors="coerce").dropna()
    gains = r[r > 0].sum()
    losses = abs(r[r < 0].sum())
    if losses == 0:
        return np.inf if gains > 0 else np.nan
    return float(gains / losses)


def annualized_return_pct(equity: pd.Series, periods_per_year: int = 252) -> float:
    eq = pd.to_numeric(equity, errors="coerce").dropna()
    if len(eq) < 2 or eq.iloc[0] <= 0:
        return np.nan
    years = max((len(eq) - 1) / periods_per_year, 1 / periods_per_year)
    return float(((eq.iloc[-1] / eq.iloc[0]) ** (1 / years) - 1) * 100.0)


def summarize_equity_curve(equity: pd.Series, returns: pd.Series | None = None) -> dict:
    eq = pd.to_numeric(equity, errors="coerce").dropna()
    if eq.empty:
        return {
            "total_return_pct": np.nan, "cagr_pct": np.nan, "mdd_pct": np.nan,
            "win_rate_pct": np.nan, "profit_factor": np.nan, "trade_count": 0,
        }
    if returns is None:
        returns = eq.pct_change().dropna()
    r = pd.to_numeric(returns, errors="coerce").dropna()
    total = (eq.iloc[-1] / eq.iloc[0] - 1.0) * 100.0 if eq.iloc[0] else np.nan
    return {
        "total_return_pct": float(total),
        "cagr_pct": annualized_return_pct(eq),
        "mdd_pct": max_drawdown_pct(eq),
        "win_rate_pct": float((r > 0).mean() * 100.0) if not r.empty else np.nan,
        "profit_factor": profit_factor(r),
        "trade_count": int(len(r)),
    }


def monthly_return_table(equity: pd.Series, date_index: pd.Series | None = None) -> pd.DataFrame:
    eq = pd.to_numeric(equity, errors="coerce").dropna()
    if date_index is not None:
        eq = pd.Series(eq.to_numpy(), index=pd.to_datetime(date_index).iloc[-len(eq):])
    elif not isinstance(eq.index, pd.DatetimeIndex):
        raise ValueError("monthly_return_table은 DatetimeIndex 또는 date_index가 필요합니다.")
    monthly = eq.resample("ME").last().pct_change().dropna() * 100.0
    out = monthly.to_frame("return_pct")
    out["year"] = out.index.year
    out["month"] = out.index.month
    return out[["year", "month", "return_pct"]].reset_index(drop=True)


def yearly_return_table(equity: pd.Series, date_index: pd.Series | None = None) -> pd.DataFrame:
    eq = pd.to_numeric(equity, errors="coerce").dropna()
    if date_index is not None:
        eq = pd.Series(eq.to_numpy(), index=pd.to_datetime(date_index).iloc[-len(eq):])
    elif not isinstance(eq.index, pd.DatetimeIndex):
        raise ValueError("yearly_return_table은 DatetimeIndex 또는 date_index가 필요합니다.")
    yearly = eq.resample("YE").last().pct_change().dropna() * 100.0
    out = yearly.to_frame("return_pct")
    out["year"] = out.index.year
    return out[["year", "return_pct"]].reset_index(drop=True)
