"""멀티 전략 실전형 일봉 백테스트 엔진.

특징
- 신호일 종가 확정 후 다음 거래일 시가 진입으로 룩어헤드 방지.
- 전략별 자금 계좌를 분리해 20/30/40/10 비중을 그대로 테스트.
- 손절/익절은 일봉 고가/저가로 체결, 같은 날 둘 다 닿으면 보수적으로 손절 우선.
- 매수/매도 수수료, 거래세, 슬리피지 반영.
- VCP/CANSLIM/Stage2/Darvas 역사적 신호를 벡터화해 생성.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import json
import math

import numpy as np
import pandas as pd

DEFAULT_CONFIG = {
    "initial_cash": 10000000,
    "enabled_strategies": ["vcp", "canslim", "stage2", "darvas"],
    "test_years": 3,
    "start_date": "",
    "end_date": "",
    "buy_commission_rate": 0.00015,
    "sell_commission_rate": 0.00015,
    "sell_tax_rate": 0.0020,
    "slippage_rate": 0.0010,
    "max_single_stock_weight": 0.10,
    "min_trading_value": 300000000,
    "max_backtest_symbols": 500,
    "liquidity_lookback_rows": 80,
    "risk_overlay": {
        "enabled": True,
        "method_note": "기존 4전략 신호는 유지하고, 백테스트 체결/비중/청산 단계에만 시장필터·변동성 포지션사이징·트레일링스탑을 적용한다.",
        "market_exposure_multiplier": {"risk_on": 1.00, "neutral": 0.80, "risk_off": 0.50},
        "block_new_entries_in_risk_off": False,
        "allow_exception_score_in_risk_off": 88,
        "use_risk_position_sizing": True,
        "risk_per_trade_pct_of_strategy_equity": {
            "vcp": 0.018,
            "canslim": 0.018,
            "stage2": 0.016,
            "darvas": 0.015
        },
        "cooldown_after_stop_days": 10,
        "breakout_fail_exit_days": {"vcp": 0, "canslim": 0, "stage2": 0, "darvas": 0},
        "breakeven_trigger_pct": {"vcp": 0.14, "canslim": 0.16, "stage2": 0.20, "darvas": 0.14},
        "breakeven_buffer_pct": 0.003,
        "trailing_stop_enabled": True,
        "trailing_activation_pct": {"vcp": 0.18, "canslim": 0.20, "stage2": 0.25, "darvas": 0.16},
        "atr_trailing_multiple": {"vcp": 2.5, "canslim": 3.0, "stage2": 3.5, "darvas": 2.5},
        "max_total_open_positions": 20,
        "risk_off_defensive_exit": False
    },
    "signal_top_n_per_day": {
        "vcp": 5,
        "canslim": 5,
        "stage2": 8,
        "darvas": 3,
    },
    "weights": {
        "vcp": 0.20,
        "canslim": 0.30,
        "stage2": 0.40,
        "darvas": 0.10,
    },
    "max_positions": {
        "vcp": 5,
        "canslim": 5,
        "stage2": 8,
        "darvas": 3,
    },
    "strategy_exit": {
        "vcp": {"stop_pct": 0.07, "target_pct": 0.18, "max_holding_days": 45},
        "canslim": {"stop_pct": 0.08, "target_pct": 0.25, "max_holding_days": 65},
        "stage2": {"stop_pct": 0.10, "target_pct": 0.35, "max_holding_days": 130},
        "darvas": {"stop_pct": 0.08, "target_pct": 0.18, "max_holding_days": 35},
    },
}

STRATEGY_NAMES = {
    "vcp": "Minervini VCP",
    "canslim": "CANSLIM",
    "stage2": "Weinstein Stage2",
    "darvas": "Darvas Box",
}


def normalize_code(code: str | int | float) -> str:
    return str(code).strip().replace(".0", "").zfill(6)


def load_backtest_config(config_path: str | Path | None = None) -> dict[str, Any]:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if config_path is None:
        config_path = Path("configs/backtest_config.json")
    p = Path(config_path)
    if p.exists():
        user = json.loads(p.read_text(encoding="utf-8"))
        for k, v in user.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
    enabled = cfg.get("enabled_strategies") or ["vcp", "canslim", "stage2", "darvas"]
    enabled = [str(x).strip().lower() for x in enabled if str(x).strip().lower() in {"vcp", "canslim", "stage2", "darvas"}]
    if not enabled:
        enabled = ["vcp", "canslim", "stage2", "darvas"]
    cfg["enabled_strategies"] = enabled
    cfg["weights"] = {k: float(v) for k, v in cfg.get("weights", {}).items() if k in enabled}
    total = sum(cfg["weights"].values())
    if total <= 0:
        raise ValueError("선택된 전략 비중 합계가 0입니다.")
    cfg["weights"] = {k: v / total for k, v in cfg["weights"].items()}
    cfg["max_positions"] = {k: v for k, v in cfg.get("max_positions", {}).items() if k in enabled}
    cfg["signal_top_n_per_day"] = {k: v for k, v in cfg.get("signal_top_n_per_day", {}).items() if k in enabled}
    return cfg



def _prefilter_backtest_universe(prices: pd.DataFrame, cfg: dict[str, Any]) -> tuple[pd.DataFrame, dict[str, Any]]:
    """백테스트 성능과 현실성을 위해 최근 거래대금 상위 종목만 선택한다.

    전체 2700개 종목을 모두 매일 백테스트하면 시간이 오래 걸리고, 실제 매매 불가능한 저유동성 종목이
    성과를 왜곡할 수 있다. 기본값은 최근 80개 거래일 median trading_value 상위 800개다.
    """
    max_symbols = int(cfg.get("max_backtest_symbols", 0) or 0)
    if max_symbols <= 0 or prices is None or prices.empty or "stock_code" not in prices.columns:
        return prices, {"universe_filtered": False, "symbols_before": 0, "symbols_after": 0}
    df = prices.copy()
    df["stock_code"] = df["stock_code"].map(normalize_code)
    df["date"] = pd.to_datetime(df["date"])
    if "trading_value" not in df.columns:
        df["trading_value"] = pd.to_numeric(df.get("close", 0), errors="coerce") * pd.to_numeric(df.get("volume", 0), errors="coerce")
    df["trading_value"] = pd.to_numeric(df["trading_value"], errors="coerce").fillna(0)
    before = int(df["stock_code"].nunique())
    if before <= max_symbols:
        return df, {"universe_filtered": False, "symbols_before": before, "symbols_after": before}
    lookback = int(cfg.get("liquidity_lookback_rows", 80) or 80)
    liq = (
        df.sort_values(["stock_code", "date"])
        .groupby("stock_code", sort=False)
        .tail(lookback)
        .groupby("stock_code")["trading_value"]
        .median()
        .sort_values(ascending=False)
    )
    keep = set(liq.head(max_symbols).index.astype(str))
    out = df[df["stock_code"].isin(keep)].copy()
    return out, {
        "universe_filtered": True,
        "symbols_before": before,
        "symbols_after": int(out["stock_code"].nunique()),
        "filter_rule": f"최근 {lookback}개 거래일 median trading_value 상위 {max_symbols}개",
    }


def _num(s: pd.Series, default=np.nan) -> pd.Series:
    if s is None:
        return pd.Series(default)
    return pd.to_numeric(s, errors="coerce")


def _roll_mean(df: pd.DataFrame, col: str, window: int, min_periods: int) -> pd.Series:
    return df.groupby("stock_code", sort=False)[col].rolling(window, min_periods=min_periods).mean().reset_index(level=0, drop=True)


def _roll_max(df: pd.DataFrame, col: str, window: int, min_periods: int) -> pd.Series:
    return df.groupby("stock_code", sort=False)[col].rolling(window, min_periods=min_periods).max().reset_index(level=0, drop=True)


def _roll_min(df: pd.DataFrame, col: str, window: int, min_periods: int) -> pd.Series:
    return df.groupby("stock_code", sort=False)[col].rolling(window, min_periods=min_periods).min().reset_index(level=0, drop=True)


def _rolling_features(prices: pd.DataFrame) -> pd.DataFrame:
    import os as _os, time as _time
    _dbg = bool(_os.getenv("DEBUG_BACKTEST"))
    _t0 = _time.time()
    def _log(msg):
        if _dbg:
            print(f"[rolling] {msg}: {_time.time()-_t0:.2f}s", flush=True)
    df = prices.copy()
    df["stock_code"] = df["stock_code"].map(normalize_code)
    if "stock_name" not in df.columns:
        df["stock_name"] = df.get("name", df["stock_code"])
    if "market" not in df.columns:
        df["market"] = "UNKNOWN"
    df["date"] = pd.to_datetime(df["date"])
    for col in ["open", "high", "low", "close", "volume", "trading_value"]:
        if col not in df.columns:
            df[col] = 0
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["date", "open", "high", "low", "close"]).sort_values(["stock_code", "date"]).reset_index(drop=True)
    _log("prep")
    g = df.groupby("stock_code", sort=False)
    for w in [10, 20, 50, 60, 120, 150, 200, 252]:
        df[f"ma{w}"] = _roll_mean(df, "close", w, max(5, int(w * 0.5)))
    df["high_shift1"] = g["high"].shift(1)
    df["low_shift1"] = g["low"].shift(1)
    for w in [20, 60, 120, 252]:
        minp = max(5, int(w * 0.4))
        df[f"high{w}_prev"] = _roll_max(df, "high_shift1", w, minp)
        df[f"low{w}_prev"] = _roll_min(df, "low_shift1", w, minp)
        df[f"ret{w}"] = g["close"].pct_change(w)
        df[f"range{w}"] = (df[f"high{w}_prev"] - df[f"low{w}_prev"]) / df["close"].replace(0, np.nan)
    prev_close = g["close"].shift(1)
    df["tr"] = pd.concat([
        (df["high"] - df["low"]).abs(),
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)
    df["atr20"] = _roll_mean(df, "tr", 20, 10)
    df["atr60"] = _roll_mean(df, "tr", 60, 20)
    df["atr_ratio"] = df["atr20"] / df["atr60"].replace(0, np.nan)
    df["vol20"] = _roll_mean(df, "volume", 20, 10)
    df["vol50"] = _roll_mean(df, "volume", 50, 20)
    df["vol60"] = _roll_mean(df, "volume", 60, 20)
    df["ma50_slope20"] = g["ma50"].diff(20) / g["ma50"].shift(20).replace(0, np.nan)
    df["ma200_slope20"] = g["ma200"].diff(20) / g["ma200"].shift(20).replace(0, np.nan)
    _log("daily rolling done")
    for w in [60, 120, 252]:
        market_ret = df.groupby("date", sort=False)[f"ret{w}"].transform("median")
        df[f"rs{w}"] = df[f"ret{w}"] - market_ret
    # 주봉 30주선 지표: 가능하면 data/csv_import/prices_weekly.csv 캐시를 사용하고, 없으면 생성한다.
    try:
        weekly = pd.DataFrame()
        weekly_path = Path("data/csv_import/prices_weekly.csv")
        if weekly_path.exists() and weekly_path.stat().st_size > 0:
            weekly = pd.read_csv(weekly_path, dtype={"stock_code": str})
            weekly["stock_code"] = weekly["stock_code"].map(normalize_code)
            weekly["date"] = pd.to_datetime(weekly["date"])
        if weekly.empty:
            from data_sources.weekly_features import build_weekly_prices
            _log("weekly build start")
            weekly = build_weekly_prices(df)
            _log("weekly build done")
        if weekly is not None and not weekly.empty:
            keep_cols = [c for c in ["stock_code", "date", "ma_30w", "ma_30w_slope_4w", "high_26w_prev", "stage2_weekly"] if c in weekly.columns]
            keep = weekly[keep_cols].copy().rename(columns={"date": "week_date"})
            keep["stock_code"] = keep["stock_code"].map(normalize_code)
            keep["week_date"] = pd.to_datetime(keep["week_date"]).dt.normalize()
            # 현재 날짜 기준으로 이미 확정된 최근 금요일 주봉만 붙인다. merge_asof보다 훨씬 빠르고 룩어헤드도 줄인다.
            df = df.copy()
            df["week_date"] = (df["date"].dt.normalize() - pd.to_timedelta((df["date"].dt.weekday - 4) % 7, unit="D"))
            df = df.merge(keep, on=["stock_code", "week_date"], how="left")
            _log("weekly merge done")
        else:
            df["ma_30w"] = np.nan; df["ma_30w_slope_4w"] = np.nan; df["high_26w_prev"] = np.nan; df["stage2_weekly"] = False
    except Exception:
        df["ma_30w"] = np.nan
        df["ma_30w_slope_4w"] = np.nan
        df["high_26w_prev"] = np.nan
        df["stage2_weekly"] = False
    for _c in ["high_shift1", "low_shift1"]:
        if _c in df.columns:
            del df[_c]
    # 이미 stock_code/date 기준으로 정렬된 상태이며 이후 백테스트에서 필요한 경우 날짜별 그룹을 다시 만든다.
    _log("done")
    return df

def generate_historical_signals(prices: pd.DataFrame, cfg: dict[str, Any] | None = None) -> pd.DataFrame:
    import os as _os, time as _time
    _dbg = bool(_os.getenv("DEBUG_BACKTEST"))
    _t0 = _time.time()
    def _glog(msg):
        if _dbg:
            print(f"[signals] {msg}: {_time.time()-_t0:.2f}s", flush=True)
    cfg = cfg or DEFAULT_CONFIG
    enabled = set(cfg.get("enabled_strategies") or ["vcp", "canslim", "stage2", "darvas"])
    required_feature_cols = {"ma200", "high20_prev", "low20_prev", "atr20", "vol60", "rs120"}
    # 이미 feature가 계산된 대형 DataFrame은 복사하지 않는다. 복사하면 5년치 800종목에서도 메모리/시간이 크게 증가한다.
    df = prices if required_feature_cols.issubset(set(prices.columns)) else _rolling_features(prices)
    _glog("features ready")
    min_tv = float(cfg.get("min_trading_value", 0))
    liquid = df["trading_value"].fillna(0) >= min_tv

    vol_ratio = df["vol20"] / df["vol60"].replace(0, np.nan)
    near_52w = df["close"] / df["high252_prev"].replace(0, np.nan) >= 0.75
    trend_strong = (df["close"] > df["ma50"]) & (df["close"] > df["ma150"]) & (df["close"] > df["ma200"]) & (df["ma50"] > df["ma150"]) & (df["ma150"] >= df["ma200"] * 0.97)
    contraction = (df["range20"] < df["range60"] * 0.80) & (df["atr_ratio"] < 1.00) & (vol_ratio < 1.05)

    signals = []
    def add(strategy: str, mask: pd.Series, pivot_col: str, score: pd.Series, stop: pd.Series, target: pd.Series):
        sig = df.loc[mask & liquid, ["date", "stock_code", "stock_name", "market", "open", "high", "low", "close", "volume", "trading_value"]].copy()
        if sig.empty:
            return
        sig["strategy_id"] = strategy
        sig["strategy_name"] = STRATEGY_NAMES[strategy]
        sig["signal_score"] = score.loc[sig.index].clip(0, 100).round(2).values
        sig["pivot_price"] = df.loc[sig.index, pivot_col].values
        sig["stop_loss"] = stop.loc[sig.index].values
        sig["target_price"] = target.loc[sig.index].values
        signals.append(sig)

    # VCP: 종가 확정 돌파 + 수축 + 거래량 증가
    if "vcp" in enabled:
        vcp_pivot = "high20_prev"
        vcp_mask = trend_strong & near_52w & contraction & (df["close"] > df[vcp_pivot] * 1.005) & (df["volume"] > df["vol60"] * 1.30)
        vcp_score = 60 + (df["rs120"].fillna(0) * 140) + ((1 - df["range20"] / df["range60"].replace(0, np.nan)).fillna(0) * 35)
        add("vcp", vcp_mask, vcp_pivot, vcp_score, df["close"] * 0.93, df["close"] * 1.18)

    # CANSLIM: 60일 신고가성 피벗 돌파 + 리더십 + 거래량. 재무는 CSV가 있으면 스캔단에서 강화하고, 백테스트는 가격 기반으로 보수적 수행.
    if "canslim" in enabled:
        canslim_pivot = "high60_prev"
        leader = (df["rs60"] > 0) & (df["rs120"] > -0.02) & (df["ret120"] > 0)
        canslim_mask = trend_strong & leader & (df["close"] > df[canslim_pivot] * 1.005) & (df["volume"] > df["vol50"] * 1.50)
        canslim_score = 62 + df["rs120"].fillna(0) * 160 + df["ret120"].fillna(0) * 45
        add("canslim", canslim_mask, canslim_pivot, canslim_score, df["close"] * 0.92, df["close"] * 1.25)

    # Stage2: 주봉 30주선 + 120일/26주 저항 돌파.
    if "stage2" in enabled:
        stage2_pivot = "high120_prev"
        weekly_ok = (df.get("stage2_weekly", False).fillna(False).astype(bool) if "stage2_weekly" in df else False)
        stage2_trend = (df["close"] > df["ma150"]) & (df["close"] > df["ma200"]) & (df["ma200_slope20"] >= -0.001)
        stage2_mask = stage2_trend & weekly_ok & (df["close"] > df[stage2_pivot] * 1.003) & (df["volume"] > df["vol60"] * 1.15)
        stage2_score = 60 + df["rs120"].fillna(0) * 150 + (df["ma_30w_slope_4w"].fillna(0) / df["ma_30w"].replace(0, np.nan).fillna(1) * 500)
        add("stage2", stage2_mask, stage2_pivot, stage2_score, np.minimum(df["close"] * 0.90, df["ma50"].fillna(df["close"] * 0.90) * 0.98), df["close"] * 1.35)

    # Darvas: 20일 박스 상단 돌파 + 박스 폭 축소.
    if "darvas" in enabled:
        darvas_pivot = "high20_prev"
        darvas_box = (df["range20"] < df["range60"] * 0.90) & (df["range20"] < 0.35)
        darvas_mask = (df["close"] > df["ma50"]) & darvas_box & (df["close"] > df[darvas_pivot] * 1.005) & (df["volume"] > df["vol60"] * 1.25)
        darvas_score = 58 + df["rs60"].fillna(0) * 130 + ((1 - df["range20"] / df["range60"].replace(0, np.nan)).fillna(0) * 30)
        darvas_target = df["close"] + (df["high20_prev"] - df["low20_prev"]).clip(lower=0) * 2.0
        add("darvas", darvas_mask, darvas_pivot, darvas_score, df["low20_prev"] * 0.99, darvas_target)

    _glog(f"raw signal parts {len(signals)}")
    if not signals:
        return pd.DataFrame(columns=["date", "stock_code", "strategy_id", "signal_score"])
    out = pd.concat(signals, ignore_index=True)
    _glog(f"concat {len(out)}")
    out = out.dropna(subset=["pivot_price", "stop_loss", "target_price"])
    _glog(f"dropna {len(out)}")
    # 하루에 전략별 상위 N개만 매수 후보로 남긴다. groupby 반복문 대신 cumcount로 벡터화해 대형 CSV에서도 빠르게 작동한다.
    topn = cfg.get("signal_top_n_per_day", {})
    out["_date_key"] = out["date"].astype(str).str.slice(0, 10)
    out = out.sort_values(["_date_key", "strategy_id", "signal_score", "trading_value"], ascending=[True, True, False, False]).reset_index(drop=True)
    counts: dict[tuple[str, str], int] = {}
    keep_mask = []
    for dkey, sid in zip(out["_date_key"].astype(str).tolist(), out["strategy_id"].astype(str).tolist()):
        key = (dkey, sid)
        cnt = counts.get(key, 0) + 1
        counts[key] = cnt
        keep_mask.append(cnt <= int(topn.get(sid, 5)))
    out = out.loc[keep_mask].drop(columns=["_date_key"], errors="ignore")
    _glog(f"top filtered {len(out)}")
    return out.reset_index(drop=True)


@dataclass
class Position:
    strategy_id: str
    stock_code: str
    stock_name: str
    entry_date: pd.Timestamp
    entry_price: float
    shares: int
    stop_loss: float
    target_price: float
    days_held: int = 0
    highest_price: float = 0.0
    highest_close: float = 0.0
    initial_risk_per_share: float = 0.0
    meta: dict[str, Any] = field(default_factory=dict)


def _metrics(equity: pd.DataFrame, trades: pd.DataFrame, initial_cash: float) -> pd.DataFrame:
    if equity.empty:
        return pd.DataFrame()
    eq = equity.copy().sort_values("date")
    eq["portfolio_value"] = pd.to_numeric(eq["portfolio_value"], errors="coerce")
    start = float(initial_cash)
    end = float(eq["portfolio_value"].iloc[-1])
    total_ret = end / start - 1 if start else 0
    days = max(1, (pd.to_datetime(eq["date"].iloc[-1]) - pd.to_datetime(eq["date"].iloc[0])).days)
    cagr = (end / start) ** (365.25 / days) - 1 if start > 0 and end > 0 else np.nan
    daily = eq["portfolio_value"].pct_change().dropna()
    sharpe = (daily.mean() / daily.std() * np.sqrt(252)) if len(daily) > 2 and daily.std() > 0 else np.nan
    cummax = eq["portfolio_value"].cummax()
    dd = eq["portfolio_value"] / cummax - 1
    mdd = dd.min() if len(dd) else 0
    if trades is None or trades.empty:
        win_rate = profit_factor = avg_hold = np.nan
        ntrades = 0
    else:
        pnl = pd.to_numeric(trades["pnl"], errors="coerce").fillna(0)
        wins = pnl[pnl > 0]
        losses = pnl[pnl < 0]
        win_rate = len(wins) / len(pnl) if len(pnl) else np.nan
        profit_factor = wins.sum() / abs(losses.sum()) if abs(losses.sum()) > 0 else np.inf if wins.sum() > 0 else np.nan
        avg_hold = pd.to_numeric(trades["holding_days"], errors="coerce").mean()
        ntrades = len(pnl)
    return pd.DataFrame([{
        "initial_cash": start,
        "final_value": end,
        "total_return_pct": total_ret * 100,
        "cagr_pct": cagr * 100 if pd.notna(cagr) else np.nan,
        "mdd_pct": mdd * 100,
        "sharpe": sharpe,
        "trades": ntrades,
        "win_rate_pct": win_rate * 100 if pd.notna(win_rate) else np.nan,
        "profit_factor": profit_factor,
        "avg_holding_days": avg_hold,
    }])




def _as_bool(v: Any, default: bool = False) -> bool:
    if isinstance(v, bool):
        return v
    if v is None:
        return default
    return str(v).strip().lower() in {"1", "true", "yes", "y", "on"}


def _build_market_regime(px: pd.DataFrame, cfg: dict[str, Any]) -> pd.DataFrame:
    """개별 전략 신호를 바꾸지 않고, 백테스트 포지션/신규진입만 통제할 시장상태 테이블을 만든다.

    벤치마크 지수 CSV가 없어도 전체 백테스트 유니버스의 median daily return으로 equal-weight 시장 프록시를
    만들기 때문에 yfinance 가격 CSV만으로 작동한다. 이 값은 종목 선정 점수에는 쓰지 않고 risk overlay에만 쓴다.
    """
    if px is None or px.empty:
        return pd.DataFrame(columns=["date_key", "market_proxy", "market_mode", "exposure_multiplier"])
    ro = cfg.get("risk_overlay", {}) or {}
    enabled = _as_bool(ro.get("enabled", True), True)
    dates = pd.DataFrame({"date": pd.to_datetime(px["date"].dropna().unique())}).sort_values("date")
    dates["date_key"] = dates["date"].dt.strftime("%Y-%m-%d")
    if not enabled:
        dates["market_proxy"] = 1000.0
        dates["market_mode"] = "risk_on"
        dates["exposure_multiplier"] = 1.0
        return dates[["date_key", "market_proxy", "market_mode", "exposure_multiplier"]]

    tmp = px[["date", "stock_code", "close"]].copy()
    tmp["date"] = pd.to_datetime(tmp["date"])
    tmp["stock_code"] = tmp["stock_code"].map(normalize_code)
    tmp["close"] = pd.to_numeric(tmp["close"], errors="coerce")
    tmp = tmp.sort_values(["stock_code", "date"])
    tmp["daily_ret"] = tmp.groupby("stock_code", sort=False)["close"].pct_change().clip(-0.30, 0.30)
    # median을 쓰면 특정 급등/급락주 하나가 시장상태를 왜곡하는 것을 줄인다.
    m = tmp.groupby("date", sort=True)["daily_ret"].median().fillna(0).reset_index()
    m["market_proxy"] = (1 + m["daily_ret"]).cumprod() * 1000.0
    m["market_ma50"] = m["market_proxy"].rolling(50, min_periods=25).mean()
    m["market_ma200"] = m["market_proxy"].rolling(200, min_periods=100).mean()
    m["market_ret20"] = m["market_proxy"].pct_change(20)
    m["market_vol20"] = m["daily_ret"].rolling(20, min_periods=10).std() * np.sqrt(252)
    m["market_dd60"] = m["market_proxy"] / m["market_proxy"].rolling(60, min_periods=20).max() - 1

    risk_on = (m["market_proxy"] > m["market_ma200"]) & (m["market_proxy"] > m["market_ma50"]) & (m["market_ret20"] > -0.04)
    neutral = ((m["market_proxy"] > m["market_ma200"]) | (m["market_proxy"] > m["market_ma50"])) & (m["market_dd60"] > -0.12)
    m["market_mode"] = np.where(risk_on, "risk_on", np.where(neutral, "neutral", "risk_off"))
    mult_map = ro.get("market_exposure_multiplier", {}) or {}
    m["exposure_multiplier"] = m["market_mode"].map({
        "risk_on": float(mult_map.get("risk_on", 1.0)),
        "neutral": float(mult_map.get("neutral", 0.6)),
        "risk_off": float(mult_map.get("risk_off", 0.2)),
    }).fillna(1.0)
    m["date_key"] = pd.to_datetime(m["date"]).dt.strftime("%Y-%m-%d")
    return m[["date_key", "market_proxy", "market_ma50", "market_ma200", "market_ret20", "market_vol20", "market_dd60", "market_mode", "exposure_multiplier"]]


def _current_strategy_equity(sid: str, cash: dict[str, float], positions: dict[tuple[str, str], Position], price_map: dict[tuple[str, str], dict[str, float]], dkey: str) -> tuple[float, float, int]:
    pos_value = 0.0
    n = 0
    for p in positions.values():
        if p.strategy_id != sid:
            continue
        n += 1
        row = price_map.get((dkey, p.stock_code))
        pos_value += (row["close"] if row else p.entry_price) * p.shares
    equity = float(cash.get(sid, 0.0)) + pos_value
    return equity, pos_value, n


def _update_risk_overlay_stop(pos: Position, row: dict[str, float], cfg: dict[str, Any]) -> None:
    """진입 신호는 그대로 두고, 보유 중 방어 로직만 적용한다."""
    ro = cfg.get("risk_overlay", {}) or {}
    if not _as_bool(ro.get("enabled", True), True):
        return
    high = float(row.get("high", np.nan))
    close = float(row.get("close", np.nan))
    atr20 = float(row.get("atr20", np.nan))
    if np.isfinite(high):
        pos.highest_price = max(float(pos.highest_price or pos.entry_price), high)
    if np.isfinite(close):
        pos.highest_close = max(float(pos.highest_close or pos.entry_price), close)
    if pos.entry_price <= 0:
        return
    best_gain = max(pos.highest_price, pos.highest_close, pos.entry_price) / pos.entry_price - 1
    # 수익이 일정 수준 나면 손절선을 매수가+비용버퍼로 끌어올린다.
    be_map = ro.get("breakeven_trigger_pct", {}) or {}
    trigger = float(be_map.get(pos.strategy_id, 0.12))
    if best_gain >= trigger:
        buffer = float(ro.get("breakeven_buffer_pct", 0.003))
        pos.stop_loss = max(pos.stop_loss, pos.entry_price * (1 + buffer))
    # Chandelier/ATR 계열 트레일링 스탑. 활성화 전에는 기존 손절선을 건드리지 않는다.
    if _as_bool(ro.get("trailing_stop_enabled", True), True):
        act_map = ro.get("trailing_activation_pct", {}) or {}
        mult_map = ro.get("atr_trailing_multiple", {}) or {}
        activation = float(act_map.get(pos.strategy_id, 0.15))
        atr_mult = float(mult_map.get(pos.strategy_id, 3.0))
        if best_gain >= activation and np.isfinite(atr20) and atr20 > 0:
            trail = pos.highest_price - atr20 * atr_mult
            if np.isfinite(trail) and trail > 0:
                pos.stop_loss = max(pos.stop_loss, trail)

def run_multi_strategy_backtest(prices: pd.DataFrame, config_path: str | Path | None = None, output_dir: str | Path = "reports/output") -> dict[str, pd.DataFrame]:
    """4전략 포트폴리오를 실제 체결 가정으로 백테스트한다.

    방식
    - 과거 전체 가격 데이터로 지표를 계산한다.
    - 기본값은 최근 3년 구간에서만 신호를 평가한다.
    - 신호일 종가 확정 후 다음 거래일 시가에 진입한다.
    - 수수료, 거래세, 슬리피지를 반영한다.
    - 기본적으로 최근 거래대금 상위 800개만 테스트해 저유동성 왜곡과 과도한 연산을 줄인다.
    """
    cfg = load_backtest_config(config_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    prices, universe_filter_info = _prefilter_backtest_universe(prices, cfg)
    feature_prices = _rolling_features(prices)
    signals = generate_historical_signals(feature_prices, cfg)
    result = _run_with_entries(feature_prices, signals, cfg, output_dir)
    if result.get("summary") is not None and not result["summary"].empty:
        for k, v in universe_filter_info.items():
            result["summary"][k] = v
        result["summary"].to_csv(output_dir / "backtest_summary.csv", index=False, encoding="utf-8-sig")
        save_backtest_html(result["equity"], result["trades"], result["summary"], result["strategy_summary"], output_dir)
    return result

def _run_with_entries(px: pd.DataFrame, signals: pd.DataFrame, cfg: dict[str, Any], output_dir: Path) -> dict[str, pd.DataFrame]:
    import os as _os, time as _time
    _dbg = bool(_os.getenv("DEBUG_BACKTEST"))
    _t0 = _time.time()
    def _blog(msg):
        if _dbg:
            print(f"[engine] {msg}: {_time.time()-_t0:.2f}s", flush=True)
    initial_cash = float(cfg.get("initial_cash", 10000000))
    weights = cfg.get("weights", DEFAULT_CONFIG["weights"])
    max_positions = cfg.get("max_positions", DEFAULT_CONFIG["max_positions"])
    cash = {sid: initial_cash * float(weights.get(sid, 0)) for sid in weights}
    positions: dict[tuple[str, str], Position] = {}
    trades = []
    equity_rows = []
    buy_fee = float(cfg.get("buy_commission_rate", 0.00015))
    sell_fee = float(cfg.get("sell_commission_rate", 0.00015))
    tax = float(cfg.get("sell_tax_rate", 0.002))
    slip = float(cfg.get("slippage_rate", 0.001))
    ro = cfg.get("risk_overlay", {}) or {}
    risk_overlay_enabled = _as_bool(ro.get("enabled", True), True)
    cooldown_after_stop_days = int(ro.get("cooldown_after_stop_days", 0) or 0)
    stop_cooldown: dict[tuple[str, str], pd.Timestamp] = {}

    _blog("start")
    # feature 생성 단계에서 이미 stock_code/date 정렬 및 정규화가 끝나 있으므로 대형 DF 복사를 피한다.
    px = px
    if not pd.api.types.is_datetime64_any_dtype(px["date"]):
        px["date"] = pd.to_datetime(px["date"])
    _blog("px ready")
    market_regime = _build_market_regime(px, cfg)
    market_regime.to_csv(output_dir / "backtest_market_regime.csv", index=False, encoding="utf-8-sig")
    market_by_date = market_regime.set_index("date_key").to_dict("index") if not market_regime.empty else {}
    codes_arr = px["stock_code"].astype(str).to_numpy()
    open_arr = pd.to_numeric(px["open"], errors="coerce").to_numpy(float)
    date_arr = pd.to_datetime(px["date"]).to_numpy()
    next_open_arr = np.full(len(px), np.nan, dtype=float)
    next_date_arr = np.empty(len(px), dtype="datetime64[ns]")
    next_date_arr[:] = np.datetime64("NaT")
    same_next = codes_arr[:-1] == codes_arr[1:]
    next_open_arr[:-1][same_next] = open_arr[1:][same_next]
    next_date_arr[:-1][same_next] = date_arr[1:][same_next]
    px["next_open"] = next_open_arr
    px["next_date"] = pd.to_datetime(next_date_arr)
    _blog("next fields")

    # 평가구간: 기본값 최근 3년. 이전 데이터는 지표 계산 warm-up에만 사용한다.
    if len(px):
        max_date = pd.Timestamp(date_arr[-1])
        if str(cfg.get("start_date", "")).strip():
            start_dt = pd.Timestamp(str(cfg.get("start_date")).strip())
        else:
            start_dt = max_date - pd.DateOffset(years=int(float(cfg.get("test_years", 3) or 3)))
        end_dt = pd.Timestamp(str(cfg.get("end_date")).strip()) if str(cfg.get("end_date", "")).strip() else max_date
    else:
        start_dt = end_dt = None

    if start_dt is not None:
        px_eval = px.loc[(px["date"] >= start_dt) & (px["date"] <= end_dt), [c for c in ["date", "stock_code", "high", "low", "close", "ma20", "ma50", "atr20"] if c in px.columns]].copy()
    else:
        px_eval = px[[c for c in ["date", "stock_code", "high", "low", "close", "ma20", "ma50", "atr20"] if c in px.columns]].copy()
    px_eval["date_key"] = px_eval["date"].dt.strftime("%Y-%m-%d")
    _blog(f"px eval {len(px_eval)}")

    # 빠른 가격 조회용 dict. 보유 포지션 수는 작기 때문에 전체 날짜×종목 매트릭스보다 dict가 단순하고 안정적이다.
    price_map: dict[tuple[str, str], dict[str, float]] = {}
    for r in px_eval.itertuples(index=False):
        rec = r._asdict()
        price_map[(rec["date_key"], rec["stock_code"])] = {
            "high": float(rec.get("high", np.nan)),
            "low": float(rec.get("low", np.nan)),
            "close": float(rec.get("close", np.nan)),
            "ma20": float(rec.get("ma20", np.nan)) if pd.notna(rec.get("ma20", np.nan)) else np.nan,
            "ma50": float(rec.get("ma50", np.nan)) if pd.notna(rec.get("ma50", np.nan)) else np.nan,
            "atr20": float(rec.get("atr20", np.nan)) if pd.notna(rec.get("atr20", np.nan)) else np.nan,
        }
    dates = sorted(px_eval["date_key"].dropna().unique().tolist())
    _blog(f"price map {len(price_map)} dates {len(dates)}")

    sig = signals.copy()
    if sig is not None and not sig.empty:
        sig["stock_code"] = sig["stock_code"].map(normalize_code)
        sig["date"] = pd.to_datetime(sig["date"])
        if start_dt is not None:
            sig = sig[(sig["date"] >= start_dt) & (sig["date"] <= end_dt)].copy()
        # next_open/next_date를 대형 merge 대신 key map으로 부착.
        _blog(f"sig start {len(sig)}")
        next_src = px[["date", "stock_code", "next_date", "next_open"]].dropna(subset=["next_date", "next_open"]).copy()
        next_src["date_key"] = next_src["date"].dt.strftime("%Y-%m-%d")
        next_src["key"] = next_src["date_key"] + "|" + next_src["stock_code"].astype(str)
        next_open_map = dict(zip(next_src["key"], pd.to_numeric(next_src["next_open"], errors="coerce")))
        next_date_map = dict(zip(next_src["key"], pd.to_datetime(next_src["next_date"]).dt.strftime("%Y-%m-%d")))
        sig["date_key"] = sig["date"].dt.strftime("%Y-%m-%d")
        sig["key"] = sig["date_key"] + "|" + sig["stock_code"].astype(str)
        sig["next_open"] = sig["key"].map(next_open_map)
        sig["next_date_key"] = sig["key"].map(next_date_map)
        sig = sig.dropna(subset=["next_open", "next_date_key"])
        sig = sig.sort_values(["next_date_key", "strategy_id", "signal_score", "trading_value"], ascending=[True, True, False, False])
        entries_by_date: dict[str, list[dict[str, Any]]] = {}
        for rec in sig.to_dict("records"):
            entries_by_date.setdefault(str(rec["next_date_key"]), []).append(rec)
        _blog(f"entries dates {len(entries_by_date)}")
    else:
        entries_by_date = {}

    _blog("loop start")
    for dkey in dates:
        regime = market_by_date.get(dkey, {"market_mode": "risk_on", "exposure_multiplier": 1.0})
        market_mode = str(regime.get("market_mode", "risk_on"))
        exposure_mult = float(regime.get("exposure_multiplier", 1.0) or 1.0)
        # exits
        for key, pos in list(positions.items()):
            row = price_map.get((dkey, pos.stock_code))
            if row is None:
                pos.days_held += 1
                continue
            close = row["close"]; high = row["high"]; low = row["low"]
            _update_risk_overlay_stop(pos, row, cfg)
            exit_reason = None; exit_price = None
            if pd.Timestamp(dkey) > pd.Timestamp(pos.entry_date):
                # 보수적 체결: 당일 저가가 트레일링/손절선을 건드리면 손절 우선.
                if low <= pos.stop_loss:
                    exit_reason = "STOP"; exit_price = pos.stop_loss * (1 - slip)
                elif high >= pos.target_price:
                    exit_reason = "TARGET"; exit_price = pos.target_price * (1 - slip)
                else:
                    ex = cfg.get("strategy_exit", {}).get(pos.strategy_id, {})
                    max_days = int(ex.get("max_holding_days", 60))
                    ma50 = row.get("ma50", np.nan)
                    ma20 = row.get("ma20", np.nan)
                    fail_days = int((ro.get("breakout_fail_exit_days", {}) or {}).get(pos.strategy_id, 0) or 0)
                    pivot_price = float(pos.meta.get("pivot_price", np.nan))
                    if fail_days > 0 and pos.days_held <= fail_days and np.isfinite(pivot_price) and close < pivot_price * 0.995:
                        exit_reason = "BREAKOUT_FAIL"; exit_price = close * (1 - slip)
                    elif risk_overlay_enabled and _as_bool(ro.get("risk_off_defensive_exit", True), True) and market_mode == "risk_off" and close < pos.entry_price and np.isfinite(ma20) and close < ma20:
                        exit_reason = "MARKET_RISK_OFF"; exit_price = close * (1 - slip)
                    elif pos.days_held >= max_days:
                        exit_reason = "MAX_HOLD"; exit_price = close * (1 - slip)
                    elif pos.strategy_id == "stage2" and np.isfinite(ma50) and close < ma50 * 0.98:
                        exit_reason = "MA50_BREAK"; exit_price = close * (1 - slip)
            if exit_reason:
                gross = exit_price * pos.shares
                cost = gross * (sell_fee + tax)
                net = gross - cost
                cash[pos.strategy_id] += net
                invested = pos.entry_price * pos.shares
                pnl = net - invested
                trades.append({
                    "strategy_id": pos.strategy_id,
                    "strategy_name": STRATEGY_NAMES.get(pos.strategy_id, pos.strategy_id),
                    "stock_code": pos.stock_code,
                    "stock_name": pos.stock_name,
                    "entry_date": pd.Timestamp(pos.entry_date).strftime("%Y-%m-%d"),
                    "exit_date": dkey,
                    "entry_price": round(pos.entry_price, 4),
                    "exit_price": round(exit_price, 4),
                    "shares": int(pos.shares),
                    "gross_exit_value": round(gross, 2),
                    "costs": round(cost, 2),
                    "pnl": round(pnl, 2),
                    "return_pct": round(pnl / invested * 100 if invested else 0, 2),
                    "holding_days": int(pos.days_held),
                    "exit_reason": exit_reason,
                })
                if cooldown_after_stop_days > 0 and exit_reason in {"STOP", "BREAKOUT_FAIL", "MARKET_RISK_OFF"}:
                    stop_cooldown[(pos.strategy_id, pos.stock_code)] = pd.Timestamp(dkey) + pd.Timedelta(days=cooldown_after_stop_days)
                del positions[key]
            else:
                pos.days_held += 1

        # entries
        for r in entries_by_date.get(dkey, []):
            sid = str(r["strategy_id"])
            code = normalize_code(r["stock_code"])
            key = (sid, code)
            if key in positions:
                continue
            if key in stop_cooldown and pd.Timestamp(dkey) <= stop_cooldown[key]:
                continue
            if risk_overlay_enabled and market_mode == "risk_off" and _as_bool(ro.get("block_new_entries_in_risk_off", True), True):
                if float(r.get("signal_score", 0) or 0) < float(ro.get("allow_exception_score_in_risk_off", 88)):
                    continue
            if risk_overlay_enabled and int(ro.get("max_total_open_positions", 0) or 0) > 0 and len(positions) >= int(ro.get("max_total_open_positions")):
                continue
            sid_positions = [p for p in positions.values() if p.strategy_id == sid]
            max_pos = int(max_positions.get(sid, 5))
            if len(sid_positions) >= max_pos:
                continue
            available_cash = cash.get(sid, 0.0)
            if available_cash <= 0:
                continue
            strategy_equity, current_pos_value, _ = _current_strategy_equity(sid, cash, positions, price_map, dkey)
            allowed_pos_value = strategy_equity * exposure_mult if risk_overlay_enabled else strategy_equity
            remaining_allowed = max(0.0, allowed_pos_value - current_pos_value)
            if remaining_allowed <= 0:
                continue
            budget = min(available_cash, strategy_equity / max_pos, remaining_allowed)
            buy_price = float(r["next_open"]) * (1 + slip)
            if not np.isfinite(buy_price) or buy_price <= 0:
                continue
            stop = float(r.get("stop_loss", buy_price * 0.92))
            target = float(r.get("target_price", buy_price * 1.20))
            if not np.isfinite(stop) or stop <= 0 or stop >= buy_price:
                stop = buy_price * (1 - cfg.get("strategy_exit", {}).get(sid, {}).get("stop_pct", 0.08))
            if not np.isfinite(target) or target <= buy_price:
                target = buy_price * (1 + cfg.get("strategy_exit", {}).get(sid, {}).get("target_pct", 0.20))
            risk_per_share = max(0.01, buy_price - stop)
            if risk_overlay_enabled and _as_bool(ro.get("use_risk_position_sizing", True), True):
                risk_map = ro.get("risk_per_trade_pct_of_strategy_equity", {}) or {}
                risk_budget = strategy_equity * float(risk_map.get(sid, 0.01))
                risk_budget = max(0.0, min(risk_budget, budget))
                risk_sized_budget = (risk_budget / risk_per_share) * buy_price if risk_per_share > 0 else budget
                budget = min(budget, risk_sized_budget)
            shares = int(budget / (buy_price * (1 + buy_fee)))
            if shares <= 0:
                continue
            gross = buy_price * shares
            cost = gross * buy_fee
            total = gross + cost
            if total > available_cash:
                continue
            cash[sid] -= total
            positions[key] = Position(
                strategy_id=sid,
                stock_code=code,
                stock_name=str(r.get("stock_name", code)),
                entry_date=pd.Timestamp(dkey),
                entry_price=buy_price,
                shares=shares,
                stop_loss=stop,
                target_price=target,
                days_held=0,
                highest_price=buy_price,
                highest_close=buy_price,
                initial_risk_per_share=risk_per_share,
                meta={"signal_date": str(r.get("date_key", "")), "signal_score": float(r.get("signal_score", 0)), "pivot_price": float(r.get("pivot_price", np.nan))},
            )

        # equity
        pv_by_strategy = {sid: 0.0 for sid in weights}
        for pos in positions.values():
            row = price_map.get((dkey, pos.stock_code))
            close = row["close"] if row else pos.entry_price
            pv_by_strategy[pos.strategy_id] = pv_by_strategy.get(pos.strategy_id, 0.0) + close * pos.shares
        total_cash = sum(cash.values())
        total_pos = sum(pv_by_strategy.values())
        erow = {"date": dkey, "cash": total_cash, "position_value": total_pos, "portfolio_value": total_cash + total_pos, "open_positions": len(positions), "market_mode": market_mode, "exposure_multiplier": exposure_mult}
        for sid in weights:
            erow[f"{sid}_value"] = cash.get(sid, 0.0) + pv_by_strategy.get(sid, 0.0)
        equity_rows.append(erow)

    _blog("loop done")
    equity = pd.DataFrame(equity_rows)
    trades_df = pd.DataFrame(trades)
    summary = _metrics(equity, trades_df, initial_cash)
    if not trades_df.empty:
        by_strategy = []
        for sid in weights:
            g = trades_df[trades_df["strategy_id"] == sid]
            eq_col = f"{sid}_value"
            if eq_col not in equity:
                continue
            eq = equity[["date", eq_col]].rename(columns={eq_col: "portfolio_value"}).copy()
            by = _metrics(eq, g, initial_cash * float(weights.get(sid, 0)))
            if not by.empty:
                by.insert(0, "strategy_id", sid)
                by.insert(1, "strategy_name", STRATEGY_NAMES.get(sid, sid))
                by_strategy.append(by)
        strategy_summary = pd.concat(by_strategy, ignore_index=True) if by_strategy else pd.DataFrame()
    else:
        strategy_summary = pd.DataFrame()

    output_dir = Path(output_dir)
    signals.to_csv(output_dir / "backtest_signals.csv", index=False, encoding="utf-8-sig")
    equity.to_csv(output_dir / "backtest_equity_curve.csv", index=False, encoding="utf-8-sig")
    trades_df.to_csv(output_dir / "backtest_trades.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(output_dir / "backtest_summary.csv", index=False, encoding="utf-8-sig")
    strategy_summary.to_csv(output_dir / "backtest_strategy_summary.csv", index=False, encoding="utf-8-sig")
    save_backtest_html(equity, trades_df, summary, strategy_summary, output_dir)
    return {"signals": signals, "equity": equity, "trades": trades_df, "summary": summary, "strategy_summary": strategy_summary}

def _equity_svg(equity: pd.DataFrame, width: int = 920, height: int = 320) -> str:
    if equity is None or equity.empty:
        return "<div class='empty'>백테스트 그래프 데이터 없음</div>"
    vals = pd.to_numeric(equity["portfolio_value"], errors="coerce").to_numpy(float)
    vals = vals[np.isfinite(vals)]
    if len(vals) < 2:
        return "<div class='empty'>백테스트 그래프 데이터 부족</div>"
    left, right, top, bottom = 64, 24, 24, 48
    cw, ch = width - left - right, height - top - bottom
    ymin, ymax = float(vals.min()), float(vals.max())
    if ymax <= ymin:
        ymax = ymin + 1
    xs = np.linspace(left, left + cw, len(vals))
    ys = top + (ymax - vals) / (ymax - ymin) * ch
    points = " ".join(f"{x:.1f},{y:.1f}" for x, y in zip(xs, ys))
    return f"""
<svg viewBox='0 0 {width} {height}' class='eqsvg'>
<rect x='0' y='0' width='{width}' height='{height}' rx='16' fill='#f8fafc' stroke='#e5e7eb'/>
<line x1='{left}' y1='{top+ch}' x2='{left+cw}' y2='{top+ch}' stroke='#cbd5e1'/>
<line x1='{left}' y1='{top}' x2='{left}' y2='{top+ch}' stroke='#cbd5e1'/>
<line x1='{left}' y1='{top+ch*.33}' x2='{left+cw}' y2='{top+ch*.33}' stroke='#e5e7eb' stroke-dasharray='4 4'/>
<line x1='{left}' y1='{top+ch*.66}' x2='{left+cw}' y2='{top+ch*.66}' stroke='#e5e7eb' stroke-dasharray='4 4'/>
<polyline points='{points}' fill='none' stroke='#2563eb' stroke-width='3'/>
<text x='12' y='{top+8}' font-size='12' fill='#64748b'>{ymax:,.0f}</text>
<text x='12' y='{top+ch}' font-size='12' fill='#64748b'>{ymin:,.0f}</text>
<text x='{left}' y='{height-16}' font-size='12' fill='#64748b'>{equity['date'].iloc[0]}</text>
<text x='{left+cw-90}' y='{height-16}' font-size='12' fill='#64748b'>{equity['date'].iloc[-1]}</text>
</svg>"""


def save_backtest_html(equity: pd.DataFrame, trades: pd.DataFrame, summary: pd.DataFrame, strategy_summary: pd.DataFrame, output_dir: str | Path) -> Path:
    output_dir = Path(output_dir)
    s = summary.iloc[0].to_dict() if summary is not None and not summary.empty else {}
    cards = "".join([f"<div class='card'><b>{k}</b><span>{v:.2f}</span></div>" for k, v in s.items() if isinstance(v, (int, float, np.floating)) and np.isfinite(v)])
    st_rows = ""
    if strategy_summary is not None and not strategy_summary.empty:
        for _, r in strategy_summary.iterrows():
            st_rows += f"<tr><td>{r.get('strategy_name','')}</td><td>{r.get('total_return_pct',0):.2f}%</td><td>{r.get('mdd_pct',0):.2f}%</td><td>{r.get('trades',0)}</td><td>{r.get('win_rate_pct',0):.2f}%</td><td>{r.get('profit_factor',0):.2f}</td></tr>"
    html = f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>백테스트 결과</title>
<style>body{{margin:0;background:#f6f7fb;color:#172033;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif}}.wrap{{max-width:1100px;margin:0 auto;padding:28px 18px 60px}}.hero{{background:linear-gradient(135deg,#111827,#1d4ed8);color:white;border-radius:24px;padding:28px}}.grid{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:18px 0}}.card{{background:white;border:1px solid #e5e7eb;border-radius:16px;padding:14px}}.card b{{display:block;color:#64748b;font-size:12px}}.card span{{font-size:20px;font-weight:800}}.panel{{background:white;border:1px solid #e5e7eb;border-radius:18px;padding:18px;margin:16px 0;box-shadow:0 8px 24px rgba(15,23,42,.06)}}table{{width:100%;border-collapse:collapse}}td,th{{border-bottom:1px solid #e5e7eb;padding:10px;text-align:left}}a{{color:#2563eb;font-weight:800;text-decoration:none}}.eqsvg{{width:100%;height:auto}}</style></head><body><main class='wrap'>
<section class='hero'><h1>멀티 전략 백테스트 결과</h1><p>신호일 종가 확정 후 다음 거래일 시가 진입, 슬리피지/수수료/거래세 반영. 같은 날 손절·익절 동시 도달 시 손절 우선.</p></section>
<div class='grid'>{cards}</div><div class='panel'>{_equity_svg(equity)}</div><div class='panel'><h2>전략별 성과</h2><table><thead><tr><th>전략</th><th>수익률</th><th>MDD</th><th>거래수</th><th>승률</th><th>PF</th></tr></thead><tbody>{st_rows}</tbody></table></div>
<div class='panel'><a href='backtest_equity_curve.csv'>equity CSV</a> · <a href='backtest_trades.csv'>trades CSV</a> · <a href='backtest_summary.csv'>summary CSV</a> · <a href='backtest_signals.csv'>signals CSV</a> · <a href='backtest_market_regime.csv'>market regime CSV</a></div>
</main></body></html>"""
    path = output_dir / "backtest_report.html"
    path.write_text(html, encoding="utf-8")
    return path
