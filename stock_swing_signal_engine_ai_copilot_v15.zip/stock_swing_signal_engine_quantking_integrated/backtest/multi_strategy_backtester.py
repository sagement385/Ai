"""멀티 전략 실전형 일봉 백테스트 엔진.

특징
- 신호일 종가 확정 후 다음 거래일 시가 진입으로 룩어헤드 방지.
- 전략별 자금 계좌를 분리해 20/30/40/10 비중을 그대로 테스트.
- 손절/익절은 일봉 고가/저가로 체결, 같은 날 둘 다 닿으면 보수적으로 손절 우선.
- 매수/매도 수수료, 거래세, 슬리피지 반영.
- VCP/CANSLIM/Stage2/Darvas 역사적 신호를 벡터화해 생성.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import json
import math

import numpy as np
import pandas as pd

DEFAULT_CONFIG = {
    "initial_cash": 10000000,
    "enabled_strategies": ["vcp", "canslim", "stage2", "darvas", "deep_turnaround"],
    "test_years": 3,
    "start_date": "",
    "end_date": "",
    "buy_commission_rate": 0.00015,
    "sell_commission_rate": 0.00015,
    "sell_tax_rate": 0.0020,
    "slippage_rate": 0.0010,
    "max_single_stock_weight": 0.10,
    "min_trading_value": 300000000,
    "max_backtest_symbols": 500,
    "liquidity_lookback_rows": 80,
    "risk_overlay": {
        "enabled": True,
        "method_note": "기존 4전략 신호는 유지하고, 백테스트 체결/비중/청산 단계에만 시장필터·변동성 포지션사이징·트레일링스탑을 적용한다.",
        "market_exposure_multiplier": {"risk_on": 1.00, "neutral": 0.80, "risk_off": 0.50},
        "block_new_entries_in_risk_off": False,
        "allow_exception_score_in_risk_off": 88,
        "use_risk_position_sizing": True,
        "risk_per_trade_pct_of_strategy_equity": {
            "vcp": 0.018,
            "canslim": 0.018,
            "stage2": 0.016,
            "darvas": 0.015,
            "deep_turnaround": 0.010
        },
        "cooldown_after_stop_days": 10,
        "breakout_fail_exit_days": {"vcp": 0, "canslim": 0, "stage2": 0, "darvas": 0},
        "breakeven_trigger_pct": {"vcp": 0.14, "canslim": 0.16, "stage2": 0.20, "darvas": 0.14, "deep_turnaround": 1.0},
        "breakeven_buffer_pct": 0.003,
        "trailing_stop_enabled": True,
        "trailing_activation_pct": {"vcp": 0.18, "canslim": 0.20, "stage2": 0.25, "darvas": 0.16, "deep_turnaround": 1.5},
        "atr_trailing_multiple": {"vcp": 2.5, "canslim": 3.0, "stage2": 3.5, "darvas": 2.5, "deep_turnaround": 8.0},
        "max_total_open_positions": 20,
        "risk_off_defensive_exit": False
    },
    "entry_quality_filter": {
        "enabled": True,
        "method_note": "기존 전략 신호는 유지하되, 한국 시장에서 흔한 상한가/급등 추격매수와 손절폭 과다 진입을 차단하는 오버레이.",
        "korea_market_mode": True,
        "enable_buy_retest": True,
        "retest_lookback_days": 12,
        "retest_band_pct": {"vcp": 0.035, "canslim": 0.045, "stage2": 0.055, "darvas": 0.035, "deep_turnaround": 0.080},
        "max_pivot_extension_pct": {"vcp": 0.07, "canslim": 0.08, "stage2": 0.11, "darvas": 0.075, "deep_turnaround": 0.14},
        "max_ma20_extension_pct": {"vcp": 0.18, "canslim": 0.20, "stage2": 0.25, "darvas": 0.18, "deep_turnaround": 0.35},
        "max_ma60_extension_pct": {"vcp": 0.36, "canslim": 0.42, "stage2": 0.50, "darvas": 0.38, "deep_turnaround": 0.80},
        "max_ret20_pct": {"vcp": 0.40, "canslim": 0.45, "stage2": 0.55, "darvas": 0.35, "deep_turnaround": 0.90},
        "max_stop_distance_pct": {"vcp": 0.16, "canslim": 0.18, "stage2": 0.22, "darvas": 0.16, "deep_turnaround": 0.38},
        "max_single_day_chase_pct": 0.22,
        "near_limit_up_block_pct": 0.285,
        "write_audit": True
    },
    "capital_injection_overlay": {
        "enabled": False,
        "method_note": "손절 대신 외부 현금을 단계적으로 추가 투입하는 고위험 프로필. 수익률 평가는 반드시 총투입원금 기준으로 봐야 한다.",
        "allowed_strategies": ["vcp", "canslim", "stage2", "deep_turnaround"],
        "drawdown_triggers_pct": [-0.18, -0.32, -0.48],
        "add_fraction_of_initial_position": [0.50, 0.75, 1.00],
        "max_additions_per_position": 3,
        "max_external_capital_pct_of_initial_cash": 2.0,
        "max_position_value_pct_of_total_contributed": 0.28,
        "min_health_score": 62,
        "require_not_falling_knife": True,
        "catastrophic_exit_enabled": True,
        "catastrophic_drawdown_pct": -0.72
    },
    "signal_top_n_per_day": {
        "vcp": 5,
        "canslim": 5,
        "stage2": 8,
        "darvas": 3,
        "deep_turnaround": 4,
    },
    "weights": {
        "vcp": 0.20,
        "canslim": 0.30,
        "stage2": 0.30,
        "darvas": 0.10,
        "deep_turnaround": 0.10,
    },
    "max_positions": {
        "vcp": 5,
        "canslim": 5,
        "stage2": 8,
        "darvas": 3,
        "deep_turnaround": 4,
    },
    "strategy_exit": {
        "vcp": {"stop_pct": 0.07, "target_pct": 0.18, "max_holding_days": 45},
        "canslim": {"stop_pct": 0.08, "target_pct": 0.25, "max_holding_days": 65},
        "stage2": {"stop_pct": 0.10, "target_pct": 0.35, "max_holding_days": 130},
        "darvas": {"stop_pct": 0.08, "target_pct": 0.18, "max_holding_days": 35},
        "deep_turnaround": {"stop_pct": 0.25, "target_price_multiple": 5.0, "target_pct": 4.0, "max_holding_days": 756},
    },
    "exit_target_mode": "signal",
    "stop_loss_mode": "signal",
    "target_exit_enabled": True,
    "exit_profile_mode": "원형 유지",
    "profile_name": "balanced_risk_overlay",
}

STRATEGY_NAMES = {
    "vcp": "Minervini VCP",
    "canslim": "CANSLIM",
    "stage2": "Weinstein Stage2",
    "darvas": "Darvas Box",
    "deep_turnaround": "Deep Turnaround 10x",
}


def normalize_code(code: str | int | float) -> str:
    return str(code).strip().replace(".0", "").zfill(6)


def load_backtest_config(config_path: str | Path | None = None) -> dict[str, Any]:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if config_path is None:
        config_path = Path("configs/backtest_config.json")
    p = Path(config_path)
    if p.exists():
        user = json.loads(p.read_text(encoding="utf-8"))
        for k, v in user.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
    enabled = cfg.get("enabled_strategies") or ["vcp", "canslim", "stage2", "darvas"]
    enabled = [str(x).strip().lower() for x in enabled if str(x).strip().lower() in {"vcp", "canslim", "stage2", "darvas", "deep_turnaround"}]
    if not enabled:
        enabled = ["vcp", "canslim", "stage2", "darvas"]
    cfg["enabled_strategies"] = enabled
    cfg["weights"] = {k: float(v) for k, v in cfg.get("weights", {}).items() if k in enabled}
    total = sum(cfg["weights"].values())
    if total <= 0:
        raise ValueError("선택된 전략 비중 합계가 0입니다.")
    cfg["weights"] = {k: v / total for k, v in cfg["weights"].items()}
    cfg["max_positions"] = {k: v for k, v in cfg.get("max_positions", {}).items() if k in enabled}
    cfg["signal_top_n_per_day"] = {k: v for k, v in cfg.get("signal_top_n_per_day", {}).items() if k in enabled}
    return cfg



def _prefilter_backtest_universe(prices: pd.DataFrame, cfg: dict[str, Any]) -> tuple[pd.DataFrame, dict[str, Any]]:
    """백테스트 성능과 현실성을 위해 최근 거래대금 상위 종목만 선택한다.

    전체 2700개 종목을 모두 매일 백테스트하면 시간이 오래 걸리고, 실제 매매 불가능한 저유동성 종목이
    성과를 왜곡할 수 있다. 기본값은 최근 80개 거래일 median trading_value 상위 800개다.
    """
    max_symbols = int(cfg.get("max_backtest_symbols", 0) or 0)
    if max_symbols <= 0 or prices is None or prices.empty or "stock_code" not in prices.columns:
        return prices, {"universe_filtered": False, "symbols_before": 0, "symbols_after": 0}
    df = prices.copy()
    df["stock_code"] = df["stock_code"].map(normalize_code)
    df["date"] = pd.to_datetime(df["date"])
    if "trading_value" not in df.columns:
        df["trading_value"] = pd.to_numeric(df.get("close", 0), errors="coerce") * pd.to_numeric(df.get("volume", 0), errors="coerce")
    df["trading_value"] = pd.to_numeric(df["trading_value"], errors="coerce").fillna(0)
    before = int(df["stock_code"].nunique())
    if before <= max_symbols:
        return df, {"universe_filtered": False, "symbols_before": before, "symbols_after": before}
    lookback = int(cfg.get("liquidity_lookback_rows", 80) or 80)
    liq = (
        df.sort_values(["stock_code", "date"])
        .groupby("stock_code", sort=False)
        .tail(lookback)
        .groupby("stock_code")["trading_value"]
        .median()
        .sort_values(ascending=False)
    )
    keep = set(liq.head(max_symbols).index.astype(str))
    out = df[df["stock_code"].isin(keep)].copy()
    return out, {
        "universe_filtered": True,
        "symbols_before": before,
        "symbols_after": int(out["stock_code"].nunique()),
        "filter_rule": f"최근 {lookback}개 거래일 median trading_value 상위 {max_symbols}개",
    }


def _num(s: pd.Series, default=np.nan) -> pd.Series:
    if s is None:
        return pd.Series(default)
    return pd.to_numeric(s, errors="coerce")


def _roll_mean(df: pd.DataFrame, col: str, window: int, min_periods: int) -> pd.Series:
    return df.groupby("stock_code", sort=False)[col].rolling(window, min_periods=min_periods).mean().reset_index(level=0, drop=True)


def _roll_max(df: pd.DataFrame, col: str, window: int, min_periods: int) -> pd.Series:
    return df.groupby("stock_code", sort=False)[col].rolling(window, min_periods=min_periods).max().reset_index(level=0, drop=True)


def _roll_min(df: pd.DataFrame, col: str, window: int, min_periods: int) -> pd.Series:
    return df.groupby("stock_code", sort=False)[col].rolling(window, min_periods=min_periods).min().reset_index(level=0, drop=True)


def _rolling_features(prices: pd.DataFrame) -> pd.DataFrame:
    import os as _os, time as _time
    _dbg = bool(_os.getenv("DEBUG_BACKTEST"))
    _t0 = _time.time()
    def _log(msg):
        if _dbg:
            print(f"[rolling] {msg}: {_time.time()-_t0:.2f}s", flush=True)
    df = prices.copy()
    df["stock_code"] = df["stock_code"].map(normalize_code)
    if "stock_name" not in df.columns:
        df["stock_name"] = df.get("name", df["stock_code"])
    if "market" not in df.columns:
        df["market"] = "UNKNOWN"
    df["date"] = pd.to_datetime(df["date"])
    for col in ["open", "high", "low", "close", "volume", "trading_value"]:
        if col not in df.columns:
            df[col] = 0
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["date", "open", "high", "low", "close"]).sort_values(["stock_code", "date"]).reset_index(drop=True)
    _log("prep")
    g = df.groupby("stock_code", sort=False)
    for w in [10, 20, 50, 60, 120, 150, 200, 252]:
        df[f"ma{w}"] = _roll_mean(df, "close", w, max(5, int(w * 0.5)))
    df["high_shift1"] = g["high"].shift(1)
    df["low_shift1"] = g["low"].shift(1)
    for w in [20, 60, 120, 252]:
        minp = max(5, int(w * 0.4))
        df[f"high{w}_prev"] = _roll_max(df, "high_shift1", w, minp)
        df[f"low{w}_prev"] = _roll_min(df, "low_shift1", w, minp)
        df[f"ret{w}"] = g["close"].pct_change(w)
        df[f"range{w}"] = (df[f"high{w}_prev"] - df[f"low{w}_prev"]) / df["close"].replace(0, np.nan)
    prev_close = g["close"].shift(1)
    df["tr"] = pd.concat([
        (df["high"] - df["low"]).abs(),
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)
    df["atr20"] = _roll_mean(df, "tr", 20, 10)
    df["atr60"] = _roll_mean(df, "tr", 60, 20)
    df["atr_ratio"] = df["atr20"] / df["atr60"].replace(0, np.nan)
    df["daily_ret"] = g["close"].pct_change()
    df["max_daily_ret20"] = df.groupby("stock_code", sort=False)["daily_ret"].rolling(20, min_periods=5).max().reset_index(level=0, drop=True)
    df["vol20"] = _roll_mean(df, "volume", 20, 10)
    df["vol50"] = _roll_mean(df, "volume", 50, 20)
    df["vol60"] = _roll_mean(df, "volume", 60, 20)
    df["ma50_slope20"] = g["ma50"].diff(20) / g["ma50"].shift(20).replace(0, np.nan)
    df["ma200_slope20"] = g["ma200"].diff(20) / g["ma200"].shift(20).replace(0, np.nan)
    _log("daily rolling done")
    for w in [60, 120, 252]:
        market_ret = df.groupby("date", sort=False)[f"ret{w}"].transform("median")
        df[f"rs{w}"] = df[f"ret{w}"] - market_ret
    # 주봉 30주선 지표: 가능하면 data/csv_import/prices_weekly.csv 캐시를 사용하고, 없으면 생성한다.
    try:
        weekly = pd.DataFrame()
        weekly_path = Path("data/csv_import/prices_weekly.csv")
        if weekly_path.exists() and weekly_path.stat().st_size > 0:
            weekly = pd.read_csv(weekly_path, dtype={"stock_code": str})
            weekly["stock_code"] = weekly["stock_code"].map(normalize_code)
            weekly["date"] = pd.to_datetime(weekly["date"])
        if weekly.empty:
            from data_sources.weekly_features import build_weekly_prices
            _log("weekly build start")
            weekly = build_weekly_prices(df)
            _log("weekly build done")
        if weekly is not None and not weekly.empty:
            keep_cols = [c for c in ["stock_code", "date", "ma_30w", "ma_30w_slope_4w", "high_26w_prev", "stage2_weekly"] if c in weekly.columns]
            keep = weekly[keep_cols].copy().rename(columns={"date": "week_date"})
            keep["stock_code"] = keep["stock_code"].map(normalize_code)
            keep["week_date"] = pd.to_datetime(keep["week_date"]).dt.normalize()
            # 현재 날짜 기준으로 이미 확정된 최근 금요일 주봉만 붙인다. merge_asof보다 훨씬 빠르고 룩어헤드도 줄인다.
            df = df.copy()
            df["week_date"] = (df["date"].dt.normalize() - pd.to_timedelta((df["date"].dt.weekday - 4) % 7, unit="D"))
            df = df.merge(keep, on=["stock_code", "week_date"], how="left")
            _log("weekly merge done")
        else:
            df["ma_30w"] = np.nan; df["ma_30w_slope_4w"] = np.nan; df["high_26w_prev"] = np.nan; df["stage2_weekly"] = False
    except Exception:
        df["ma_30w"] = np.nan
        df["ma_30w_slope_4w"] = np.nan
        df["high_26w_prev"] = np.nan
        df["stage2_weekly"] = False
    for _c in ["high_shift1", "low_shift1"]:
        if _c in df.columns:
            del df[_c]
    # 이미 stock_code/date 기준으로 정렬된 상태이며 이후 백테스트에서 필요한 경우 날짜별 그룹을 다시 만든다.
    _log("done")
    return df



def _cfg_strategy_float(cfg: dict[str, Any], section: str, key: str, sid: str, default: float) -> float:
    try:
        v = (cfg.get(section, {}) or {}).get(key, default)
        if isinstance(v, dict):
            return float(v.get(sid, default))
        return float(v)
    except Exception:
        return float(default)


def _recent_retest_mask(df: pd.DataFrame, raw_breakout: pd.Series, pivot: pd.Series, sid: str, cfg: dict[str, Any]) -> pd.Series:
    ef = cfg.get("entry_quality_filter", {}) or {}
    if not _as_bool(ef.get("enable_buy_retest", True), True):
        return pd.Series(False, index=df.index)
    lookback = int(ef.get("retest_lookback_days", 12) or 12)
    band = _cfg_strategy_float(cfg, "entry_quality_filter", "retest_band_pct", sid, 0.04)
    rb = raw_breakout.fillna(False).astype(int)
    recent = rb.groupby(df["stock_code"], sort=False).rolling(lookback, min_periods=1).max().reset_index(level=0, drop=True).shift(1).fillna(0).astype(bool)
    # 돌파 이후 피벗 근처로 눌렸다가 피벗 위를 유지하는 재진입. 추격매수 대신 retest를 허용한다.
    return recent & (df["low"] <= pivot * (1 + band)) & (df["close"] >= pivot * 0.985) & (df["close"] <= pivot * (1 + band)) & (df["close"] >= df["ma20"] * 0.985)


def _apply_entry_quality(df: pd.DataFrame, mask: pd.Series, pivot: pd.Series, stop: pd.Series, sid: str, cfg: dict[str, Any], entry_type: str = "BREAKOUT") -> tuple[pd.Series, pd.DataFrame]:
    """추격매수/과열/손절폭 과다 진입을 차단하고 제외 사유별 카운트를 반환한다."""
    ef = cfg.get("entry_quality_filter", {}) or {}
    if not _as_bool(ef.get("enabled", True), True):
        return mask.fillna(False), pd.DataFrame()
    base = mask.fillna(False).copy()
    close = pd.to_numeric(df["close"], errors="coerce")
    pivot_gap = close / pivot.replace(0, np.nan) - 1
    ma20_gap = close / df["ma20"].replace(0, np.nan) - 1
    ma60_gap = close / df["ma60"].replace(0, np.nan) - 1
    ret20 = pd.to_numeric(df.get("ret20"), errors="coerce")
    daily_ret = pd.to_numeric(df.get("daily_ret"), errors="coerce")
    stop_dist = close / stop.replace(0, np.nan) - 1
    max_pivot = _cfg_strategy_float(cfg, "entry_quality_filter", "max_pivot_extension_pct", sid, 0.08)
    max_ma20 = _cfg_strategy_float(cfg, "entry_quality_filter", "max_ma20_extension_pct", sid, 0.20)
    max_ma60 = _cfg_strategy_float(cfg, "entry_quality_filter", "max_ma60_extension_pct", sid, 0.42)
    max_ret20 = _cfg_strategy_float(cfg, "entry_quality_filter", "max_ret20_pct", sid, 0.45)
    max_stop = _cfg_strategy_float(cfg, "entry_quality_filter", "max_stop_distance_pct", sid, 0.18)
    single_day = float(ef.get("max_single_day_chase_pct", 0.22) or 0.22)
    limit_day = float(ef.get("near_limit_up_block_pct", 0.285) or 0.285)

    filters = {
        "pivot_extension": pivot_gap > max_pivot,
        "ma20_extension": ma20_gap > max_ma20,
        "ma60_extension": ma60_gap > max_ma60,
        "ret20_overheat": ret20 > max_ret20,
        "stop_distance_wide": stop_dist > max_stop,
        "single_day_chase": daily_ret > single_day,
        "korea_limit_up_chase": daily_ret > limit_day,
    }
    # Retest 신호는 이미 눌림을 확인한 것이므로 피벗/MA 이격 기준을 완화한다.
    if str(entry_type).upper() == "RETEST":
        filters["pivot_extension"] = pivot_gap > max(max_pivot, _cfg_strategy_float(cfg, "entry_quality_filter", "retest_band_pct", sid, 0.04) + 0.015)
        filters["ma20_extension"] = ma20_gap > max_ma20 * 1.15
    excluded = pd.Series(False, index=df.index)
    rows = []
    raw_count = int(base.sum())
    for reason, cond in filters.items():
        c = cond.fillna(False) & base
        n = int(c.sum())
        if n:
            rows.append({"strategy_id": sid, "entry_type": entry_type, "reason": reason, "excluded": n, "raw_candidates": raw_count})
        excluded = excluded | c
    ok = base & (~excluded)
    audit = pd.DataFrame(rows)
    return ok, audit

def generate_historical_signals(prices: pd.DataFrame, cfg: dict[str, Any] | None = None) -> pd.DataFrame:
    import os as _os, time as _time
    _dbg = bool(_os.getenv("DEBUG_BACKTEST"))
    _t0 = _time.time()
    def _glog(msg):
        if _dbg:
            print(f"[signals] {msg}: {_time.time()-_t0:.2f}s", flush=True)
    cfg = cfg or DEFAULT_CONFIG
    enabled = set(cfg.get("enabled_strategies") or ["vcp", "canslim", "stage2", "darvas"])
    required_feature_cols = {"ma200", "high20_prev", "low20_prev", "atr20", "vol60", "rs120"}
    df = prices if required_feature_cols.issubset(set(prices.columns)) else _rolling_features(prices)
    _glog("features ready")
    min_tv = float(cfg.get("min_trading_value", 0))
    liquid = df["trading_value"].fillna(0) >= min_tv

    vol_ratio = df["vol20"] / df["vol60"].replace(0, np.nan)
    near_52w = df["close"] / df["high252_prev"].replace(0, np.nan) >= 0.75
    trend_strong = (df["close"] > df["ma50"]) & (df["close"] > df["ma150"]) & (df["close"] > df["ma200"]) & (df["ma50"] > df["ma150"]) & (df["ma150"] >= df["ma200"] * 0.97)
    contraction = (df["range20"] < df["range60"] * 0.80) & (df["atr_ratio"] < 1.00) & (vol_ratio < 1.05)

    signals = []
    audit_parts = []
    def add(strategy: str, mask: pd.Series, pivot_col: str, score: pd.Series, stop: pd.Series, target: pd.Series, entry_type: str = "BREAKOUT"):
        pivot = df[pivot_col] if isinstance(pivot_col, str) else pivot_col
        clean_mask, audit = _apply_entry_quality(df, mask, pivot, stop, strategy, cfg, entry_type=entry_type)
        if audit is not None and not audit.empty:
            audit_parts.append(audit)
        sig = df.loc[clean_mask & liquid, ["date", "stock_code", "stock_name", "market", "open", "high", "low", "close", "volume", "trading_value", "ma20", "ma60", "ret20", "daily_ret"]].copy()
        if sig.empty:
            return
        sig["strategy_id"] = strategy
        sig["strategy_name"] = STRATEGY_NAMES[strategy]
        sig["entry_type"] = str(entry_type).upper()
        sig["signal_score"] = score.loc[sig.index].clip(0, 100).round(2).values
        sig["pivot_price"] = pivot.loc[sig.index].values
        sig["stop_loss"] = stop.loc[sig.index].values
        sig["target_price"] = target.loc[sig.index].values
        sig["pivot_gap_pct"] = ((sig["close"] / sig["pivot_price"].replace(0, np.nan) - 1) * 100).round(2)
        sig["ma20_gap_pct"] = ((sig["close"] / sig["ma20"].replace(0, np.nan) - 1) * 100).round(2)
        sig["ma60_gap_pct"] = ((sig["close"] / sig["ma60"].replace(0, np.nan) - 1) * 100).round(2)
        sig["ret20_pct"] = (sig["ret20"] * 100).round(2)
        sig["stop_distance_pct"] = ((sig["close"] / sig["stop_loss"].replace(0, np.nan) - 1) * 100).round(2)
        sig["entry_quality_note"] = np.where(sig["entry_type"].eq("RETEST"), "BUY_RETEST: 돌파 후 피벗 재지지 확인", "BUY_BREAKOUT: 종가 확정 돌파")
        signals.append(sig)

    def add_breakout_and_retest(strategy: str, raw_breakout: pd.Series, pivot_col: str, base_mask: pd.Series, score: pd.Series, stop: pd.Series, target: pd.Series):
        pivot = df[pivot_col]
        breakout_mask = base_mask & raw_breakout
        add(strategy, breakout_mask, pivot_col, score, stop, target, "BREAKOUT")
        retest_mask = base_mask & _recent_retest_mask(df, raw_breakout, pivot, strategy, cfg)
        # retest는 같은 날 breakout과 중복되지 않게 분리한다.
        retest_mask = retest_mask & (~breakout_mask.fillna(False))
        add(strategy, retest_mask, pivot_col, score + 3.0, stop, target, "RETEST")

    if "vcp" in enabled:
        vcp_pivot = "high20_prev"
        vcp_base = trend_strong & near_52w & contraction
        vcp_raw = (df["close"] > df[vcp_pivot] * 1.005) & (df["volume"] > df["vol60"] * 1.30)
        vcp_score = 60 + (df["rs120"].fillna(0) * 140) + ((1 - df["range20"] / df["range60"].replace(0, np.nan)).fillna(0) * 35)
        add_breakout_and_retest("vcp", vcp_raw, vcp_pivot, vcp_base, vcp_score, df["close"] * 0.93, df["close"] * 1.18)

    if "canslim" in enabled:
        canslim_pivot = "high60_prev"
        leader = (df["rs60"] > 0) & (df["rs120"] > -0.02) & (df["ret120"] > 0)
        canslim_base = trend_strong & leader
        canslim_raw = (df["close"] > df[canslim_pivot] * 1.005) & (df["volume"] > df["vol50"] * 1.50)
        canslim_score = 62 + df["rs120"].fillna(0) * 160 + df["ret120"].fillna(0) * 45
        add_breakout_and_retest("canslim", canslim_raw, canslim_pivot, canslim_base, canslim_score, df["close"] * 0.92, df["close"] * 1.25)

    if "stage2" in enabled:
        stage2_pivot = "high120_prev"
        weekly_ok = (df.get("stage2_weekly", False).fillna(False).astype(bool) if "stage2_weekly" in df else False)
        stage2_trend = (df["close"] > df["ma150"]) & (df["close"] > df["ma200"]) & (df["ma200_slope20"] >= -0.001)
        stage2_base = stage2_trend & weekly_ok
        stage2_raw = (df["close"] > df[stage2_pivot] * 1.003) & (df["volume"] > df["vol60"] * 1.15)
        stage2_score = 60 + df["rs120"].fillna(0) * 150 + (df["ma_30w_slope_4w"].fillna(0) / df["ma_30w"].replace(0, np.nan).fillna(1) * 500)
        add_breakout_and_retest("stage2", stage2_raw, stage2_pivot, stage2_base, stage2_score, np.minimum(df["close"] * 0.90, df["ma50"].fillna(df["close"] * 0.90) * 0.98), df["close"] * 1.35)

    if "darvas" in enabled:
        darvas_pivot = "high20_prev"
        darvas_box = (df["range20"] < df["range60"] * 0.90) & (df["range20"] < 0.35)
        darvas_base = (df["close"] > df["ma50"]) & darvas_box
        darvas_raw = (df["close"] > df[darvas_pivot] * 1.005) & (df["volume"] > df["vol60"] * 1.25)
        darvas_score = 58 + df["rs60"].fillna(0) * 130 + ((1 - df["range20"] / df["range60"].replace(0, np.nan)).fillna(0) * 30)
        darvas_target = df["close"] + (df["high20_prev"] - df["low20_prev"]).clip(lower=0) * 2.0
        add_breakout_and_retest("darvas", darvas_raw, darvas_pivot, darvas_base, darvas_score, df["low20_prev"] * 0.99, darvas_target)

    if "deep_turnaround" in enabled:
        deep_pivot_series = pd.concat([df["high120_prev"], df["ma200"] * 1.02], axis=1).max(axis=1)
        df["deep_pivot_tmp"] = deep_pivot_series
        drawdown = df["close"] / df["high252_prev"].replace(0, np.nan) - 1
        off_low = df["close"] / df["low252_prev"].replace(0, np.nan) - 1
        bottom_stability = (
            ((off_low - 0.08) / (0.70 - 0.08) * 100).clip(0, 100).fillna(0) * 0.30 +
            ((df["close"] / df["low120_prev"].replace(0, np.nan) - 1 - 0.05) / (0.45 - 0.05) * 100).clip(0, 100).fillna(0) * 0.25 +
            ((df["low60_prev"] / df["low120_prev"].replace(0, np.nan) - 1 + 0.03) / (0.20 + 0.03) * 100).clip(0, 100).fillna(0) * 0.20 +
            ((1.20 - df["atr_ratio"]) / (1.20 - 0.55) * 100).clip(0, 100).fillna(0) * 0.25
        )
        recovery = ((df["close"] > df["ma50"]).astype(int) * 25 + (df["close"] > df["ma120"]).astype(int) * 20 + (df["ma50_slope20"] > 0).astype(int) * 20 + (df["close"] > df["ma200"] * 0.92).astype(int) * 20 + (df["ma200_slope20"] > -0.0007).astype(int) * 15)
        revival = (((vol_ratio - 0.75) / (2.2 - 0.75) * 100).clip(0, 100).fillna(0) * 0.45 + ((df["rs60"] + 0.05) / (0.20 + 0.05) * 100).clip(0, 100).fillna(0) * 0.30 + ((df["ret60"] + 0.05) / (0.35 + 0.05) * 100).clip(0, 100).fillna(0) * 0.25)
        drawdown_score = ((drawdown.abs() - 0.45) / (0.85 - 0.45) * 100).clip(0, 100).fillna(0)
        falling_knife = (df["ret20"] < -0.12) | ((df["close"] < df["ma50"]) & (df["ma50_slope20"] < 0) & (df["ret60"] < 0))
        no_base = (df["close"] < df["low120_prev"] * 1.05) & (df["ma50_slope20"] < 0)
        lottery_spike = df.get("max_daily_ret20", 0).fillna(0) > 0.30
        extreme_distress = drawdown < -0.92
        false_penalty = falling_knife.astype(int)*22 + no_base.astype(int)*18 + lottery_spike.astype(int)*15 + extreme_distress.astype(int)*30
        deep_score = drawdown_score*0.22 + bottom_stability*0.25 + recovery*0.25 + revival*0.18 + 50*0.10 - false_penalty
        deep_base = (drawdown <= -0.45) & (drawdown >= -0.93) & (~falling_knife) & (~no_base)
        deep_raw = (df["close"] > deep_pivot_series * 1.005) & (vol_ratio > 1.05)
        add_breakout_and_retest("deep_turnaround", deep_raw, "deep_pivot_tmp", deep_base, deep_score, np.minimum(df["close"] * 0.75, df["low120_prev"] * 0.96), df["close"] * 5.0)

    _glog(f"raw signal parts {len(signals)}")
    if not signals:
        out = pd.DataFrame(columns=["date", "stock_code", "strategy_id", "signal_score"])
        out.attrs["entry_filter_audit"] = pd.concat(audit_parts, ignore_index=True) if audit_parts else pd.DataFrame()
        return out
    out = pd.concat(signals, ignore_index=True)
    _glog(f"concat {len(out)}")
    out = out.dropna(subset=["pivot_price", "stop_loss", "target_price"])
    _glog(f"dropna {len(out)}")
    topn = cfg.get("signal_top_n_per_day", {})
    out["_date_key"] = out["date"].astype(str).str.slice(0, 10)
    out = out.sort_values(["_date_key", "strategy_id", "signal_score", "trading_value"], ascending=[True, True, False, False]).reset_index(drop=True)
    counts: dict[tuple[str, str], int] = {}
    keep_mask = []
    for dkey, sid in zip(out["_date_key"].astype(str).tolist(), out["strategy_id"].astype(str).tolist()):
        key = (dkey, sid)
        cnt = counts.get(key, 0) + 1
        counts[key] = cnt
        keep_mask.append(cnt <= int(topn.get(sid, 5)))
    out = out.loc[keep_mask].drop(columns=["_date_key"], errors="ignore")
    _glog(f"top filtered {len(out)}")
    out.attrs["entry_filter_audit"] = pd.concat(audit_parts, ignore_index=True) if audit_parts else pd.DataFrame(columns=["strategy_id", "entry_type", "reason", "excluded", "raw_candidates"])
    return out.reset_index(drop=True)


@dataclass
class Position:
    strategy_id: str
    stock_code: str
    stock_name: str
    entry_date: pd.Timestamp
    entry_price: float
    shares: int
    stop_loss: float
    target_price: float
    days_held: int = 0
    highest_price: float = 0.0
    highest_close: float = 0.0
    initial_risk_per_share: float = 0.0
    meta: dict[str, Any] = field(default_factory=dict)


def _metrics(equity: pd.DataFrame, trades: pd.DataFrame, initial_cash: float) -> pd.DataFrame:
    if equity.empty:
        return pd.DataFrame()
    eq = equity.copy().sort_values("date")
    eq["portfolio_value"] = pd.to_numeric(eq["portfolio_value"], errors="coerce")
    start = float(initial_cash)
    end = float(eq["portfolio_value"].iloc[-1])
    total_ret = end / start - 1 if start else 0
    days = max(1, (pd.to_datetime(eq["date"].iloc[-1]) - pd.to_datetime(eq["date"].iloc[0])).days)
    cagr = (end / start) ** (365.25 / days) - 1 if start > 0 and end > 0 else np.nan
    daily = eq["portfolio_value"].pct_change().dropna()
    sharpe = (daily.mean() / daily.std() * np.sqrt(252)) if len(daily) > 2 and daily.std() > 0 else np.nan
    cummax = eq["portfolio_value"].cummax()
    dd = eq["portfolio_value"] / cummax - 1
    mdd = dd.min() if len(dd) else 0
    if trades is None or trades.empty:
        win_rate = profit_factor = avg_hold = np.nan
        ntrades = 0
    else:
        pnl = pd.to_numeric(trades["pnl"], errors="coerce").fillna(0)
        wins = pnl[pnl > 0]
        losses = pnl[pnl < 0]
        win_rate = len(wins) / len(pnl) if len(pnl) else np.nan
        profit_factor = wins.sum() / abs(losses.sum()) if abs(losses.sum()) > 0 else np.inf if wins.sum() > 0 else np.nan
        avg_hold = pd.to_numeric(trades["holding_days"], errors="coerce").mean()
        ntrades = len(pnl)
    out = pd.DataFrame([{
        "initial_cash": start,
        "final_value": end,
        "total_return_pct": total_ret * 100,
        "cagr_pct": cagr * 100 if pd.notna(cagr) else np.nan,
        "mdd_pct": mdd * 100,
        "sharpe": sharpe,
        "trades": ntrades,
        "win_rate_pct": win_rate * 100 if pd.notna(win_rate) else np.nan,
        "profit_factor": profit_factor,
        "avg_holding_days": avg_hold,
    }])
    # 외부 자금 추가투입 전략은 단순 final/initial 수익률이 과장될 수 있다.
    # 따라서 총투입원금 기준 수익률을 별도로 기록한다.
    if "cumulative_external_contributions" in eq.columns:
        extra = pd.to_numeric(eq["cumulative_external_contributions"], errors="coerce").fillna(0)
        total_extra = float(extra.iloc[-1]) if len(extra) else 0.0
        total_contributed = start + total_extra
        net_profit = end - total_contributed
        out["external_contributions"] = total_extra
        out["total_contributed_cash"] = total_contributed
        out["net_profit_after_contributions"] = net_profit
        out["return_on_total_contributed_pct"] = (net_profit / total_contributed * 100) if total_contributed > 0 else np.nan
    return out


def _buyhold_benchmark(px_eval: pd.DataFrame, initial_cash: float, benchmark_id: str, benchmark_name: str, market_filter: str | None = None) -> pd.DataFrame:
    """평가구간 시작 시점 매수 후 보유형 동일가중 벤치마크를 만든다.

    KOSPI/KOSDAQ은 공식 지수 자체가 아니라 CSV의 market 컬럼을 이용한 동일가중 proxy다.
    평가 시작 이후 10일 이내 가격이 있는 종목만 포함해 신규상장주 중간 편입 왜곡을 줄인다.
    """
    cols = [c for c in ["date", "stock_code", "close", "market"] if c in px_eval.columns]
    df = px_eval[cols].copy()
    if df.empty or "close" not in df.columns:
        return pd.DataFrame(columns=["date", benchmark_id])
    df["date"] = pd.to_datetime(df["date"])
    df["stock_code"] = df["stock_code"].map(normalize_code)
    df["close"] = pd.to_numeric(df["close"], errors="coerce")
    df = df.dropna(subset=["date", "stock_code", "close"])
    df = df[df["close"] > 0]
    if market_filter and "market" in df.columns:
        mf = str(market_filter).upper()
        df = df[df["market"].astype(str).str.upper().str.contains(mf, na=False)].copy()
    if df.empty:
        return pd.DataFrame(columns=["date", benchmark_id])
    start_dt = df["date"].min()
    base_cutoff = start_dt + pd.Timedelta(days=10)
    base = (
        df[df["date"] <= base_cutoff]
        .sort_values(["stock_code", "date"])
        .groupby("stock_code", sort=False)
        .head(1)[["stock_code", "close"]]
        .rename(columns={"close": "base_close"})
    )
    base = base[pd.to_numeric(base["base_close"], errors="coerce") > 0]
    if base.empty:
        return pd.DataFrame(columns=["date", benchmark_id])
    merged = df.merge(base, on="stock_code", how="inner")
    merged["rel"] = merged["close"] / merged["base_close"].replace(0, np.nan)
    curve = merged.groupby("date", sort=True)["rel"].mean().dropna().reset_index()
    curve[benchmark_id] = curve["rel"] * float(initial_cash)
    return curve[["date", benchmark_id]]


def _daily_rebalanced_proxy(px_eval: pd.DataFrame, initial_cash: float, benchmark_id: str = "ew_daily_rebalanced_proxy") -> pd.DataFrame:
    """백테스트 유니버스의 일별 평균수익률 proxy. 공식 지수 대용 보조 벤치마크."""
    if px_eval is None or px_eval.empty:
        return pd.DataFrame(columns=["date", benchmark_id])
    df = px_eval[["date", "stock_code", "close"]].copy()
    df["date"] = pd.to_datetime(df["date"])
    df["stock_code"] = df["stock_code"].map(normalize_code)
    df["close"] = pd.to_numeric(df["close"], errors="coerce")
    df = df.dropna(subset=["date", "stock_code", "close"]).sort_values(["stock_code", "date"])
    df["ret"] = df.groupby("stock_code", sort=False)["close"].pct_change().clip(-0.30, 0.30)
    daily = df.groupby("date", sort=True)["ret"].mean().fillna(0).reset_index()
    daily[benchmark_id] = (1 + daily["ret"]).cumprod() * float(initial_cash)
    return daily[["date", benchmark_id]]


def _benchmark_summary_from_curve(curve: pd.DataFrame, value_col: str, benchmark_name: str, initial_cash: float) -> dict[str, Any]:
    if curve is None or curve.empty or value_col not in curve.columns:
        return {"benchmark_id": value_col, "benchmark_name": benchmark_name, "final_value": np.nan, "total_return_pct": np.nan, "cagr_pct": np.nan, "mdd_pct": np.nan, "sharpe": np.nan}
    tmp = curve[["date", value_col]].rename(columns={value_col: "portfolio_value"}).copy()
    met = _metrics(tmp, pd.DataFrame(), initial_cash)
    row = met.iloc[0].to_dict() if not met.empty else {}
    return {"benchmark_id": value_col, "benchmark_name": benchmark_name, "final_value": row.get("final_value", np.nan), "total_return_pct": row.get("total_return_pct", np.nan), "cagr_pct": row.get("cagr_pct", np.nan), "mdd_pct": row.get("mdd_pct", np.nan), "sharpe": row.get("sharpe", np.nan)}


def _compute_benchmarks(px_eval: pd.DataFrame, equity: pd.DataFrame, cfg: dict[str, Any], initial_cash: float, output_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """전략성과를 시장/동일가중 proxy와 비교하기 위한 벤치마크 파일을 만든다."""
    if equity is None or equity.empty or px_eval is None or px_eval.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    eq_dates = pd.to_datetime(equity["date"])
    start_dt, end_dt = eq_dates.min(), eq_dates.max()
    px_eval = px_eval.copy()
    px_eval["date"] = pd.to_datetime(px_eval["date"])
    px_eval = px_eval[(px_eval["date"] >= start_dt) & (px_eval["date"] <= end_dt)].copy()
    curves = []
    meta = []
    for bid, bname, mf in [
        ("ew_buyhold_universe", "동일가중 매수보유 · 백테스트 유니버스", None),
        ("ew_buyhold_kospi_proxy", "KOSPI 동일가중 proxy · CSV market 기준", "KOSPI"),
        ("ew_buyhold_kosdaq_proxy", "KOSDAQ 동일가중 proxy · CSV market 기준", "KOSDAQ"),
    ]:
        c = _buyhold_benchmark(px_eval, initial_cash, bid, bname, mf)
        if not c.empty:
            curves.append(c); meta.append((bid, bname))
    c = _daily_rebalanced_proxy(px_eval, initial_cash, "ew_daily_rebalanced_proxy")
    if not c.empty:
        curves.append(c); meta.append(("ew_daily_rebalanced_proxy", "동일가중 일별 리밸런싱 proxy"))
    if not curves:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    bench = curves[0]
    for c in curves[1:]:
        bench = bench.merge(c, on="date", how="outer")
    bench = bench.sort_values("date")
    value_cols = [c for c in bench.columns if c != "date"]
    bench[value_cols] = bench[value_cols].ffill()
    bench["date"] = pd.to_datetime(bench["date"]).dt.strftime("%Y-%m-%d")
    summary_rows = [_benchmark_summary_from_curve(bench[["date", bid]].copy(), bid, bname, initial_cash) for bid, bname in meta]
    benchmark_summary = pd.DataFrame(summary_rows)
    strat_summary = _metrics(equity[["date", "portfolio_value"]].copy(), pd.DataFrame(), initial_cash)
    excess_rows = []
    if not strat_summary.empty:
        ss = strat_summary.iloc[0].to_dict()
        for _, b in benchmark_summary.iterrows():
            excess_rows.append({
                "benchmark_id": b.get("benchmark_id"),
                "benchmark_name": b.get("benchmark_name"),
                "strategy_total_return_pct": ss.get("total_return_pct", np.nan),
                "benchmark_total_return_pct": b.get("total_return_pct", np.nan),
                "excess_total_return_pct": ss.get("total_return_pct", np.nan) - b.get("total_return_pct", np.nan),
                "strategy_cagr_pct": ss.get("cagr_pct", np.nan),
                "benchmark_cagr_pct": b.get("cagr_pct", np.nan),
                "excess_cagr_pct": ss.get("cagr_pct", np.nan) - b.get("cagr_pct", np.nan),
                "strategy_mdd_pct": ss.get("mdd_pct", np.nan),
                "benchmark_mdd_pct": b.get("mdd_pct", np.nan),
                "mdd_advantage_pct": ss.get("mdd_pct", np.nan) - b.get("mdd_pct", np.nan),
                "strategy_sharpe": ss.get("sharpe", np.nan),
                "benchmark_sharpe": b.get("sharpe", np.nan),
                "sharpe_diff": ss.get("sharpe", np.nan) - b.get("sharpe", np.nan),
            })
    excess = pd.DataFrame(excess_rows)
    output_dir.mkdir(parents=True, exist_ok=True)
    bench.to_csv(output_dir / "backtest_benchmark_equity.csv", index=False, encoding="utf-8-sig")
    benchmark_summary.to_csv(output_dir / "backtest_benchmark_summary.csv", index=False, encoding="utf-8-sig")
    excess.to_csv(output_dir / "backtest_excess_summary.csv", index=False, encoding="utf-8-sig")
    return bench, benchmark_summary, excess




def _as_bool(v: Any, default: bool = False) -> bool:
    if isinstance(v, bool):
        return v
    if v is None:
        return default
    return str(v).strip().lower() in {"1", "true", "yes", "y", "on"}




def _capital_injection_health(row: dict[str, float], pos: Position, cfg: dict[str, Any]) -> tuple[float, bool, str]:
    """추가매수 안전장치.

    손절 대신 추가 자금을 투입할 때 가장 위험한 것은 거짓 저점/falling knife다.
    재무 point-in-time 데이터가 없을 수 있으므로 여기서는 가격 기반 생존·회복 조건을 보수적으로 사용한다.
    """
    c = float(row.get("close", np.nan))
    ma50 = float(row.get("ma50", np.nan))
    ma120 = float(row.get("ma120", np.nan))
    ma200 = float(row.get("ma200", np.nan))
    ma50_slope = float(row.get("ma50_slope20", np.nan))
    ma200_slope = float(row.get("ma200_slope20", np.nan))
    ret20 = float(row.get("ret20", np.nan))
    ret60 = float(row.get("ret60", np.nan))
    low120 = float(row.get("low120_prev", np.nan))
    high252 = float(row.get("high252_prev", np.nan))
    low252 = float(row.get("low252_prev", np.nan))
    vol20 = float(row.get("vol20", np.nan))
    vol60 = float(row.get("vol60", np.nan))

    score = 50.0
    reasons = []
    if np.isfinite(c) and np.isfinite(ma50) and c > ma50:
        score += 10; reasons.append("close>ma50")
    if np.isfinite(c) and np.isfinite(ma120) and c > ma120 * 0.95:
        score += 8; reasons.append("near/above ma120")
    if np.isfinite(c) and np.isfinite(ma200) and c > ma200 * 0.88:
        score += 10; reasons.append("near ma200")
    if np.isfinite(ma50_slope) and ma50_slope > -0.01:
        score += 8; reasons.append("ma50 not collapsing")
    if np.isfinite(ma200_slope) and ma200_slope > -0.015:
        score += 8; reasons.append("ma200 stable")
    if np.isfinite(ret60) and ret60 > -0.08:
        score += 8; reasons.append("60d not weak")
    if np.isfinite(vol20) and np.isfinite(vol60) and vol60 > 0 and vol20 / vol60 > 0.70:
        score += 6; reasons.append("volume alive")

    falling_knife = (np.isfinite(ret20) and ret20 < -0.12) or (np.isfinite(c) and np.isfinite(ma50) and np.isfinite(ma50_slope) and np.isfinite(ret60) and c < ma50 and ma50_slope < 0 and ret60 < 0)
    no_base = np.isfinite(c) and np.isfinite(low120) and np.isfinite(ma50_slope) and c < low120 * 1.05 and ma50_slope < 0
    extreme_distress = np.isfinite(c) and np.isfinite(high252) and high252 > 0 and c / high252 - 1 < -0.92
    dead_bounce = np.isfinite(c) and np.isfinite(low252) and low252 > 0 and c < low252 * 1.08 and np.isfinite(ret60) and ret60 < 0

    if falling_knife:
        score -= 28; reasons.append("falling_knife")
    if no_base:
        score -= 18; reasons.append("no_base")
    if extreme_distress:
        score -= 25; reasons.append("extreme_distress")
    if dead_bounce:
        score -= 12; reasons.append("dead_bounce")

    cio = cfg.get("capital_injection_overlay", {}) or {}
    min_score = float(cio.get("min_health_score", 62) or 62)
    require_not_falling = _as_bool(cio.get("require_not_falling_knife", True), True)
    ok = score >= min_score and (not require_not_falling or not falling_knife) and not no_base and not extreme_distress
    return float(max(0, min(100, score))), bool(ok), ",".join(reasons)


def _try_capital_injection(
    pos: Position,
    row: dict[str, float],
    cfg: dict[str, Any],
    cash: dict[str, float],
    initial_cash: float,
    external_contributions_total: float,
    contribution_rows: list[dict[str, Any]],
    dkey: str,
    buy_fee: float,
    slip: float,
) -> float:
    """조건 충족 시 외부 자금을 추가 투입해 해당 포지션을 물타기한다.

    반환값은 업데이트된 누적 외부투입금이다.
    """
    cio = cfg.get("capital_injection_overlay", {}) or {}
    if not _as_bool(cio.get("enabled", False), False):
        return external_contributions_total
    allowed = set(str(x).lower() for x in (cio.get("allowed_strategies") or []))
    if allowed and pos.strategy_id not in allowed:
        return external_contributions_total
    close = float(row.get("close", np.nan))
    if not np.isfinite(close) or close <= 0 or pos.entry_price <= 0:
        return external_contributions_total
    current_dd = close / pos.entry_price - 1
    triggers = [float(x) for x in (cio.get("drawdown_triggers_pct") or [])]
    adds = [float(x) for x in (cio.get("add_fraction_of_initial_position") or [])]
    if not triggers or not adds:
        return external_contributions_total
    max_additions = int(cio.get("max_additions_per_position", len(triggers)) or len(triggers))
    done = set(pos.meta.get("capital_injection_tiers", []))
    if len(done) >= max_additions:
        return external_contributions_total

    tier = None
    for i, trig in enumerate(triggers):
        if current_dd <= trig and i not in done:
            tier = i
            break
    if tier is None:
        return external_contributions_total

    health, ok, health_reason = _capital_injection_health(row, pos, cfg)
    if not ok:
        pos.meta.setdefault("capital_injection_rejections", []).append({"date": dkey, "tier": tier, "drawdown": current_dd, "health": health, "reason": health_reason})
        return external_contributions_total

    max_external = initial_cash * float(cio.get("max_external_capital_pct_of_initial_cash", 2.0) or 2.0)
    if external_contributions_total >= max_external:
        return external_contributions_total

    initial_value = float(pos.meta.get("initial_position_value", pos.entry_price * pos.shares))
    add_fraction = adds[min(tier, len(adds)-1)]
    contribution = max(0.0, initial_value * add_fraction)
    contribution = min(contribution, max_external - external_contributions_total)
    total_contributed_after = initial_cash + external_contributions_total + contribution
    max_position_value = total_contributed_after * float(cio.get("max_position_value_pct_of_total_contributed", 0.28) or 0.28)
    current_value = close * pos.shares
    contribution = min(contribution, max(0.0, max_position_value - current_value))
    if contribution <= 0:
        return external_contributions_total

    buy_price = close * (1 + slip)
    shares = int(contribution / (buy_price * (1 + buy_fee)))
    if shares <= 0:
        return external_contributions_total
    gross = buy_price * shares
    fee = gross * buy_fee
    total_cost = gross + fee
    # 외부 자금을 현금으로 넣고 즉시 매수한 것으로 처리한다.
    cash[pos.strategy_id] = cash.get(pos.strategy_id, 0.0) + contribution - total_cost
    old_shares = pos.shares
    old_cost = pos.entry_price * old_shares
    pos.shares += shares
    pos.entry_price = (old_cost + gross) / max(1, pos.shares)
    pos.meta.setdefault("capital_injection_tiers", []).append(tier)
    pos.meta["external_contribution"] = float(pos.meta.get("external_contribution", 0.0) or 0.0) + contribution
    pos.meta["avg_cost_after_add"] = pos.entry_price
    # 평균단가가 내려가더라도 catastrophic stop은 완전히 제거하지 않는다.
    cat_dd = float(cio.get("catastrophic_drawdown_pct", -0.72) or -0.72)
    if _as_bool(cio.get("catastrophic_exit_enabled", True), True):
        pos.stop_loss = min(pos.stop_loss, pos.entry_price * (1 + cat_dd))

    external_contributions_total += contribution
    contribution_rows.append({
        "date": dkey,
        "strategy_id": pos.strategy_id,
        "stock_code": pos.stock_code,
        "stock_name": pos.stock_name,
        "tier": tier + 1,
        "trigger_drawdown_pct": round(current_dd * 100, 2),
        "health_score": round(health, 2),
        "health_reason": health_reason,
        "contribution_cash": round(contribution, 2),
        "add_price": round(buy_price, 4),
        "add_shares": int(shares),
        "avg_cost_after": round(pos.entry_price, 4),
        "shares_after": int(pos.shares),
        "cumulative_external_contributions": round(external_contributions_total, 2),
    })
    return external_contributions_total

def _apply_exit_price_policy(sid: str, buy_price: float, signal_stop: float, signal_target: float, cfg: dict[str, Any]) -> tuple[float, float, str]:
    """기존 4개 알고리즘의 진입 신호는 그대로 두고, 백테스트 청산 목표/손절만 프로필에 맞게 바꾼다.

    - signal: 전략 신호가 산출한 기존 진입/손절/목표를 그대로 사용
    - config_pct: strategy_exit의 stop_pct/target_pct를 진입가 기준으로 사용
    - config_multiple: strategy_exit의 target_price_multiple을 진입가 배수 목표로 사용
    - max_signal_and_config: 기존 신호 목표와 config 목표 중 더 큰 목표 사용, 손절은 config/신호 중 더 넓은 쪽 사용
    """
    ex = (cfg.get("strategy_exit", {}) or {}).get(sid, {}) or {}
    target_mode = str(cfg.get("exit_target_mode", "signal") or "signal").lower().strip()
    stop_mode = str(cfg.get("stop_loss_mode", "signal") or "signal").lower().strip()

    stop_pct = float(ex.get("stop_pct", 0.08) or 0.08)
    target_pct = float(ex.get("target_pct", 0.20) or 0.20)
    target_mult = float(ex.get("target_price_multiple", 1.0 + target_pct) or (1.0 + target_pct))

    stop = float(signal_stop) if np.isfinite(signal_stop) and signal_stop > 0 else buy_price * (1 - stop_pct)
    target = float(signal_target) if np.isfinite(signal_target) and signal_target > buy_price else buy_price * (1 + target_pct)

    cfg_stop = buy_price * (1 - stop_pct)
    cfg_target_pct = buy_price * (1 + target_pct)
    cfg_target_mult = buy_price * target_mult

    if stop_mode in {"config", "config_pct"}:
        stop = cfg_stop
    elif stop_mode in {"wider", "wider_of_signal_and_config", "aggressive_wider"}:
        # 롱 포지션에서 더 넓은 손절은 더 낮은 가격이다.
        stop = min(stop, cfg_stop)
    elif stop_mode in {"tighter", "tighter_of_signal_and_config"}:
        stop = max(stop, cfg_stop)

    if target_mode in {"config", "config_pct"}:
        target = cfg_target_pct
    elif target_mode in {"config_multiple", "multiple", "price_multiple"}:
        target = cfg_target_mult
    elif target_mode in {"max_signal_and_config", "long_swing", "aggressive_long_swing"}:
        target = max(target, cfg_target_pct, cfg_target_mult)
    elif target_mode in {"min_signal_and_config"}:
        target = min(target, cfg_target_pct, cfg_target_mult)

    if not np.isfinite(stop) or stop <= 0 or stop >= buy_price:
        stop = buy_price * (1 - stop_pct)
    if not np.isfinite(target) or target <= buy_price:
        target = buy_price * max(1.01, target_mult)
    return float(stop), float(target), f"target_mode={target_mode};stop_mode={stop_mode}"

def _build_market_regime(px: pd.DataFrame, cfg: dict[str, Any]) -> pd.DataFrame:
    """개별 전략 신호를 바꾸지 않고, 백테스트 포지션/신규진입만 통제할 시장상태 테이블을 만든다.

    벤치마크 지수 CSV가 없어도 전체 백테스트 유니버스의 median daily return으로 equal-weight 시장 프록시를
    만들기 때문에 yfinance 가격 CSV만으로 작동한다. 이 값은 종목 선정 점수에는 쓰지 않고 risk overlay에만 쓴다.
    """
    if px is None or px.empty:
        return pd.DataFrame(columns=["date_key", "market_proxy", "market_mode", "exposure_multiplier"])
    ro = cfg.get("risk_overlay", {}) or {}
    enabled = _as_bool(ro.get("enabled", True), True)
    dates = pd.DataFrame({"date": pd.to_datetime(px["date"].dropna().unique())}).sort_values("date")
    dates["date_key"] = dates["date"].dt.strftime("%Y-%m-%d")
    if not enabled:
        dates["market_proxy"] = 1000.0
        dates["market_mode"] = "risk_on"
        dates["exposure_multiplier"] = 1.0
        return dates[["date_key", "market_proxy", "market_mode", "exposure_multiplier"]]

    tmp = px[["date", "stock_code", "close"]].copy()
    tmp["date"] = pd.to_datetime(tmp["date"])
    tmp["stock_code"] = tmp["stock_code"].map(normalize_code)
    tmp["close"] = pd.to_numeric(tmp["close"], errors="coerce")
    tmp = tmp.sort_values(["stock_code", "date"])
    tmp["daily_ret"] = tmp.groupby("stock_code", sort=False)["close"].pct_change().clip(-0.30, 0.30)
    # median을 쓰면 특정 급등/급락주 하나가 시장상태를 왜곡하는 것을 줄인다.
    m = tmp.groupby("date", sort=True)["daily_ret"].median().fillna(0).reset_index()
    m["market_proxy"] = (1 + m["daily_ret"]).cumprod() * 1000.0
    m["market_ma50"] = m["market_proxy"].rolling(50, min_periods=25).mean()
    m["market_ma200"] = m["market_proxy"].rolling(200, min_periods=100).mean()
    m["market_ret20"] = m["market_proxy"].pct_change(20)
    m["market_vol20"] = m["daily_ret"].rolling(20, min_periods=10).std() * np.sqrt(252)
    m["market_dd60"] = m["market_proxy"] / m["market_proxy"].rolling(60, min_periods=20).max() - 1

    risk_on = (m["market_proxy"] > m["market_ma200"]) & (m["market_proxy"] > m["market_ma50"]) & (m["market_ret20"] > -0.04)
    neutral = ((m["market_proxy"] > m["market_ma200"]) | (m["market_proxy"] > m["market_ma50"])) & (m["market_dd60"] > -0.12)
    m["market_mode"] = np.where(risk_on, "risk_on", np.where(neutral, "neutral", "risk_off"))
    mult_map = ro.get("market_exposure_multiplier", {}) or {}
    m["exposure_multiplier"] = m["market_mode"].map({
        "risk_on": float(mult_map.get("risk_on", 1.0)),
        "neutral": float(mult_map.get("neutral", 0.6)),
        "risk_off": float(mult_map.get("risk_off", 0.2)),
    }).fillna(1.0)
    m["date_key"] = pd.to_datetime(m["date"]).dt.strftime("%Y-%m-%d")
    return m[["date_key", "market_proxy", "market_ma50", "market_ma200", "market_ret20", "market_vol20", "market_dd60", "market_mode", "exposure_multiplier"]]


def _current_strategy_equity(sid: str, cash: dict[str, float], positions: dict[tuple[str, str], Position], price_map: dict[tuple[str, str], dict[str, float]], dkey: str) -> tuple[float, float, int]:
    pos_value = 0.0
    n = 0
    for p in positions.values():
        if p.strategy_id != sid:
            continue
        n += 1
        row = price_map.get((dkey, p.stock_code))
        pos_value += (row["close"] if row else p.entry_price) * p.shares
    equity = float(cash.get(sid, 0.0)) + pos_value
    return equity, pos_value, n


def _update_risk_overlay_stop(pos: Position, row: dict[str, float], cfg: dict[str, Any]) -> None:
    """진입 신호는 그대로 두고, 보유 중 방어 로직만 적용한다."""
    ro = cfg.get("risk_overlay", {}) or {}
    if not _as_bool(ro.get("enabled", True), True):
        return
    high = float(row.get("high", np.nan))
    close = float(row.get("close", np.nan))
    atr20 = float(row.get("atr20", np.nan))
    if np.isfinite(high):
        pos.highest_price = max(float(pos.highest_price or pos.entry_price), high)
    if np.isfinite(close):
        pos.highest_close = max(float(pos.highest_close or pos.entry_price), close)
    if pos.entry_price <= 0:
        return
    best_gain = max(pos.highest_price, pos.highest_close, pos.entry_price) / pos.entry_price - 1
    # 수익이 일정 수준 나면 손절선을 매수가+비용버퍼로 끌어올린다.
    be_map = ro.get("breakeven_trigger_pct", {}) or {}
    trigger = float(be_map.get(pos.strategy_id, 0.12))
    if best_gain >= trigger:
        buffer = float(ro.get("breakeven_buffer_pct", 0.003))
        pos.stop_loss = max(pos.stop_loss, pos.entry_price * (1 + buffer))
    # Chandelier/ATR 계열 트레일링 스탑. 활성화 전에는 기존 손절선을 건드리지 않는다.
    if _as_bool(ro.get("trailing_stop_enabled", True), True):
        act_map = ro.get("trailing_activation_pct", {}) or {}
        mult_map = ro.get("atr_trailing_multiple", {}) or {}
        activation = float(act_map.get(pos.strategy_id, 0.15))
        atr_mult = float(mult_map.get(pos.strategy_id, 3.0))
        if best_gain >= activation and np.isfinite(atr20) and atr20 > 0:
            trail = pos.highest_price - atr20 * atr_mult
            if np.isfinite(trail) and trail > 0:
                pos.stop_loss = max(pos.stop_loss, trail)

def run_multi_strategy_backtest(prices: pd.DataFrame, config_path: str | Path | None = None, output_dir: str | Path = "reports/output") -> dict[str, pd.DataFrame]:
    """4전략 포트폴리오를 실제 체결 가정으로 백테스트한다.

    방식
    - 과거 전체 가격 데이터로 지표를 계산한다.
    - 기본값은 최근 3년 구간에서만 신호를 평가한다.
    - 신호일 종가 확정 후 다음 거래일 시가에 진입한다.
    - 수수료, 거래세, 슬리피지를 반영한다.
    - 기본적으로 최근 거래대금 상위 800개만 테스트해 저유동성 왜곡과 과도한 연산을 줄인다.
    """
    cfg = load_backtest_config(config_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    prices, universe_filter_info = _prefilter_backtest_universe(prices, cfg)
    feature_prices = _rolling_features(prices)
    signals = generate_historical_signals(feature_prices, cfg)
    entry_audit = signals.attrs.get("entry_filter_audit", pd.DataFrame()) if hasattr(signals, "attrs") else pd.DataFrame()
    if entry_audit is not None and not entry_audit.empty:
        entry_audit.to_csv(output_dir / "backtest_entry_filter_audit.csv", index=False, encoding="utf-8-sig")
    else:
        pd.DataFrame(columns=["strategy_id","entry_type","reason","excluded","raw_candidates"]).to_csv(output_dir / "backtest_entry_filter_audit.csv", index=False, encoding="utf-8-sig")
    result = _run_with_entries(feature_prices, signals, cfg, output_dir)
    if result.get("summary") is not None and not result["summary"].empty:
        for k, v in universe_filter_info.items():
            result["summary"][k] = v
        result["summary"].to_csv(output_dir / "backtest_summary.csv", index=False, encoding="utf-8-sig")
        save_backtest_html(result["equity"], result["trades"], result["summary"], result["strategy_summary"], output_dir, result.get("benchmark_equity"), result.get("benchmark_summary"), result.get("excess_summary"))
    return result

def _run_with_entries(px: pd.DataFrame, signals: pd.DataFrame, cfg: dict[str, Any], output_dir: Path) -> dict[str, pd.DataFrame]:
    import os as _os, time as _time
    _dbg = bool(_os.getenv("DEBUG_BACKTEST"))
    _t0 = _time.time()
    def _blog(msg):
        if _dbg:
            print(f"[engine] {msg}: {_time.time()-_t0:.2f}s", flush=True)
    initial_cash = float(cfg.get("initial_cash", 10000000))
    weights = cfg.get("weights", DEFAULT_CONFIG["weights"])
    max_positions = cfg.get("max_positions", DEFAULT_CONFIG["max_positions"])
    cash = {sid: initial_cash * float(weights.get(sid, 0)) for sid in weights}
    positions: dict[tuple[str, str], Position] = {}
    trades = []
    equity_rows = []
    contribution_rows: list[dict[str, Any]] = []
    external_contributions_total = 0.0
    buy_fee = float(cfg.get("buy_commission_rate", 0.00015))
    sell_fee = float(cfg.get("sell_commission_rate", 0.00015))
    tax = float(cfg.get("sell_tax_rate", 0.002))
    slip = float(cfg.get("slippage_rate", 0.001))
    ro = cfg.get("risk_overlay", {}) or {}
    risk_overlay_enabled = _as_bool(ro.get("enabled", True), True)
    cooldown_after_stop_days = int(ro.get("cooldown_after_stop_days", 0) or 0)
    stop_cooldown: dict[tuple[str, str], pd.Timestamp] = {}

    _blog("start")
    # feature 생성 단계에서 이미 stock_code/date 정렬 및 정규화가 끝나 있으므로 대형 DF 복사를 피한다.
    px = px
    if not pd.api.types.is_datetime64_any_dtype(px["date"]):
        px["date"] = pd.to_datetime(px["date"])
    _blog("px ready")
    market_regime = _build_market_regime(px, cfg)
    market_regime.to_csv(output_dir / "backtest_market_regime.csv", index=False, encoding="utf-8-sig")
    market_by_date = market_regime.set_index("date_key").to_dict("index") if not market_regime.empty else {}
    codes_arr = px["stock_code"].astype(str).to_numpy()
    open_arr = pd.to_numeric(px["open"], errors="coerce").to_numpy(float)
    date_arr = pd.to_datetime(px["date"]).to_numpy()
    next_open_arr = np.full(len(px), np.nan, dtype=float)
    next_date_arr = np.empty(len(px), dtype="datetime64[ns]")
    next_date_arr[:] = np.datetime64("NaT")
    same_next = codes_arr[:-1] == codes_arr[1:]
    next_open_arr[:-1][same_next] = open_arr[1:][same_next]
    next_date_arr[:-1][same_next] = date_arr[1:][same_next]
    px["next_open"] = next_open_arr
    px["next_date"] = pd.to_datetime(next_date_arr)
    _blog("next fields")

    # 평가구간: 기본값 최근 3년. 이전 데이터는 지표 계산 warm-up에만 사용한다.
    if len(px):
        max_date = pd.Timestamp(date_arr[-1])
        if str(cfg.get("start_date", "")).strip():
            start_dt = pd.Timestamp(str(cfg.get("start_date")).strip())
        else:
            start_dt = max_date - pd.DateOffset(years=int(float(cfg.get("test_years", 3) or 3)))
        end_dt = pd.Timestamp(str(cfg.get("end_date")).strip()) if str(cfg.get("end_date", "")).strip() else max_date
    else:
        start_dt = end_dt = None

    if start_dt is not None:
        px_eval = px.loc[(px["date"] >= start_dt) & (px["date"] <= end_dt), [c for c in ["date", "stock_code", "market", "high", "low", "close", "volume", "trading_value", "ma20", "ma50", "ma120", "ma200", "ma50_slope20", "ma200_slope20", "atr20", "ret20", "ret60", "low120_prev", "high252_prev", "low252_prev", "vol20", "vol60"] if c in px.columns]].copy()
    else:
        px_eval = px[[c for c in ["date", "stock_code", "market", "high", "low", "close", "volume", "trading_value", "ma20", "ma50", "ma120", "ma200", "ma50_slope20", "ma200_slope20", "atr20", "ret20", "ret60", "low120_prev", "high252_prev", "low252_prev", "vol20", "vol60"] if c in px.columns]].copy()
    px_eval["date_key"] = px_eval["date"].dt.strftime("%Y-%m-%d")
    _blog(f"px eval {len(px_eval)}")

    # 빠른 가격 조회용 dict. 보유 포지션 수는 작기 때문에 전체 날짜×종목 매트릭스보다 dict가 단순하고 안정적이다.
    price_map: dict[tuple[str, str], dict[str, float]] = {}
    for r in px_eval.itertuples(index=False):
        rec = r._asdict()
        drec = {}
        for c in ["high", "low", "close", "volume", "trading_value", "ma20", "ma50", "ma120", "ma200", "ma50_slope20", "ma200_slope20", "atr20", "ret20", "ret60", "low120_prev", "high252_prev", "low252_prev", "vol20", "vol60"]:
            v = rec.get(c, np.nan)
            drec[c] = float(v) if pd.notna(v) else np.nan
        price_map[(rec["date_key"], rec["stock_code"])] = drec
    dates = sorted(px_eval["date_key"].dropna().unique().tolist())
    _blog(f"price map {len(price_map)} dates {len(dates)}")

    sig = signals.copy()
    if sig is not None and not sig.empty:
        sig["stock_code"] = sig["stock_code"].map(normalize_code)
        sig["date"] = pd.to_datetime(sig["date"])
        if start_dt is not None:
            sig = sig[(sig["date"] >= start_dt) & (sig["date"] <= end_dt)].copy()
        # next_open/next_date를 대형 merge 대신 key map으로 부착.
        _blog(f"sig start {len(sig)}")
        next_src = px[["date", "stock_code", "next_date", "next_open"]].dropna(subset=["next_date", "next_open"]).copy()
        next_src["date_key"] = next_src["date"].dt.strftime("%Y-%m-%d")
        next_src["key"] = next_src["date_key"] + "|" + next_src["stock_code"].astype(str)
        next_open_map = dict(zip(next_src["key"], pd.to_numeric(next_src["next_open"], errors="coerce")))
        next_date_map = dict(zip(next_src["key"], pd.to_datetime(next_src["next_date"]).dt.strftime("%Y-%m-%d")))
        sig["date_key"] = sig["date"].dt.strftime("%Y-%m-%d")
        sig["key"] = sig["date_key"] + "|" + sig["stock_code"].astype(str)
        sig["next_open"] = sig["key"].map(next_open_map)
        sig["next_date_key"] = sig["key"].map(next_date_map)
        sig = sig.dropna(subset=["next_open", "next_date_key"])
        sig = sig.sort_values(["next_date_key", "strategy_id", "signal_score", "trading_value"], ascending=[True, True, False, False])
        entries_by_date: dict[str, list[dict[str, Any]]] = {}
        for rec in sig.to_dict("records"):
            entries_by_date.setdefault(str(rec["next_date_key"]), []).append(rec)
        _blog(f"entries dates {len(entries_by_date)}")
    else:
        entries_by_date = {}

    _blog("loop start")
    for dkey in dates:
        regime = market_by_date.get(dkey, {"market_mode": "risk_on", "exposure_multiplier": 1.0})
        market_mode = str(regime.get("market_mode", "risk_on"))
        exposure_mult = float(regime.get("exposure_multiplier", 1.0) or 1.0)
        # exits
        for key, pos in list(positions.items()):
            row = price_map.get((dkey, pos.stock_code))
            if row is None:
                pos.days_held += 1
                continue
            close = row["close"]; high = row["high"]; low = row["low"]
            _update_risk_overlay_stop(pos, row, cfg)
            external_contributions_total = _try_capital_injection(
                pos, row, cfg, cash, initial_cash, external_contributions_total, contribution_rows, dkey, buy_fee, slip
            )
            exit_reason = None; exit_price = None
            if pd.Timestamp(dkey) > pd.Timestamp(pos.entry_date):
                # 보수적 체결: 당일 저가가 트레일링/손절선을 건드리면 손절 우선.
                if low <= pos.stop_loss:
                    exit_reason = "STOP"; exit_price = pos.stop_loss * (1 - slip)
                elif _as_bool(cfg.get("target_exit_enabled", True), True) and high >= pos.target_price:
                    exit_reason = "TARGET"; exit_price = pos.target_price * (1 - slip)
                else:
                    ex = cfg.get("strategy_exit", {}).get(pos.strategy_id, {})
                    max_days = int(ex.get("max_holding_days", 60))
                    ma50 = row.get("ma50", np.nan)
                    ma20 = row.get("ma20", np.nan)
                    fail_days = int((ro.get("breakout_fail_exit_days", {}) or {}).get(pos.strategy_id, 0) or 0)
                    pivot_price = float(pos.meta.get("pivot_price", np.nan))
                    if fail_days > 0 and pos.days_held <= fail_days and np.isfinite(pivot_price) and close < pivot_price * 0.995:
                        exit_reason = "BREAKOUT_FAIL"; exit_price = close * (1 - slip)
                    elif risk_overlay_enabled and _as_bool(ro.get("risk_off_defensive_exit", True), True) and market_mode == "risk_off" and close < pos.entry_price and np.isfinite(ma20) and close < ma20:
                        exit_reason = "MARKET_RISK_OFF"; exit_price = close * (1 - slip)
                    elif pos.days_held >= max_days:
                        exit_reason = "MAX_HOLD"; exit_price = close * (1 - slip)
                    elif pos.strategy_id == "stage2" and np.isfinite(ma50) and close < ma50 * 0.98:
                        exit_reason = "MA50_BREAK"; exit_price = close * (1 - slip)
            if exit_reason:
                gross = exit_price * pos.shares
                cost = gross * (sell_fee + tax)
                net = gross - cost
                cash[pos.strategy_id] += net
                invested = pos.entry_price * pos.shares
                pnl = net - invested
                trades.append({
                    "strategy_id": pos.strategy_id,
                    "strategy_name": STRATEGY_NAMES.get(pos.strategy_id, pos.strategy_id),
                    "stock_code": pos.stock_code,
                    "stock_name": pos.stock_name,
                    "entry_date": pd.Timestamp(pos.entry_date).strftime("%Y-%m-%d"),
                    "exit_date": dkey,
                    "entry_price": round(pos.entry_price, 4),
                    "exit_price": round(exit_price, 4),
                    "initial_stop_loss": round(pos.meta.get("initial_stop_loss", pos.stop_loss), 4) if isinstance(pos.meta, dict) else round(pos.stop_loss, 4),
                    "final_stop_loss": round(pos.stop_loss, 4),
                    "target_price": round(pos.target_price, 4),
                    "shares": int(pos.shares),
                    "gross_exit_value": round(gross, 2),
                    "costs": round(cost, 2),
                    "pnl": round(pnl, 2),
                    "return_pct": round(pnl / invested * 100 if invested else 0, 2),
                    "holding_days": int(pos.days_held),
                    "exit_reason": exit_reason,
                    "entry_type": pos.meta.get("entry_type", ""),
                    "entry_pivot_gap_pct": round(float(pos.meta.get("entry_pivot_gap_pct", np.nan)), 2) if isinstance(pos.meta, dict) else np.nan,
                    "signal_date": pos.meta.get("signal_date", "") if isinstance(pos.meta, dict) else "",
                })
                if cooldown_after_stop_days > 0 and exit_reason in {"STOP", "BREAKOUT_FAIL", "MARKET_RISK_OFF"}:
                    stop_cooldown[(pos.strategy_id, pos.stock_code)] = pd.Timestamp(dkey) + pd.Timedelta(days=cooldown_after_stop_days)
                del positions[key]
            else:
                pos.days_held += 1

        # entries
        for r in entries_by_date.get(dkey, []):
            sid = str(r["strategy_id"])
            code = normalize_code(r["stock_code"])
            key = (sid, code)
            if key in positions:
                continue
            if key in stop_cooldown and pd.Timestamp(dkey) <= stop_cooldown[key]:
                continue
            if risk_overlay_enabled and market_mode == "risk_off" and _as_bool(ro.get("block_new_entries_in_risk_off", True), True):
                if float(r.get("signal_score", 0) or 0) < float(ro.get("allow_exception_score_in_risk_off", 88)):
                    continue
            if risk_overlay_enabled and int(ro.get("max_total_open_positions", 0) or 0) > 0 and len(positions) >= int(ro.get("max_total_open_positions")):
                continue
            sid_positions = [p for p in positions.values() if p.strategy_id == sid]
            max_pos = int(max_positions.get(sid, 5))
            if len(sid_positions) >= max_pos:
                continue
            available_cash = cash.get(sid, 0.0)
            if available_cash <= 0:
                continue
            strategy_equity, current_pos_value, _ = _current_strategy_equity(sid, cash, positions, price_map, dkey)
            allowed_pos_value = strategy_equity * exposure_mult if risk_overlay_enabled else strategy_equity
            remaining_allowed = max(0.0, allowed_pos_value - current_pos_value)
            if remaining_allowed <= 0:
                continue
            budget = min(available_cash, strategy_equity / max_pos, remaining_allowed)
            buy_price = float(r["next_open"]) * (1 + slip)
            if not np.isfinite(buy_price) or buy_price <= 0:
                continue
            signal_stop = float(r.get("stop_loss", buy_price * 0.92))
            signal_target = float(r.get("target_price", buy_price * 1.20))
            stop, target, exit_policy_note = _apply_exit_price_policy(sid, buy_price, signal_stop, signal_target, cfg)
            risk_per_share = max(0.01, buy_price - stop)
            if risk_overlay_enabled and _as_bool(ro.get("use_risk_position_sizing", True), True):
                risk_map = ro.get("risk_per_trade_pct_of_strategy_equity", {}) or {}
                risk_budget = strategy_equity * float(risk_map.get(sid, 0.01))
                risk_budget = max(0.0, min(risk_budget, budget))
                risk_sized_budget = (risk_budget / risk_per_share) * buy_price if risk_per_share > 0 else budget
                budget = min(budget, risk_sized_budget)
            shares = int(budget / (buy_price * (1 + buy_fee)))
            if shares <= 0:
                continue
            gross = buy_price * shares
            cost = gross * buy_fee
            total = gross + cost
            if total > available_cash:
                continue
            cash[sid] -= total
            positions[key] = Position(
                strategy_id=sid,
                stock_code=code,
                stock_name=str(r.get("stock_name", code)),
                entry_date=pd.Timestamp(dkey),
                entry_price=buy_price,
                shares=shares,
                stop_loss=stop,
                target_price=target,
                days_held=0,
                highest_price=buy_price,
                highest_close=buy_price,
                initial_risk_per_share=risk_per_share,
                meta={"signal_date": str(r.get("date_key", "")), "signal_score": float(r.get("signal_score", 0)), "pivot_price": float(r.get("pivot_price", np.nan)), "entry_type": str(r.get("entry_type", "BREAKOUT")), "entry_pivot_gap_pct": float(r.get("pivot_gap_pct", np.nan)), "entry_quality_note": str(r.get("entry_quality_note", "")), "exit_policy": exit_policy_note, "initial_stop_loss": stop, "initial_position_value": gross, "capital_injection_tiers": [], "external_contribution": 0.0},
            )

        # equity
        pv_by_strategy = {sid: 0.0 for sid in weights}
        for pos in positions.values():
            row = price_map.get((dkey, pos.stock_code))
            close = row["close"] if row else pos.entry_price
            pv_by_strategy[pos.strategy_id] = pv_by_strategy.get(pos.strategy_id, 0.0) + close * pos.shares
        total_cash = sum(cash.values())
        total_pos = sum(pv_by_strategy.values())
        erow = {"date": dkey, "cash": total_cash, "position_value": total_pos, "portfolio_value": total_cash + total_pos, "open_positions": len(positions), "market_mode": market_mode, "exposure_multiplier": exposure_mult, "cumulative_external_contributions": external_contributions_total, "total_contributed_cash": initial_cash + external_contributions_total}
        for sid in weights:
            erow[f"{sid}_value"] = cash.get(sid, 0.0) + pv_by_strategy.get(sid, 0.0)
        equity_rows.append(erow)

    _blog("loop done")
    equity = pd.DataFrame(equity_rows)
    trades_df = pd.DataFrame(trades)
    contributions_df = pd.DataFrame(contribution_rows)
    if not contributions_df.empty:
        contributions_df.to_csv(output_dir / "backtest_capital_injections.csv", index=False, encoding="utf-8-sig")
    else:
        pd.DataFrame(columns=["date", "strategy_id", "stock_code", "contribution_cash", "health_score"]).to_csv(output_dir / "backtest_capital_injections.csv", index=False, encoding="utf-8-sig")
    summary = _metrics(equity, trades_df, initial_cash)
    if not trades_df.empty:
        by_strategy = []
        for sid in weights:
            g = trades_df[trades_df["strategy_id"] == sid]
            eq_col = f"{sid}_value"
            if eq_col not in equity:
                continue
            eq = equity[["date", eq_col]].rename(columns={eq_col: "portfolio_value"}).copy()
            by = _metrics(eq, g, initial_cash * float(weights.get(sid, 0)))
            if not by.empty:
                by.insert(0, "strategy_id", sid)
                by.insert(1, "strategy_name", STRATEGY_NAMES.get(sid, sid))
                by_strategy.append(by)
        strategy_summary = pd.concat(by_strategy, ignore_index=True) if by_strategy else pd.DataFrame()
    else:
        strategy_summary = pd.DataFrame()

    output_dir = Path(output_dir)
    benchmark_equity, benchmark_summary, excess_summary = _compute_benchmarks(px_eval, equity, cfg, initial_cash, output_dir)
    signals.to_csv(output_dir / "backtest_signals.csv", index=False, encoding="utf-8-sig")
    equity.to_csv(output_dir / "backtest_equity_curve.csv", index=False, encoding="utf-8-sig")
    trades_df.to_csv(output_dir / "backtest_trades.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(output_dir / "backtest_summary.csv", index=False, encoding="utf-8-sig")
    strategy_summary.to_csv(output_dir / "backtest_strategy_summary.csv", index=False, encoding="utf-8-sig")
    save_backtest_audit(signals, trades_df, equity, cfg, output_dir)
    save_algorithm_audit(cfg, output_dir)
    save_backtest_html(equity, trades_df, summary, strategy_summary, output_dir, benchmark_equity, benchmark_summary, excess_summary)
    return {"signals": signals, "equity": equity, "trades": trades_df, "summary": summary, "strategy_summary": strategy_summary, "benchmark_equity": benchmark_equity, "benchmark_summary": benchmark_summary, "excess_summary": excess_summary}

def _equity_svg(equity: pd.DataFrame, width: int = 920, height: int = 320) -> str:
    if equity is None or equity.empty:
        return "<div class='empty'>백테스트 그래프 데이터 없음</div>"
    vals = pd.to_numeric(equity["portfolio_value"], errors="coerce").to_numpy(float)
    vals = vals[np.isfinite(vals)]
    if len(vals) < 2:
        return "<div class='empty'>백테스트 그래프 데이터 부족</div>"
    left, right, top, bottom = 64, 24, 24, 48
    cw, ch = width - left - right, height - top - bottom
    ymin, ymax = float(vals.min()), float(vals.max())
    if ymax <= ymin:
        ymax = ymin + 1
    xs = np.linspace(left, left + cw, len(vals))
    ys = top + (ymax - vals) / (ymax - ymin) * ch
    points = " ".join(f"{x:.1f},{y:.1f}" for x, y in zip(xs, ys))
    return f"""
<svg viewBox='0 0 {width} {height}' class='eqsvg'>
<rect x='0' y='0' width='{width}' height='{height}' rx='16' fill='#f8fafc' stroke='#e5e7eb'/>
<line x1='{left}' y1='{top+ch}' x2='{left+cw}' y2='{top+ch}' stroke='#cbd5e1'/>
<line x1='{left}' y1='{top}' x2='{left}' y2='{top+ch}' stroke='#cbd5e1'/>
<line x1='{left}' y1='{top+ch*.33}' x2='{left+cw}' y2='{top+ch*.33}' stroke='#e5e7eb' stroke-dasharray='4 4'/>
<line x1='{left}' y1='{top+ch*.66}' x2='{left+cw}' y2='{top+ch*.66}' stroke='#e5e7eb' stroke-dasharray='4 4'/>
<polyline points='{points}' fill='none' stroke='#2563eb' stroke-width='3'/>
<text x='12' y='{top+8}' font-size='12' fill='#64748b'>{ymax:,.0f}</text>
<text x='12' y='{top+ch}' font-size='12' fill='#64748b'>{ymin:,.0f}</text>
<text x='{left}' y='{height-16}' font-size='12' fill='#64748b'>{equity['date'].iloc[0]}</text>
<text x='{left+cw-90}' y='{height-16}' font-size='12' fill='#64748b'>{equity['date'].iloc[-1]}</text>
</svg>"""





def save_algorithm_audit(cfg: dict[str, Any], output_dir: str | Path) -> Path:
    """4개 전략 구현 상태를 사람이 확인할 수 있게 CSV로 저장한다."""
    rows = [
        {
            "strategy_id": "vcp",
            "strategy_name": "Minervini VCP proxy",
            "implementation_status": "OHLCV 기반 핵심 구조 구현",
            "implemented_rules": "상승추세(50/150/200), 52주 고점 근접, 20/60일 변동성 수축, ATR 수축, 거래량 수축, 20일 피벗 돌파 및 거래량 증가",
            "backtest_rule": "신호일 종가가 20일 전고점 피벗을 돌파하고 다음 거래일 시가 진입",
            "known_limits": "원저자의 재량적 베이스 판독과 수축 횟수 수동 판정은 수치 규칙으로 근사",
            "verdict": "현재 OHLCV 데이터만으로 구현 가능한 범위에서는 의도와 잘 맞음",
        },
        {
            "strategy_id": "canslim",
            "strategy_name": "O'Neil CANSLIM proxy",
            "implementation_status": "가격/거래량 리더십 구현, 재무는 현재 분석에만 보조 반영",
            "implemented_rules": "신고가 근처, 60일 피벗 돌파, 상대강도, 거래량 증가, 50/150/200일 추세. financials.csv가 있으면 ROE/이익/성장률 보조 반영",
            "backtest_rule": "포인트인타임 분기 재무 데이터가 없으면 역사 백테스트는 가격/거래량 프록시만 사용해 look-ahead를 피함",
            "known_limits": "정확한 CANSLIM을 위해서는 financial_quarterly.csv의 분기별 매출/EPS YoY를 날짜별로 붙여야 함. 최신 financials.csv만 과거에 적용하면 미래정보 누수 위험",
            "verdict": "부분 구현. 현재 백테스트는 보수적으로 가격/거래량 프록시로 판단",
        },
        {
            "strategy_id": "stage2",
            "strategy_name": "Weinstein Stage2 proxy",
            "implementation_status": "주봉 30주선 기반 구조 구현",
            "implemented_rules": "주봉 30주선 위, 30주선 기울기, 일봉 150/200일 추세, 120일 저항 돌파, 거래량 증가, 상대강도",
            "backtest_rule": "주봉은 확정된 최근 금요일 기준으로 병합하고 120일 피벗 돌파 후 다음 거래일 시가 진입",
            "known_limits": "상대강도선 차트의 수동 판독은 수치 상대강도로 근사",
            "verdict": "현재 4전략 중 원형과 가장 가깝고 백테스트 안정성도 비교적 높음. 장기 스윙 프로필에서는 진입 신호는 유지하고 목표가/보유기간만 크게 확장",
        },
        {
            "strategy_id": "darvas",
            "strategy_name": "Darvas Box proxy",
            "implementation_status": "박스 돌파/박스 하단 손절 구조 구현",
            "implemented_rules": "20일 박스 상단 돌파, 박스폭 축소, 50일선 위, 거래량 증가, 박스 하단 손절, 박스폭 기반 목표가",
            "backtest_rule": "20일 피벗 돌파 후 다음 거래일 시가 진입, 박스 하단/손절선 우선 청산",
            "known_limits": "Darvas의 뉴스/거래량 재량 판단 및 박스 재정의는 자동 규칙으로 근사",
            "verdict": "구조는 맞지만 최근 데이터 단독 성과가 약해 비중은 낮게 유지 권장",
        },
        {
            "strategy_id": "deep_turnaround",
            "strategy_name": "Deep Turnaround 10x proxy",
            "implementation_status": "저점 회복형 별도 알고리즘 구현",
            "implemented_rules": "52주 고점 대비 -45~-93% 낙폭, 120/252일 저점 대비 회복, 50/120/200일선 회복 조짐, 거래량·상대강도 회복, 120일 고점 또는 200일선 회복 돌파",
            "backtest_rule": "거짓 저점 필터를 통과하고 장기 저항/200일선 회복 피벗 돌파 시 다음 거래일 시가 진입",
            "known_limits": "10배는 고정 목표가보다 장기 추적/트레일링 성격이 강함. Point-in-time 재무 데이터가 부족하면 재무 생존력은 보수적 중립 처리",
            "verdict": "기존 4전략을 건드리지 않는 고위험 장기 옵션형 전략. 종목당 비중은 작게 운용 권장",
        },
    ]
    rows.append({
        "strategy_id": "EXIT_PROFILE",
        "strategy_name": str(cfg.get("exit_profile_mode", cfg.get("profile_name", ""))),
        "implementation_status": "청산 프로필 잠금",
        "implemented_rules": "손절비/손익비를 임의 숫자로 섞지 않고 원형 유지·장기 스윙·공격형·10x 실험 프로필로 분리",
        "backtest_rule": f"target_exit_enabled={cfg.get('target_exit_enabled', True)}; exit_target_mode={cfg.get('exit_target_mode', '')}; stop_loss_mode={cfg.get('stop_loss_mode', '')}",
        "known_limits": "사용자 커스텀 숫자 변경은 원형 훼손 가능성이 있어 프로필 단위로만 권장",
        "verdict": "원형 보호 적용"
    })
    audit = pd.DataFrame(rows)
    path = Path(output_dir) / "algorithm_audit.csv"
    audit.to_csv(path, index=False, encoding="utf-8-sig")
    return path

def save_backtest_audit(signals: pd.DataFrame, trades: pd.DataFrame, equity: pd.DataFrame, cfg: dict[str, Any], output_dir: str | Path) -> Path:
    """백테스트가 실제 과거 구간에서 어떻게 실행됐는지 확인하는 감사 로그를 저장한다."""
    output_dir = Path(output_dir)
    rows = []
    if equity is not None and not equity.empty:
        rows.append({"item": "equity_start", "value": str(equity["date"].iloc[0])})
        rows.append({"item": "equity_end", "value": str(equity["date"].iloc[-1])})
        rows.append({"item": "equity_rows", "value": len(equity)})
    rows += [
        {"item": "test_years", "value": cfg.get("test_years", "")},
        {"item": "start_date_config", "value": cfg.get("start_date", "")},
        {"item": "end_date_config", "value": cfg.get("end_date", "")},
        {"item": "enabled_strategies", "value": ",".join(cfg.get("enabled_strategies", []))},
        {"item": "exit_profile_mode", "value": cfg.get("exit_profile_mode", "")},
        {"item": "profile_name", "value": cfg.get("profile_name", "")},
        {"item": "target_exit_enabled", "value": cfg.get("target_exit_enabled", True)},
        {"item": "max_backtest_symbols", "value": cfg.get("max_backtest_symbols", "")},
        {"item": "min_trading_value", "value": cfg.get("min_trading_value", "")},
        {"item": "execution_rule", "value": "signal close confirmed at t, buy next trading day's open"},
        {"item": "stop_target_rule", "value": "daily low/high fill, stop first if both stop and target hit"},
    ]
    if signals is not None and not signals.empty and "date" in signals:
        ds = pd.to_datetime(signals["date"], errors="coerce").dropna()
        rows.append({"item": "signal_count", "value": len(signals)})
        rows.append({"item": "first_signal_date", "value": ds.min().strftime("%Y-%m-%d") if len(ds) else ""})
        rows.append({"item": "last_signal_date", "value": ds.max().strftime("%Y-%m-%d") if len(ds) else ""})
    else:
        rows.append({"item": "signal_count", "value": 0})
    if trades is not None and not trades.empty and "entry_date" in trades:
        de = pd.to_datetime(trades["entry_date"], errors="coerce").dropna()
        dx = pd.to_datetime(trades["exit_date"], errors="coerce").dropna() if "exit_date" in trades else pd.Series(dtype="datetime64[ns]")
        rows.append({"item": "trade_count", "value": len(trades)})
        rows.append({"item": "first_entry_date", "value": de.min().strftime("%Y-%m-%d") if len(de) else ""})
        rows.append({"item": "last_entry_date", "value": de.max().strftime("%Y-%m-%d") if len(de) else ""})
        rows.append({"item": "last_exit_date", "value": dx.max().strftime("%Y-%m-%d") if len(dx) else ""})
    else:
        rows.append({"item": "trade_count", "value": 0})
    audit = pd.DataFrame(rows)
    path = output_dir / "backtest_audit.csv"
    audit.to_csv(path, index=False, encoding="utf-8-sig")
    return path

def save_backtest_html(equity: pd.DataFrame, trades: pd.DataFrame, summary: pd.DataFrame, strategy_summary: pd.DataFrame, output_dir: str | Path, benchmark_equity: pd.DataFrame | None = None, benchmark_summary: pd.DataFrame | None = None, excess_summary: pd.DataFrame | None = None) -> Path:
    output_dir = Path(output_dir)
    s = summary.iloc[0].to_dict() if summary is not None and not summary.empty else {}
    cards = "".join([f"<div class='card'><b>{k}</b><span>{v:.2f}</span></div>" for k, v in s.items() if isinstance(v, (int, float, np.floating)) and np.isfinite(v)])
    st_rows = ""
    if strategy_summary is not None and not strategy_summary.empty:
        for _, r in strategy_summary.iterrows():
            st_rows += f"<tr><td>{r.get('strategy_name','')}</td><td>{r.get('total_return_pct',0):.2f}%</td><td>{r.get('mdd_pct',0):.2f}%</td><td>{r.get('trades',0)}</td><td>{r.get('win_rate_pct',0):.2f}%</td><td>{r.get('profit_factor',0):.2f}</td></tr>"
    bench_rows = ""
    if excess_summary is not None and not excess_summary.empty:
        for _, r in excess_summary.iterrows():
            bench_rows += f"<tr><td>{r.get('benchmark_name','')}</td><td>{r.get('benchmark_total_return_pct',np.nan):.2f}%</td><td>{r.get('excess_total_return_pct',np.nan):.2f}%</td><td>{r.get('benchmark_mdd_pct',np.nan):.2f}%</td><td>{r.get('mdd_advantage_pct',np.nan):.2f}%</td><td>{r.get('benchmark_sharpe',np.nan):.2f}</td><td>{r.get('sharpe_diff',np.nan):.2f}</td></tr>"
    entry_filter_path = Path(output_dir) / "backtest_entry_filter_audit.csv"
    entry_filter_rows = ""
    try:
        efa = pd.read_csv(entry_filter_path) if entry_filter_path.exists() else pd.DataFrame()
        if not efa.empty:
            for _, r in efa.groupby(["strategy_id", "entry_type", "reason"], dropna=False)["excluded"].sum().reset_index().iterrows():
                entry_filter_rows += f"<tr><td>{r.get('strategy_id','')}</td><td>{r.get('entry_type','')}</td><td>{r.get('reason','')}</td><td>{int(r.get('excluded',0))}</td></tr>"
    except Exception:
        entry_filter_rows = ""
    entry_filter_panel = f"""<div class='panel'><h2>추격매수 제외 감사</h2><p>피벗 과이격, 이동평균선 과이격, 최근 급등, 손절폭 과다, 한국 시장 상한가성 급등 추격을 제외한 횟수입니다.</p><table><thead><tr><th>전략</th><th>진입유형</th><th>제외 사유</th><th>제외 수</th></tr></thead><tbody>{entry_filter_rows if entry_filter_rows else '<tr><td colspan=4>제외 내역 없음</td></tr>'}</tbody></table><p><a href='backtest_entry_filter_audit.csv'>entry filter audit CSV</a></p></div>"""
    bench_panel = f"""<div class='panel'><h2>벤치마크 비교</h2><p>벤치마크는 같은 백테스트 유니버스와 같은 평가구간에서 계산한 동일가중 proxy입니다. KOSPI/KOSDAQ proxy는 CSV의 market 컬럼 기준이며 공식 지수 자체는 아닙니다.</p><table><thead><tr><th>벤치마크</th><th>벤치 수익률</th><th>초과수익</th><th>벤치 MDD</th><th>MDD 우위</th><th>벤치 Sharpe</th><th>Sharpe 차이</th></tr></thead><tbody>{bench_rows if bench_rows else '<tr><td colspan=7>벤치마크 데이터 없음</td></tr>'}</tbody></table><p><a href='backtest_benchmark_equity.csv'>benchmark equity CSV</a> · <a href='backtest_benchmark_summary.csv'>benchmark summary CSV</a> · <a href='backtest_excess_summary.csv'>excess summary CSV</a></p></div>"""
    html = f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>백테스트 결과</title>
<style>body{{margin:0;background:#f6f7fb;color:#172033;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif}}.wrap{{max-width:1100px;margin:0 auto;padding:28px 18px 60px}}.hero{{background:linear-gradient(135deg,#111827,#1d4ed8);color:white;border-radius:24px;padding:28px}}.grid{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:18px 0}}.card{{background:white;border:1px solid #e5e7eb;border-radius:16px;padding:14px}}.card b{{display:block;color:#64748b;font-size:12px}}.card span{{font-size:20px;font-weight:800}}.panel{{background:white;border:1px solid #e5e7eb;border-radius:18px;padding:18px;margin:16px 0;box-shadow:0 8px 24px rgba(15,23,42,.06)}}table{{width:100%;border-collapse:collapse}}td,th{{border-bottom:1px solid #e5e7eb;padding:10px;text-align:left}}a{{color:#2563eb;font-weight:800;text-decoration:none}}.eqsvg{{width:100%;height:auto}}</style></head><body><main class='wrap'>
<section class='hero'><h1>멀티 전략 백테스트 결과</h1><p>신호일 종가 확정 후 다음 거래일 시가 진입, 슬리피지/수수료/거래세 반영. 같은 날 손절·익절 동시 도달 시 손절 우선.</p></section>
<div class='grid'>{cards}</div><div class='panel'>{_equity_svg(equity)}</div><div class='panel'><h2>전략별 성과</h2><table><thead><tr><th>전략</th><th>수익률</th><th>MDD</th><th>거래수</th><th>승률</th><th>PF</th></tr></thead><tbody>{st_rows}</tbody></table></div>
{bench_panel}
{entry_filter_panel}
<div class='panel'><h2>검증 파일</h2><p>신호 수, 첫 진입일, 마지막 진입일 등은 audit CSV에서 확인할 수 있습니다.</p><a href='backtest_audit.csv'>audit CSV</a> · <a href='backtest_equity_curve.csv'>equity CSV</a> · <a href='backtest_trades.csv'>trades CSV</a> · <a href='backtest_summary.csv'>summary CSV</a> · <a href='backtest_signals.csv'>signals CSV</a> · <a href='backtest_market_regime.csv'>market regime CSV</a></div>
</main></body></html>"""
    path = output_dir / "backtest_report.html"
    path.write_text(html, encoding="utf-8")
    return path
