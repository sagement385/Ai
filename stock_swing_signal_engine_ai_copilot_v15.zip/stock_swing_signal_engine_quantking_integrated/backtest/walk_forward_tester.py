"""walk_forward_tester.py - 간단한 walk-forward 검증 골격."""
from __future__ import annotations
import pandas as pd


def split_walk_forward_dates(prices: pd.DataFrame, train_days: int = 500, test_days: int = 120) -> list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp, pd.Timestamp]]:
    dates = sorted(pd.to_datetime(prices["date"]).drop_duplicates())
    out = []
    i = 0
    while i + train_days + test_days <= len(dates):
        out.append((dates[i], dates[i + train_days - 1], dates[i + train_days], dates[i + train_days + test_days - 1]))
        i += test_days
    return out
