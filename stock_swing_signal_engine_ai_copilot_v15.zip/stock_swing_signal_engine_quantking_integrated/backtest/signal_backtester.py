"""signal_backtester.py - 특정 날짜의 점수표가 이후 수익률을 냈는지 검증."""
from __future__ import annotations
import pandas as pd
from validation.feature_validity_checker import future_return_table
from backtest.performance_metrics import summarize_returns


def backtest_topk(prices: pd.DataFrame, rankings: pd.DataFrame, k: int = 10, horizon: int = 60) -> dict:
    top = rankings.sort_values("final_score", ascending=False).head(k).copy()
    table = future_return_table(prices, top, horizon=horizon)
    return summarize_returns(table["future_return"])
