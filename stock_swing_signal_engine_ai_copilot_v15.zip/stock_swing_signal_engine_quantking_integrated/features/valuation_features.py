"""
valuation_features.py

재무·밸류에이션 feature.
이 프로그램에서 밸류는 단독 추천 신호가 아니라, 횡보/수급이 받쳐줄 때 의미 있는 보조 신호다.
"""
from __future__ import annotations
import pandas as pd
import numpy as np


def compute_valuation_features(financials: pd.DataFrame) -> pd.DataFrame:
    if financials is None or financials.empty:
        return pd.DataFrame(columns=["stock_code", "per", "pbr", "roe", "debt_ratio", "market_cap", "valuation_data_available"])
    df = financials.copy()
    rename = {"PER": "per", "PBR": "pbr", "ROE": "roe"}
    df = df.rename(columns=rename)
    for col in ["per", "pbr", "roe", "debt_ratio", "market_cap", "operating_profit", "net_income"]:
        if col not in df.columns: df[col] = pd.NA
        df[col] = pd.to_numeric(df[col], errors="coerce")
    out = df[["stock_code", "per", "pbr", "roe", "debt_ratio", "market_cap", "operating_profit", "net_income"]].copy()
    out["valuation_data_available"] = True
    return out
