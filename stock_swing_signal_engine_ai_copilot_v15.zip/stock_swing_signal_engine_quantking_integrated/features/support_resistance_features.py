"""
support_resistance_features.py

De Angelis & Peskir: 지지·저항을 가격 장벽으로 해석.
Tengelin & Sopasakis: 가격 클러스터링으로 지지·저항 가격대를 추정.

일봉 기반 간소화:
- 최근 120일 가격을 bin으로 나눔
- 체류일수와 거래량이 큰 가격대를 support/resistance 후보로 본다
- 현재가 아래의 가장 강한 클러스터를 support로 사용
"""
from __future__ import annotations
import pandas as pd
import numpy as np


def _one_stock_sr(grp: pd.DataFrame, bins: int = 16) -> dict:
    grp = grp.sort_values("date").tail(120).copy()
    code = grp["stock_code"].iloc[-1]
    close = float(grp["close"].iloc[-1])
    if len(grp) < 30 or grp["close"].max() == grp["close"].min():
        return {"stock_code": code, "support_level": np.nan, "resistance_level": np.nan, "support_distance": np.nan, "support_strength": 0, "resistance_distance": np.nan, "breakdown_failure_count": 0}
    low, high = float(grp["low"].min()), float(grp["high"].max())
    edges = np.linspace(low, high, bins + 1)
    centers = (edges[:-1] + edges[1:]) / 2
    grp["bin"] = pd.cut(grp["close"], bins=edges, labels=False, include_lowest=True)
    stats = grp.groupby("bin", observed=True).agg(days=("close", "size"), volume=("volume", "sum")).reset_index()
    stats["center"] = stats["bin"].apply(lambda i: centers[int(i)] if pd.notna(i) else np.nan)
    stats["strength"] = stats["days"] / stats["days"].max() * 0.55 + stats["volume"] / max(stats["volume"].max(), 1) * 0.45
    below = stats[stats["center"] <= close]
    above = stats[stats["center"] > close]
    support = below.sort_values(["strength", "center"], ascending=[False, False]).head(1)
    resistance = above.sort_values(["strength", "center"], ascending=[False, True]).head(1)
    support_level = float(support["center"].iloc[0]) if not support.empty else np.nan
    resistance_level = float(resistance["center"].iloc[0]) if not resistance.empty else np.nan
    support_strength = float(support["strength"].iloc[0] * 100) if not support.empty else 0.0
    # 지지선 이탈 후 회복: low가 support 아래로 갔다가 close가 support 위로 회복한 날
    if np.isfinite(support_level):
        breakdown_failure_count = int(((grp["low"] < support_level * 0.985) & (grp["close"] > support_level)).sum())
        support_distance = (close - support_level) / close if close else np.nan
    else:
        breakdown_failure_count, support_distance = 0, np.nan
    resistance_distance = (resistance_level - close) / close if np.isfinite(resistance_level) and close else np.nan
    return {
        "stock_code": code,
        "support_level": support_level,
        "resistance_level": resistance_level,
        "support_distance": support_distance,
        "support_strength": support_strength,
        "resistance_distance": resistance_distance,
        "breakdown_failure_count": breakdown_failure_count,
    }


def compute_support_resistance_features(prices: pd.DataFrame) -> pd.DataFrame:
    rows = [_one_stock_sr(g) for _, g in prices.groupby("stock_code")]
    return pd.DataFrame(rows)
