"""
fibonacci_angle_features.py

피보나치/빗각은 메인 신호가 아니라 6순위 보조 확인용이다.

논문/개념 연결:
- Tsinaslanidis & Guijarro: 피보나치 되돌림은 사람이 임의로 긋지 않고 swing high/low를 자동 탐지해 zone으로 평가해야 한다.
- Lo, Mamaysky & Wang: 가격 노이즈를 줄이고 local high/low 구조를 추출해 기술적 패턴을 계량화한다.
- Trendline / support-resistance 문헌: 대각 추세선은 단독 매수 신호가 아니라 지지·저항, 횡보, 수급 조건과 결합될 때만 보조 신뢰도를 준다.

구현 원칙:
- 피보나치 zone 근접만으로는 높은 점수를 주지 않는다.
- 가격 클러스터/지지선/횡보장/수급 조건과 최종 랭킹에서 결합될 때만 소폭 가산된다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

FIB_RATIOS = (0.382, 0.5, 0.618, 0.786)


def _safe_float(x, default=np.nan):
    try:
        if pd.isna(x):
            return default
        return float(x)
    except Exception:
        return default


def _local_extrema(series: pd.Series, mode: str = "min", window: int = 2) -> np.ndarray:
    """간단한 local high/low index 추출. 데이터가 부족하면 빈 배열을 반환한다."""
    vals = series.to_numpy(dtype=float)
    idxs: list[int] = []
    if len(vals) < window * 2 + 1:
        return np.array(idxs, dtype=int)
    for i in range(window, len(vals) - window):
        chunk = vals[i - window:i + window + 1]
        if mode == "min" and vals[i] == np.nanmin(chunk):
            if np.isfinite(vals[i]):
                idxs.append(i)
        if mode == "max" and vals[i] == np.nanmax(chunk):
            if np.isfinite(vals[i]):
                idxs.append(i)
    return np.array(idxs, dtype=int)


def _linear_fit_score(x: np.ndarray, y: np.ndarray) -> tuple[float, float, float]:
    """slope, intercept, r2 반환."""
    if len(x) < 2 or len(y) < 2:
        return np.nan, np.nan, 0.0
    try:
        slope, intercept = np.polyfit(x, y, 1)
        pred = slope * x + intercept
        ss_res = float(np.sum((y - pred) ** 2))
        ss_tot = float(np.sum((y - np.mean(y)) ** 2))
        r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
        return float(slope), float(intercept), float(np.clip(r2, 0, 1))
    except Exception:
        return np.nan, np.nan, 0.0


def _one_stock_fib_angle(grp: pd.DataFrame, lookback: int = 120) -> dict:
    g = grp.sort_values("date").tail(lookback).copy()
    code = str(g["stock_code"].iloc[-1]).zfill(6)
    if len(g) < 40:
        return {
            "stock_code": code,
            "fib_nearest_ratio": np.nan,
            "fib_distance": np.nan,
            "fib_zone_score_raw": 0.0,
            "low_trend_slope_norm": np.nan,
            "high_trend_slope_norm": np.nan,
            "low_trend_r2": 0.0,
            "high_trend_r2": 0.0,
            "low_trend_distance": np.nan,
            "channel_convergence": 0.0,
            "angle_score_raw": 0.0,
        }

    close = _safe_float(g["close"].iloc[-1])
    low_price = _safe_float(g["low"].min())
    high_price = _safe_float(g["high"].max())
    if not np.isfinite(close) or close <= 0 or not np.isfinite(low_price) or not np.isfinite(high_price) or high_price <= low_price:
        fib_ratio, fib_dist, fib_raw = np.nan, np.nan, 0.0
    else:
        levels = {ratio: high_price - ratio * (high_price - low_price) for ratio in FIB_RATIOS}
        dists = {ratio: abs(close - level) / close for ratio, level in levels.items()}
        fib_ratio = min(dists, key=dists.get)
        fib_dist = float(dists[fib_ratio])
        # 0~2.5% 이내만 보조 의미. 너무 멀면 0점.
        fib_raw = float(np.clip(1 - fib_dist / 0.025, 0, 1) * 100)

    lows = g["low"].reset_index(drop=True)
    highs = g["high"].reset_index(drop=True)
    low_idx = _local_extrema(lows, mode="min", window=2)
    high_idx = _local_extrema(highs, mode="max", window=2)
    # local extrema가 너무 적으면 최근 n등분 지점의 rolling min/max로 보완
    if len(low_idx) < 3:
        low_idx = lows.rolling(5, min_periods=3).mean().nsmallest(min(5, len(lows))).index.to_numpy()
        low_idx = np.sort(low_idx)
    if len(high_idx) < 3:
        high_idx = highs.rolling(5, min_periods=3).mean().nlargest(min(5, len(highs))).index.to_numpy()
        high_idx = np.sort(high_idx)

    # 최근 8개 extrema만 사용해 현재 구조를 반영
    low_idx = low_idx[-8:]
    high_idx = high_idx[-8:]
    low_slope, low_intercept, low_r2 = _linear_fit_score(low_idx.astype(float), lows.iloc[low_idx].to_numpy(dtype=float))
    high_slope, high_intercept, high_r2 = _linear_fit_score(high_idx.astype(float), highs.iloc[high_idx].to_numpy(dtype=float))

    last_x = len(g) - 1
    low_pred = low_slope * last_x + low_intercept if np.isfinite(low_slope) and np.isfinite(low_intercept) else np.nan
    high_pred = high_slope * last_x + high_intercept if np.isfinite(high_slope) and np.isfinite(high_intercept) else np.nan
    low_dist = (close - low_pred) / close if np.isfinite(low_pred) and close else np.nan
    high_dist = (high_pred - close) / close if np.isfinite(high_pred) and close else np.nan
    low_slope_norm = low_slope / close if np.isfinite(low_slope) and close else np.nan
    high_slope_norm = high_slope / close if np.isfinite(high_slope) and close else np.nan

    # 장기 스윙 관점에서 좋은 빗각: 저점선이 완만히 상승 또는 평탄, 현재가가 저점선에서 0~8% 위.
    angle_score = 0.0
    if np.isfinite(low_slope_norm):
        if low_slope_norm >= -0.0004:  # 강한 하락 저점선은 제외
            angle_score += 28
        if 0 <= low_slope_norm <= 0.0025:
            angle_score += 16
    if np.isfinite(low_dist):
        if 0 <= low_dist <= 0.08:
            angle_score += 30 * (1 - low_dist / 0.08)
        elif low_dist < 0:
            angle_score -= 12
    angle_score += min(low_r2, 1.0) * 16

    # 고점선이 낮아지거나 평탄하면서 저점선이 유지되면 수렴/압축 구조로 약간 가산
    convergence = 0.0
    if np.isfinite(low_slope_norm) and np.isfinite(high_slope_norm):
        if high_slope_norm <= 0.0005 and low_slope_norm >= -0.0004:
            convergence = 1.0
            angle_score += 10
        if np.isfinite(high_dist) and high_dist > 0.06:
            angle_score += 4  # 위쪽 공간

    return {
        "stock_code": code,
        "fib_nearest_ratio": fib_ratio,
        "fib_distance": fib_dist,
        "fib_zone_score_raw": float(np.clip(fib_raw, 0, 100)),
        "low_trend_slope_norm": low_slope_norm,
        "high_trend_slope_norm": high_slope_norm,
        "low_trend_r2": low_r2,
        "high_trend_r2": high_r2,
        "low_trend_distance": low_dist,
        "channel_convergence": convergence,
        "angle_score_raw": float(np.clip(angle_score, 0, 100)),
    }


def compute_fibonacci_angle_features(prices: pd.DataFrame, lookback: int = 120) -> pd.DataFrame:
    rows = [_one_stock_fib_angle(g, lookback=lookback) for _, g in prices.groupby("stock_code")]
    return pd.DataFrame(rows)
