"""
sideways_features.py

Brock et al.의 trading range / moving average 규칙과 Lo et al.의 기술적 패턴 자동인식 개념을 반영한다.
핵심은 사람이 보는 횡보를 수식화하는 것:
- N일 고저폭
- 이동평균선 수렴
- 박스권 내 현재 위치
- 박스권 지속성
"""
from __future__ import annotations
import pandas as pd
import numpy as np


def compute_sideways_features(prices: pd.DataFrame) -> pd.DataFrame:
    df = prices.sort_values(["stock_code", "date"]).copy()
    g = df.groupby("stock_code")
    for n in [20, 60, 120]:
        df[f"ma_{n}"] = g["close"].transform(lambda s: s.rolling(n, min_periods=max(5, n//3)).mean())
        df[f"high_{n}"] = g["high"].transform(lambda s: s.rolling(n, min_periods=max(5, n//3)).max())
        df[f"low_{n}"] = g["low"].transform(lambda s: s.rolling(n, min_periods=max(5, n//3)).min())
    df["range_width_60"] = (df["high_60"] - df["low_60"]) / df["close"].replace(0, np.nan)
    df["range_width_120"] = (df["high_120"] - df["low_120"]) / df["close"].replace(0, np.nan)
    df["ma_convergence"] = df[["ma_20", "ma_60", "ma_120"]].std(axis=1) / df["close"].replace(0, np.nan)
    df["box_position_120"] = (df["close"] - df["low_120"]) / (df["high_120"] - df["low_120"]).replace(0, np.nan)
    # 최근 60일 중 120일 박스권 내부에 머문 비율
    df["inside_box"] = ((df["close"] >= df["low_120"]) & (df["close"] <= df["high_120"])).astype(int)
    df["box_persistence_60"] = g["inside_box"].transform(lambda s: s.rolling(60, min_periods=20).mean())
    latest = df.groupby("stock_code").tail(1)[["stock_code", "range_width_60", "range_width_120", "ma_convergence", "box_position_120", "box_persistence_60"]]
    return latest.reset_index(drop=True)
