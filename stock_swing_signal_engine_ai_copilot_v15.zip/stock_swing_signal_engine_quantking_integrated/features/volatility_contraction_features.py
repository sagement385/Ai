"""
volatility_contraction_features.py

Cont의 volatility clustering, MMAR의 다중 시간축 변동성 관점을 단순 feature로 구현.
장기 스윙에서는 변동성 폭발보다 변동성 수축과 안정성을 선호한다.
"""
from __future__ import annotations
import pandas as pd
import numpy as np


def compute_volatility_contraction_features(prices: pd.DataFrame) -> pd.DataFrame:
    df = prices.sort_values(["stock_code", "date"]).copy()
    prev_close = df.groupby("stock_code")["close"].shift(1)
    tr = pd.concat([
        (df["high"] - df["low"]).abs(),
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)
    df["tr"] = tr
    g = df.groupby("stock_code")
    df["atr_20"] = g["tr"].transform(lambda s: s.rolling(20, min_periods=10).mean())
    df["atr_60"] = g["tr"].transform(lambda s: s.rolling(60, min_periods=20).mean())
    df["atr_ratio_20_60"] = df["atr_20"] / df["atr_60"].replace(0, np.nan)
    ma20 = g["close"].transform(lambda s: s.rolling(20, min_periods=10).mean())
    std20 = g["close"].transform(lambda s: s.rolling(20, min_periods=10).std())
    df["bb_width_20"] = (4 * std20) / ma20.replace(0, np.nan)
    df["bb_width_60_avg"] = g["bb_width_20"].transform(lambda s: s.rolling(60, min_periods=20).mean())
    df["bb_contraction"] = df["bb_width_20"] / df["bb_width_60_avg"].replace(0, np.nan)
    latest = df.groupby("stock_code").tail(1)[["stock_code", "atr_ratio_20_60", "bb_width_20", "bb_contraction"]]
    return latest.reset_index(drop=True)
