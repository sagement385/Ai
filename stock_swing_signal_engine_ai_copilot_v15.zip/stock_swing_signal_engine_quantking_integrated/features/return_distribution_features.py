"""
return_distribution_features.py

Mandelbrot / Cont 기반:
- 수익률은 정규분포보다 극단값이 자주 나타난다.
- 변동성 군집은 위험 신호다.
이 파일은 매수 신호가 아니라 risk_score의 원천 feature를 만든다.
"""
from __future__ import annotations
import pandas as pd
import numpy as np


def compute_return_distribution_features(prices: pd.DataFrame) -> pd.DataFrame:
    df = prices.sort_values(["stock_code", "date"]).copy()
    g = df.groupby("stock_code")
    df["log_return"] = g["close"].transform(lambda s: np.log(s / s.shift(1)))
    df["ret_20"] = g["close"].pct_change(20)
    df["ret_60"] = g["close"].pct_change(60)
    df["vol_20"] = g["log_return"].transform(lambda s: s.rolling(20, min_periods=10).std())
    df["vol_60"] = g["log_return"].transform(lambda s: s.rolling(60, min_periods=20).std())
    df["kurt_60"] = g["log_return"].transform(lambda s: s.rolling(60, min_periods=30).kurt())
    df["extreme_day"] = (df["log_return"].abs() > (df["vol_60"].fillna(df["vol_20"]) * 2.5)).astype(int)
    df["extreme_days_60"] = g["extreme_day"].transform(lambda s: s.rolling(60, min_periods=20).sum())
    df["vol_cluster_ratio"] = df["vol_20"] / df["vol_60"].replace(0, np.nan)
    latest = df.groupby("stock_code").tail(1)[["stock_code", "ret_20", "ret_60", "vol_20", "vol_60", "kurt_60", "extreme_days_60", "vol_cluster_ratio"]]
    return latest.reset_index(drop=True)
