"""
accumulation_features.py

조용한 매집 feature.
Gabaix et al. + Chordia et al. 관점:
- 큰돈의 유입은 거래대금 대비 비율로 정규화해야 한다.
- 장기 스윙에서는 '수급 유입 + 가격 횡보' 조합이 핵심이다.
"""
from __future__ import annotations
import pandas as pd
import numpy as np


def compute_accumulation_features(prices: pd.DataFrame, supply_features: pd.DataFrame | None = None) -> pd.DataFrame:
    df = prices.sort_values(["stock_code", "date"]).copy()
    g = df.groupby("stock_code")
    df["ret_1"] = g["close"].pct_change()
    df["obv_step"] = np.where(df["ret_1"] > 0, df["volume"], np.where(df["ret_1"] < 0, -df["volume"], 0))
    df["obv"] = g["obv_step"].cumsum()
    df["obv_ma_20"] = g["obv"].transform(lambda s: s.rolling(20, min_periods=5).mean())
    df["obv_ma_60"] = g["obv"].transform(lambda s: s.rolling(60, min_periods=20).mean())
    df["up_volume"] = np.where(df["ret_1"] > 0, df["volume"], 0)
    df["down_volume"] = np.where(df["ret_1"] < 0, df["volume"], 0)
    df["up_volume_20"] = g["up_volume"].transform(lambda s: s.rolling(20, min_periods=5).sum())
    df["down_volume_20"] = g["down_volume"].transform(lambda s: s.rolling(20, min_periods=5).sum())
    df["up_down_volume_ratio_20"] = df["up_volume_20"] / df["down_volume_20"].replace(0, np.nan)
    df["price_return_60"] = g["close"].pct_change(60)
    df["low_60"] = g["low"].transform(lambda s: s.rolling(60, min_periods=20).min())
    df["low_20"] = g["low"].transform(lambda s: s.rolling(20, min_periods=10).min())
    df["higher_low"] = (df["low_20"] > df["low_60"] * 1.02).astype(float)
    latest = df.groupby("stock_code").tail(1)[["stock_code", "obv", "obv_ma_20", "obv_ma_60", "up_down_volume_ratio_20", "price_return_60", "higher_low"]].copy()
    latest["obv_trend_positive"] = (latest["obv_ma_20"] > latest["obv_ma_60"]).astype(float)
    if supply_features is not None and not supply_features.empty:
        sf = supply_features[["stock_code", "inst_buy_ratio_20", "foreign_buy_ratio_20", "inst_persistence_20", "foreign_persistence_20", "supply_data_available"]].copy()
        latest = latest.merge(sf, on="stock_code", how="left")
    else:
        latest["inst_buy_ratio_20"] = 0.0
        latest["foreign_buy_ratio_20"] = 0.0
        latest["inst_persistence_20"] = 0.0
        latest["foreign_persistence_20"] = 0.0
        latest["supply_data_available"] = False
    # 가격이 크게 오르지 않았는데 수급/OBV가 개선되면 조용한 매집
    latest["quiet_accumulation"] = (
        (latest["price_return_60"].fillna(0).between(-0.12, 0.18)) &
        ((latest["inst_buy_ratio_20"].fillna(0) + latest["foreign_buy_ratio_20"].fillna(0)) > 0.005) &
        (latest["obv_trend_positive"] > 0)
    ).astype(float)
    return latest.reset_index(drop=True)
