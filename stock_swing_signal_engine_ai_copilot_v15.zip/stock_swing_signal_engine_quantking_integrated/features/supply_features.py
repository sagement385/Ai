"""
supply_features.py

기관/외국인 수급 feature.
Lakonishok et al. + Chordia et al. 관점:
- 기관/외국인 순매수는 단일 금액보다 거래대금 대비 비율과 지속성이 중요하다.
"""
from __future__ import annotations
import pandas as pd
import numpy as np


def compute_supply_features(supply: pd.DataFrame, prices: pd.DataFrame | None = None) -> pd.DataFrame:
    if supply is None or supply.empty:
        codes = prices["stock_code"].drop_duplicates() if prices is not None and not prices.empty else []
        return pd.DataFrame({"stock_code": list(codes), "supply_data_available": False, "inst_buy_ratio_20": 0, "inst_buy_ratio_60": 0, "foreign_buy_ratio_20": 0, "foreign_buy_ratio_60": 0, "inst_persistence_20": 0, "foreign_persistence_20": 0})
    df = supply.sort_values(["stock_code", "date"]).copy()
    for col in ["institution_net_buy_value", "foreign_net_buy_value", "pension_net_buy_value", "individual_net_buy_value", "trading_value"]:
        if col not in df.columns: df[col] = 0.0
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)
    if prices is not None and not prices.empty:
        p = prices[["stock_code", "date", "trading_value"]].copy()
        p["date"] = pd.to_datetime(p["date"])
        df["date"] = pd.to_datetime(df["date"])
        df = df.merge(p, on=["stock_code", "date"], how="left", suffixes=("", "_price"))
        df["trading_value"] = df["trading_value"].where(df["trading_value"] > 0, df["trading_value_price"].fillna(0))
    g = df.groupby("stock_code")
    for n in [20, 60]:
        denom = g["trading_value"].transform(lambda s: s.rolling(n, min_periods=max(5, n//3)).sum()).replace(0, np.nan)
        df[f"inst_buy_ratio_{n}"] = g["institution_net_buy_value"].transform(lambda s: s.rolling(n, min_periods=max(5, n//3)).sum()) / denom
        df[f"foreign_buy_ratio_{n}"] = g["foreign_net_buy_value"].transform(lambda s: s.rolling(n, min_periods=max(5, n//3)).sum()) / denom
    df["inst_positive"] = (df["institution_net_buy_value"] > 0).astype(int)
    df["foreign_positive"] = (df["foreign_net_buy_value"] > 0).astype(int)
    df["inst_persistence_20"] = g["inst_positive"].transform(lambda s: s.rolling(20, min_periods=5).mean())
    df["foreign_persistence_20"] = g["foreign_positive"].transform(lambda s: s.rolling(20, min_periods=5).mean())
    latest = df.groupby("stock_code").tail(1)[["stock_code", "inst_buy_ratio_20", "inst_buy_ratio_60", "foreign_buy_ratio_20", "foreign_buy_ratio_60", "inst_persistence_20", "foreign_persistence_20"]].copy()
    latest["supply_data_available"] = True
    return latest.reset_index(drop=True)
