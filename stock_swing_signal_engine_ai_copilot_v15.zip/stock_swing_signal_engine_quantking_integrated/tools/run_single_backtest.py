from __future__ import annotations

import argparse
from pathlib import Path

from data_sources.price_data import read_prices
from data_sources.volume_data import ensure_volume_columns
from backtest.multi_strategy_backtester import run_multi_strategy_backtest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--prices-csv', required=True)
    ap.add_argument('--config', required=True)
    ap.add_argument('--output-dir', required=True)
    args = ap.parse_args()
    prices = ensure_volume_columns(read_prices(Path(args.prices_csv)))
    run_multi_strategy_backtest(prices, config_path=args.config, output_dir=args.output_dir)

if __name__ == '__main__':
    main()
