from __future__ import annotations

import csv
import json
import math
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


def _deep_update(d: dict[str, Any], u: dict[str, Any]) -> dict[str, Any]:
    out = json.loads(json.dumps(d))
    for k, v in u.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_update(out[k], v)
        else:
            out[k] = v
    return out


def _date_splits_from_csv(prices_csv: Path) -> dict[str, tuple[str, str]]:
    vals: set[str] = set()
    with prices_csv.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if "date" not in (reader.fieldnames or []):
            raise RuntimeError("prices_daily.csv에 date 컬럼이 없습니다.")
        for row in reader:
            v = (row.get("date") or "").strip()
            if v:
                vals.add(v[:10])
    dates = sorted(vals)
    if len(dates) < 300:
        raise RuntimeError("가격 데이터가 너무 짧아 훈련/검증/테스트 분할을 만들 수 없습니다.")
    i1 = int(len(dates) * 0.45)
    i2 = int(len(dates) * 0.70)
    return {
        "train": (dates[0], dates[i1]),
        "validation": (dates[i1 + 1], dates[i2]),
        "test": (dates[i2 + 1], dates[-1]),
        "full": (dates[0], dates[-1]),
    }


def _base_ultra_config() -> dict[str, Any]:
    return {
        "profile_name": "ultra_10x_concentrated_oos_guarded",
        "initial_cash": 10000000,
        "enabled_strategies": ["vcp", "canslim", "deep_turnaround"],
        "start_date": "",
        "end_date": "",
        "test_years": 5,
        "buy_commission_rate": 0.00015,
        "sell_commission_rate": 0.00015,
        "sell_tax_rate": 0.0020,
        "slippage_rate": 0.0015,
        "min_trading_value": 300000000,
        "max_backtest_symbols": 80,
        "liquidity_lookback_rows": 80,
        "exit_target_mode": "config_multiple",
        "stop_loss_mode": "wider_of_signal_and_config",
        "weights": {"vcp": 0.70, "canslim": 0.20, "deep_turnaround": 0.10},
        "max_positions": {"vcp": 3, "canslim": 2, "deep_turnaround": 1},
        "signal_top_n_per_day": {"vcp": 5, "canslim": 4, "deep_turnaround": 3},
        "strategy_exit": {
            "vcp": {"stop_pct": 0.35, "target_price_multiple": 6.0, "target_pct": 5.0, "max_holding_days": 1008},
            "canslim": {"stop_pct": 0.35, "target_price_multiple": 5.0, "target_pct": 4.0, "max_holding_days": 1008},
            "deep_turnaround": {"stop_pct": 0.45, "target_price_multiple": 12.0, "target_pct": 11.0, "max_holding_days": 1260},
        },
        "risk_overlay": {
            "enabled": True,
            "method_note": "초공격 집중형. train/validation/test 분할 평가와 거래 수 제한을 함께 사용한다.",
            "market_exposure_multiplier": {"risk_on": 1.20, "neutral": 1.00, "risk_off": 0.65},
            "block_new_entries_in_risk_off": False,
            "allow_exception_score_in_risk_off": 82,
            "use_risk_position_sizing": True,
            "risk_per_trade_pct_of_strategy_equity": {"vcp": 0.040, "canslim": 0.032, "deep_turnaround": 0.012},
            "cooldown_after_stop_days": 0,
            "breakeven_trigger_pct": {"vcp": 1.50, "canslim": 1.50, "deep_turnaround": 2.50},
            "breakeven_buffer_pct": 0.0,
            "trailing_stop_enabled": True,
            "trailing_activation_pct": {"vcp": 2.0, "canslim": 2.0, "deep_turnaround": 4.0},
            "atr_trailing_multiple": {"vcp": 10.0, "canslim": 10.0, "deep_turnaround": 15.0},
            "max_total_open_positions": 6,
            "risk_off_defensive_exit": False,
        },
        "capital_injection_overlay": {
            "enabled": True,
            "method_note": "손절 대신 제한된 추가투입. 무제한 물타기를 금지하고 종목/총투입 한도를 둔다.",
            "allowed_strategies": ["vcp", "canslim", "deep_turnaround"],
            "drawdown_triggers_pct": [-0.20, -0.38, -0.55],
            "add_fraction_of_initial_position": [0.75, 1.00, 1.25],
            "max_additions_per_position": 3,
            "max_external_capital_pct_of_initial_cash": 3.0,
            "max_position_value_pct_of_total_contributed": 0.45,
            "min_health_score": 60,
            "require_not_falling_knife": True,
            "catastrophic_exit_enabled": True,
            "catastrophic_drawdown_pct": -0.82,
        },
    }


def _candidate_configs() -> list[dict[str, Any]]:
    base = _base_ultra_config()
    raw = [
        ("vcp_core_80", {}),
        ("vcp_core_100", {"max_backtest_symbols": 100, "weights": {"vcp": .65, "canslim": .25, "deep_turnaround": .10}, "max_positions": {"vcp": 4, "canslim": 2, "deep_turnaround": 1}, "risk_overlay": {"max_total_open_positions": 7}}),
        ("vcp_canslim_concentrated", {"enabled_strategies": ["vcp", "canslim"], "max_backtest_symbols": 90, "weights": {"vcp": .72, "canslim": .28}, "max_positions": {"vcp": 3, "canslim": 2}, "signal_top_n_per_day": {"vcp": 5, "canslim": 4}, "capital_injection_overlay": {"allowed_strategies": ["vcp", "canslim"]}, "risk_overlay": {"max_total_open_positions": 5}}),
        ("deep_option_sleeve", {"max_backtest_symbols": 100, "weights": {"vcp": .50, "canslim": .25, "deep_turnaround": .25}, "max_positions": {"vcp": 3, "canslim": 2, "deep_turnaround": 3}, "risk_overlay": {"max_total_open_positions": 8, "risk_per_trade_pct_of_strategy_equity": {"vcp": .030, "canslim": .026, "deep_turnaround": .016}}}),
        ("wider_additions", {"max_backtest_symbols": 90, "weights": {"vcp": .60, "canslim": .25, "deep_turnaround": .15}, "capital_injection_overlay": {"drawdown_triggers_pct": [-0.25, -0.45, -0.62], "add_fraction_of_initial_position": [1.0, 1.25, 1.5], "max_external_capital_pct_of_initial_cash": 3.5, "max_position_value_pct_of_total_contributed": .50}, "risk_overlay": {"max_total_open_positions": 6}}),
        ("hard_chase_risk_on", {"max_backtest_symbols": 80, "weights": {"vcp": .75, "canslim": .20, "deep_turnaround": .05}, "risk_overlay": {"market_exposure_multiplier": {"risk_on": 1.35, "neutral": 1.0, "risk_off": .65}, "risk_per_trade_pct_of_strategy_equity": {"vcp": .045, "canslim": .035, "deep_turnaround": .010}, "max_total_open_positions": 5}}),
        ("vcp_only_concentrated", {"enabled_strategies": ["vcp"], "max_backtest_symbols": 90, "weights": {"vcp": 1.0}, "max_positions": {"vcp": 4}, "signal_top_n_per_day": {"vcp": 6}, "capital_injection_overlay": {"allowed_strategies": ["vcp"]}, "risk_overlay": {"max_total_open_positions": 4, "risk_per_trade_pct_of_strategy_equity": {"vcp": .04}}}),
    ]
    out = []
    for name, upd in raw:
        cfg = _deep_update(base, upd)
        cfg["optimizer_candidate"] = name
        enabled = cfg.get("enabled_strategies", ["vcp", "canslim", "deep_turnaround"])
        cfg["weights"] = {k: v for k, v in cfg.get("weights", {}).items() if k in enabled}
        s = sum(cfg["weights"].values()) or 1
        cfg["weights"] = {k: v/s for k, v in cfg["weights"].items()}
        cfg["max_positions"] = {k: v for k, v in cfg.get("max_positions", {}).items() if k in enabled}
        cfg["signal_top_n_per_day"] = {k: v for k, v in cfg.get("signal_top_n_per_day", {}).items() if k in enabled}
        out.append(cfg)
    return out


def _write_config(cfg: dict[str, Any], path: Path, start: str, end: str) -> Path:
    c = json.loads(json.dumps(cfg))
    c["start_date"] = start
    c["end_date"] = end
    c["test_years"] = 99
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def _read_summary(path: Path) -> dict[str, str]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    return rows[0] if rows else {}


def _float(row: dict[str, Any], key: str, default: float = 0.0) -> float:
    try:
        x = float(row.get(key, default))
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _objective(row: dict[str, Any]) -> tuple[float, str]:
    ret = _float(row, "return_on_total_contributed_pct", _float(row, "total_return_pct", 0))
    total_ret = _float(row, "total_return_pct", 0)
    mdd = _float(row, "mdd_pct", -100)
    pf = _float(row, "profit_factor", 0)
    trades = _float(row, "trades", 0)
    cagr = _float(row, "cagr_pct", 0)
    score = ret + 0.35*cagr + max(0, pf-1.0)*12
    reasons = []
    if trades < 10:
        score -= 80; reasons.append("거래수<10")
    elif trades < 20:
        score -= 25; reasons.append("거래수<20")
    if mdd < -55:
        score -= 80; reasons.append("MDD<-55")
    elif mdd < -40:
        score -= 25; reasons.append("MDD<-40")
    if pf < 1.0:
        score -= 40; reasons.append("PF<1")
    if total_ret > 1000 and trades < 30:
        score -= 50; reasons.append("극단수익/낮은표본")
    return score, ";".join(reasons)


def _run_backtest_process(prices_csv: Path, config_path: Path, output_dir: Path, timeout_sec: int = 240) -> dict[str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, "-m", "tools.run_single_backtest", "--prices-csv", str(prices_csv), "--config", str(config_path), "--output-dir", str(output_dir)]
    subprocess.run(cmd, check=True, timeout=timeout_sec)
    summary_path = output_dir / "backtest_summary.csv"
    if not summary_path.exists():
        raise RuntimeError(f"백테스트 요약 파일이 생성되지 않았습니다: {summary_path}")
    return _read_summary(summary_path)


def _write_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys())
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def run_ultra10x_optimization(prices_csv: str | Path = "data/csv_import/prices_daily.csv", output_dir: str | Path = "reports/output", max_candidates: int | None = None) -> dict[str, Path]:
    prices_csv = Path(prices_csv)
    if not prices_csv.exists():
        raise RuntimeError(f"가격 CSV가 없습니다: {prices_csv}")
    out = Path(output_dir)
    opt_dir = out / "ultra10x_optimizer"
    if opt_dir.exists():
        shutil.rmtree(opt_dir)
    opt_dir.mkdir(parents=True, exist_ok=True)
    splits = _date_splits_from_csv(prices_csv)
    candidates = _candidate_configs()
    if max_candidates:
        candidates = candidates[:max_candidates]
    rows: list[dict[str, Any]] = []
    partial = out / "ultra10x_optimization_report_partial.csv"
    for i, cfg in enumerate(candidates, 1):
        name = cfg.get("optimizer_candidate", f"candidate_{i}")
        cand_dir = opt_dir / name
        print(f"[ultra10x] candidate {i}/{len(candidates)} train: {name}", flush=True)
        cfg_train = _write_config(cfg, cand_dir / "train_config.json", *splits["train"])
        train = _run_backtest_process(prices_csv, cfg_train, cand_dir / "train")
        print(f"[ultra10x] candidate {i}/{len(candidates)} validation: {name}", flush=True)
        cfg_val = _write_config(cfg, cand_dir / "validation_config.json", *splits["validation"])
        val = _run_backtest_process(prices_csv, cfg_val, cand_dir / "validation")
        train_score, train_penalty = _objective(train)
        val_score, val_penalty = _objective(val)
        train_ret = _float(train, "return_on_total_contributed_pct", _float(train, "total_return_pct", 0))
        val_ret = _float(val, "return_on_total_contributed_pct", _float(val, "total_return_pct", 0))
        overfit_gap = train_ret - val_ret
        selection_score = val_score - max(0, overfit_gap - 120) * 0.35
        rows.append({
            "candidate": name,
            "enabled_strategies": ",".join(cfg.get("enabled_strategies", [])),
            "train_start": splits["train"][0], "train_end": splits["train"][1],
            "validation_start": splits["validation"][0], "validation_end": splits["validation"][1],
            "train_return_on_contributed_pct": train_ret,
            "train_total_return_pct": _float(train, "total_return_pct", 0),
            "train_mdd_pct": _float(train, "mdd_pct", 0),
            "train_trades": _float(train, "trades", 0),
            "train_pf": _float(train, "profit_factor", 0),
            "validation_return_on_contributed_pct": val_ret,
            "validation_total_return_pct": _float(val, "total_return_pct", 0),
            "validation_mdd_pct": _float(val, "mdd_pct", 0),
            "validation_trades": _float(val, "trades", 0),
            "validation_pf": _float(val, "profit_factor", 0),
            "train_objective": train_score,
            "validation_objective": val_score,
            "overfit_gap_pct": overfit_gap,
            "selection_score": selection_score,
            "penalties": ",".join([x for x in [train_penalty, val_penalty] if x]),
            "max_backtest_symbols": cfg.get("max_backtest_symbols"),
            "max_positions": json.dumps(cfg.get("max_positions", {}), ensure_ascii=False),
            "weights": json.dumps(cfg.get("weights", {}), ensure_ascii=False),
        })
        _write_rows(partial, sorted(rows, key=lambda r: float(r["selection_score"]), reverse=True))
    rows = sorted(rows, key=lambda r: float(r["selection_score"]), reverse=True)
    report_path = out / "ultra10x_optimization_report.csv"
    _write_rows(report_path, rows)
    selected_name = rows[0]["candidate"]
    selected_cfg = next(c for c in candidates if c.get("optimizer_candidate") == selected_name)
    selected_cfg["selection_note"] = "Chosen by validation selection_score. Test period was not used for selection."
    selected_cfg["train_period"] = splits["train"]
    selected_cfg["validation_period"] = splits["validation"]
    selected_cfg["test_period"] = splits["test"]
    selected_cfg["full_period"] = splits["full"]
    selected_path = out / "ultra10x_selected_config.json"
    selected_path.write_text(json.dumps(selected_cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[ultra10x] selected: {selected_name}; running OOS test", flush=True)
    test_cfg = _write_config(selected_cfg, opt_dir / selected_name / "test_config.json", *splits["test"])
    test = _run_backtest_process(prices_csv, test_cfg, out / "ultra10x_test", timeout_sec=360)
    print(f"[ultra10x] running full-reference result (not for selection)", flush=True)
    full_cfg = _write_config(selected_cfg, opt_dir / selected_name / "full_config.json", *splits["full"])
    full = _run_backtest_process(prices_csv, full_cfg, out / "ultra10x_full_reference", timeout_sec=480)
    for sub, prefix in [("ultra10x_test", "ultra10x_test"), ("ultra10x_full_reference", "ultra10x_full")]:
        d = out / sub
        for fname in ["backtest_summary.csv", "backtest_trades.csv", "backtest_equity_curve.csv", "backtest_report.html", "backtest_excess_summary.csv", "backtest_capital_injections.csv"]:
            src = d / fname
            if src.exists():
                shutil.copy2(src, out / f"{prefix}_{fname}")
    rows2 = []
    for label, row, period in [("test_oos", test, splits["test"]), ("full_reference_not_for_selection", full, splits["full"] )]:
        rows2.append({
            "section": label,
            "start": period[0], "end": period[1],
            "candidate": selected_name,
            "total_return_pct": _float(row, "total_return_pct", 0),
            "return_on_total_contributed_pct": _float(row, "return_on_total_contributed_pct", 0),
            "cagr_pct": _float(row, "cagr_pct", 0),
            "mdd_pct": _float(row, "mdd_pct", 0),
            "trades": _float(row, "trades", 0),
            "profit_factor": _float(row, "profit_factor", 0),
            "win_rate_pct": _float(row, "win_rate_pct", 0),
        })
    summary_path = out / "ultra10x_selected_oos_summary.csv"
    _write_rows(summary_path, rows2)
    return {
        "optimization_report": report_path,
        "selected_config": selected_path,
        "selected_oos_summary": summary_path,
        "test_report": out / "ultra10x_test_backtest_report.html",
        "full_reference_report": out / "ultra10x_full_backtest_report.html",
    }


if __name__ == "__main__":
    paths = run_ultra10x_optimization()
    for k, v in paths.items():
        print(f"{k}: {v}")
