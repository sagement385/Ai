# QuantKingSetup(1).zip 파일 인벤토리

분석 기준 파일: 사용자가 업로드한 `QuantKingSetup(1).zip`

## 포함 파일 요약

- `QuantKing.exe`: Windows .NET Framework 4.5.2 GUI 실행파일
- `program.msi`: 설치 패키지
- `KHOpenAPI.ocx`: Kiwoom OpenAPI+ OCX로 추정되는 COM 컨트롤
- `Interop.KHOpenAPILib.dll`, `AxInterop.KHOpenAPILib.dll`: Kiwoom OCX .NET interop DLL
- `System.Data.SQLite.dll`, `x64/SQLite.Interop.dll`, `x86/SQLite.Interop.dll`: SQLite 로컬 DB 사용 흔적
- `Newtonsoft.Json.dll`: JSON 처리
- `Microsoft.Azure.Storage.*.dll`: 클라우드 스토리지 사용 가능성
- `Sound.wav`, `logo_new2.ico`: UI 리소스

## exe 문자열에서 확인된 기능 흔적

- Kiwoom/OpenAPI: `axKHOpenAPI1`, `OpenAPISetup.exe`, Kiwoom 다운로드 URL
- DB: `SELECT name FROM sqlite_master`, `t_company_basic`, `t_company_user`, `t_data`, `codeIdx`, `date`
- 가격성 컬럼 추정: `c101`, `c2002`, `c2003`, `c2004`, `c602`
- 백테스트: `BackTestResult`, `MDD(Maximum Draw Down)`, 월별/연도별 그리드, CSV 저장
- 밸류/재무: `PER`, `PBR`, `ROE`, `POR`, `PCR`, `CMA`
- 차트/UI: `financeChart`, 다수의 chart 컨트롤

## 엔진 통합 판단

실행파일 코드 자체를 가져오는 것은 불가능/부적절하므로 다음만 반영했습니다.

1. Kiwoom OpenAPI 수집 브리지
2. QuantKing SQLite DB 변환 브리지
3. QuantKing식 백테스트 성과지표
4. 데이터 요구사항 문서화
