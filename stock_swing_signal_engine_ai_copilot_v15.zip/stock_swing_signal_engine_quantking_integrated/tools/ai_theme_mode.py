from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

DEFAULT_THEMES = {
    "피지컬AI_로봇": {
        "keywords": ["로봇", "로보", "robot", "뉴로메카", "레인보우", "두산로보", "로보티즈", "로보스타", "에스피지", "감속기", "협동로봇", "스마트팩토리"],
        "description": "피지컬 AI, 산업용/협동로봇, 감속기, 자동화 장비"
    },
    "AI반도체_HBM": {
        "keywords": ["하이닉스", "삼성전자", "한미반도체", "HBM", "반도체", "ISC", "리노공업", "이오테크닉스", "피에스케이", "HPSP", "주성", "원익", "테스", "제우스"],
        "description": "AI 서버, HBM, 후공정, 반도체 장비/소재"
    },
    "자동차반도체_SDv": {
        "keywords": ["텔레칩스", "칩스앤미디어", "넥스트칩", "아이에이", "어보브", "해성디에스", "차량용", "자율주행", "모빌리티", "오토에버", "SDV"],
        "description": "차량용 반도체, SDV, 자율주행, 차량 SW"
    },
    "전고체_차세대배터리": {
        "keywords": ["전고체", "배터리", "이수스페셜", "한농화성", "씨아이에스", "동화기업", "삼성SDI", "엘앤에프", "에코프로", "천보", "대주전자", "나노신소재"],
        "description": "전고체, 2차전지 소재, 장비, 배터리 밸류체인"
    },
    "수소_연료전지": {
        "keywords": ["수소", "퓨얼셀", "연료전지", "두산퓨얼셀", "범한퓨얼셀", "일진하이솔루스", "효성중공업", "비나텍", "에스퓨얼셀", "제이엔케이"],
        "description": "수소 생산/저장/연료전지/인프라"
    },
    "우주_항공": {
        "keywords": ["우주", "항공", "한화에어로", "한국항공우주", "쎄트렉아이", "AP위성", "인텔리안", "컨텍", "위성", "발사체"],
        "description": "우주항공, 위성, 발사체, 통신"
    },
    "드론_무인체계": {
        "keywords": ["드론", "무인", "UAM", "퍼스텍", "네온테크", "제이씨현", "베셀", "코콤"],
        "description": "드론, 무인체계, UAM, 방산형 로봇"
    },
    "전력인프라_데이터센터": {
        "keywords": ["전력", "전선", "변압", "효성중공업", "HD현대일렉트릭", "LS ELECTRIC", "LS일렉트릭", "대한전선", "가온전선", "데이터센터", "전력기기"],
        "description": "AI 데이터센터 전력, 변압기, 전선, 전력기기"
    },
    "방산_첨단무기": {
        "keywords": ["방산", "한화에어로", "LIG넥스원", "현대로템", "풍산", "퍼스텍", "미사일", "레이더", "유도무기"],
        "description": "방산, 유도무기, 장갑차, 첨단 무기체계"
    }
}


def _read_csv(path: Path, **kwargs) -> pd.DataFrame:
    try:
        if path.exists() and path.stat().st_size > 0:
            return pd.read_csv(path, **kwargs)
    except Exception:
        return pd.DataFrame()
    return pd.DataFrame()


def _norm_code(s) -> str:
    return str(s).strip().replace(".0", "").zfill(6)


def _pct(v, lo, hi):
    try:
        x = float(v)
        if not np.isfinite(x): return 50.0
        return max(0.0, min(100.0, (x - lo) / (hi - lo) * 100.0))
    except Exception:
        return 50.0


def _invpct(v, lo, hi):
    return 100.0 - _pct(v, lo, hi)


def _load_taxonomy(path: Path | None = None) -> dict[str, Any]:
    if path and path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data:
                return data
        except Exception:
            pass
    return DEFAULT_THEMES


def _latest_price_features(prices: pd.DataFrame) -> pd.DataFrame:
    if prices is None or prices.empty:
        return pd.DataFrame()
    p = prices.copy()
    p["stock_code"] = p["stock_code"].map(_norm_code)
    p["date"] = pd.to_datetime(p["date"], errors="coerce")
    if "stock_name" not in p.columns:
        p["stock_name"] = p.get("name", p["stock_code"])
    if "market" not in p.columns:
        p["market"] = "UNKNOWN"
    for c in ["close", "high", "low", "volume", "trading_value"]:
        if c not in p.columns:
            p[c] = 0
        p[c] = pd.to_numeric(p[c], errors="coerce")
    if "trading_value" not in p.columns or p["trading_value"].fillna(0).sum() == 0:
        p["trading_value"] = p["close"] * p["volume"]
    p = p.dropna(subset=["date", "stock_code", "close"]).sort_values(["stock_code", "date"])
    g = p.groupby("stock_code", sort=False)
    for n in [20, 60, 120, 252]:
        p[f"ret_{n}d"] = g["close"].pct_change(n) * 100
    p["high_252"] = g["high"].rolling(252, min_periods=80).max().reset_index(level=0, drop=True)
    p["low_252"] = g["low"].rolling(252, min_periods=80).min().reset_index(level=0, drop=True)
    p["avg_tv_60"] = g["trading_value"].rolling(60, min_periods=20).mean().reset_index(level=0, drop=True)
    p["volatility_60"] = g["close"].pct_change().groupby(p["stock_code"], sort=False).rolling(60, min_periods=20).std().reset_index(level=0, drop=True) * np.sqrt(252) * 100
    latest = g.tail(1).copy()
    latest["drawdown_52w_pct"] = (latest["close"] / latest["high_252"].replace(0, np.nan) - 1) * 100
    latest["off_low_52w_pct"] = (latest["close"] / latest["low_252"].replace(0, np.nan) - 1) * 100
    market_ret = {n: latest[f"ret_{n}d"].median(skipna=True) for n in [60, 120, 252] if f"ret_{n}d" in latest.columns}
    for n, m in market_ret.items():
        latest[f"rs_{n}d"] = latest[f"ret_{n}d"] - m
    cols = ["stock_code", "stock_name", "market", "date", "close", "volume", "trading_value", "avg_tv_60", "ret_20d", "ret_60d", "ret_120d", "ret_252d", "rs_60d", "rs_120d", "rs_252d", "drawdown_52w_pct", "off_low_52w_pct", "volatility_60"]
    return latest[[c for c in cols if c in latest.columns]].reset_index(drop=True)


def _financial_features(fin: pd.DataFrame) -> pd.DataFrame:
    if fin is None or fin.empty or "stock_code" not in fin.columns:
        return pd.DataFrame(columns=["stock_code", "financial_health_score", "financial_notes"])
    f = fin.copy()
    f["stock_code"] = f["stock_code"].map(_norm_code)
    f = f.drop_duplicates("stock_code", keep="last")
    def col(names):
        for n in names:
            if n in f.columns:
                return pd.to_numeric(f[n], errors="coerce")
        return pd.Series(np.nan, index=f.index)
    roe = col(["ROE", "roe"])
    debt = col(["debt_ratio", "부채비율"])
    pbr = col(["PBR", "pbr"])
    op = col(["operating_profit", "operating_income", "영업이익"])
    ni = col(["net_income", "당기순이익"])
    growth = col(["revenue_yoy", "sales_growth_yoy", "operating_profit_yoy", "operating_income_yoy", "net_income_yoy", "eps_yoy"])
    score = pd.Series(50.0, index=f.index)
    score += roe.map(lambda x: (_pct(x, -5, 15)-50)*0.25)
    score += debt.map(lambda x: (_invpct(x, 50, 350)-50)*0.30)
    score += pbr.map(lambda x: (_invpct(x, 0.5, 4.0)-50)*0.10)
    score += growth.map(lambda x: (_pct(x, -20, 60)-50)*0.25)
    score = np.where((op > 0) & (ni > 0), np.maximum(score, 68), score)
    score = np.where((op < 0) & (ni < 0), np.minimum(score, 35), score)
    out = f[["stock_code"]].copy()
    out["financial_health_score"] = pd.Series(score, index=f.index).clip(0, 100).round(1)
    notes = []
    for i in f.index:
        msg=[]
        if pd.notna(roe.loc[i]): msg.append(f"ROE {roe.loc[i]:.1f}")
        if pd.notna(debt.loc[i]): msg.append(f"부채 {debt.loc[i]:.0f}%")
        if pd.notna(growth.loc[i]): msg.append(f"성장 {growth.loc[i]:.1f}%")
        if pd.notna(op.loc[i]) and pd.notna(ni.loc[i]): msg.append("흑자" if op.loc[i] > 0 and ni.loc[i] > 0 else "이익주의")
        notes.append(", ".join(msg) if msg else "재무 데이터 부족: 중립")
    out["financial_notes"] = notes
    return out


def _supply_features(supply: pd.DataFrame) -> pd.DataFrame:
    if supply is None or supply.empty or "stock_code" not in supply.columns:
        return pd.DataFrame(columns=["stock_code", "supply_score", "supply_notes"])
    s = supply.copy()
    s["stock_code"] = s["stock_code"].map(_norm_code)
    s["date"] = pd.to_datetime(s.get("date"), errors="coerce")
    score_cols = [c for c in s.columns if any(k in c.lower() for k in ["foreign", "institution", "기관", "외국인", "net"])]
    numeric_cols=[]
    for c in score_cols:
        try:
            s[c] = pd.to_numeric(s[c], errors="coerce")
            numeric_cols.append(c)
        except Exception:
            pass
    if not numeric_cols:
        return pd.DataFrame(columns=["stock_code", "supply_score", "supply_notes"])
    recent = s.sort_values(["stock_code", "date"]).groupby("stock_code").tail(20)
    flow = recent.groupby("stock_code")[numeric_cols].sum(numeric_only=True).sum(axis=1).reset_index(name="net_flow_20")
    med = flow["net_flow_20"].abs().median() or 1
    flow["supply_score"] = flow["net_flow_20"].map(lambda x: _pct(x/med, -3, 3)).round(1)
    flow["supply_notes"] = np.where(flow["net_flow_20"] > 0, "최근 수급 순유입", "최근 수급 약함/순유출")
    return flow[["stock_code", "supply_score", "supply_notes"]]


def build_ai_theme_report(data_dir: str | Path = "data/csv_import", output_dir: str | Path = "reports/output", taxonomy_path: str | Path = "configs/ai_theme_taxonomy.json", max_per_theme: int = 50, min_score: float = 45.0) -> tuple[pd.DataFrame, pd.DataFrame, Path]:
    data_dir = Path(data_dir); output_dir = Path(output_dir); output_dir.mkdir(parents=True, exist_ok=True)
    taxonomy = _load_taxonomy(Path(taxonomy_path))
    prices = _read_csv(data_dir / "prices_daily.csv", dtype={"stock_code": str})
    universe = _read_csv(data_dir / "universe.csv", dtype={"stock_code": str})
    financials = _read_csv(data_dir / "financials.csv", dtype={"stock_code": str})
    supply = _read_csv(data_dir / "supply_daily.csv", dtype={"stock_code": str})
    latest = _latest_price_features(prices)
    if latest.empty:
        raise RuntimeError("prices_daily.csv가 없어 AI 테마 분석을 만들 수 없습니다.")
    if not universe.empty and "stock_code" in universe.columns:
        universe = universe.rename(columns={"name": "universe_name", "종목명": "universe_name"})
        universe["stock_code"] = universe["stock_code"].map(_norm_code)
        keep_cols = [c for c in ["stock_code", "universe_name", "market", "sector", "industry"] if c in universe.columns]
        latest = latest.merge(universe[keep_cols].drop_duplicates("stock_code"), on="stock_code", how="left", suffixes=("", "_u"))
        latest["stock_name"] = latest["stock_name"].fillna(latest.get("universe_name"))
        if "market_u" in latest.columns:
            latest["market"] = latest["market"].fillna(latest["market_u"])
    fin = _financial_features(financials)
    sup = _supply_features(supply)
    if not fin.empty:
        latest = latest.merge(fin, on="stock_code", how="left")
    if not sup.empty:
        latest = latest.merge(sup, on="stock_code", how="left")
    latest["financial_health_score"] = latest.get("financial_health_score", pd.Series(50, index=latest.index)).fillna(50)
    latest["supply_score"] = latest.get("supply_score", pd.Series(50, index=latest.index)).fillna(50)
    rows=[]
    name_series = latest["stock_name"].astype(str).fillna("")
    sector_text = latest["sector"].astype(str) if "sector" in latest.columns else pd.Series("", index=latest.index)
    industry_text = latest["industry"].astype(str) if "industry" in latest.columns else pd.Series("", index=latest.index)
    for theme, spec in taxonomy.items():
        kws = [str(x).lower() for x in spec.get("keywords", [])]
        desc = str(spec.get("description", ""))
        text = (name_series + " " + sector_text.astype(str) + " " + industry_text.astype(str)).str.lower()
        mask = pd.Series(False, index=latest.index)
        matched_kw = pd.Series("", index=latest.index)
        for kw in kws:
            m = text.str.contains(kw, regex=False, na=False)
            matched_kw = matched_kw.mask(m & matched_kw.eq(""), kw)
            mask = mask | m
        part = latest[mask].copy()
        if part.empty:
            continue
        part["theme"] = theme
        part["theme_description"] = desc
        part["matched_keyword"] = matched_kw[mask].values
        # 장기 테마형 점수: 테마 관련도는 keyword 매칭으로만 쓰고, 투자 우선순위는 추세+재무+유동성+수급을 같이 본다.
        mom = part.get("rs_120d", pd.Series(0, index=part.index)).map(lambda x: _pct(x, -20, 60)) * 0.35 + part.get("ret_252d", pd.Series(0, index=part.index)).map(lambda x: _pct(x, -30, 120)) * 0.20
        health = part["financial_health_score"] * 0.20
        liq = part.get("avg_tv_60", part.get("trading_value", pd.Series(0, index=part.index))).map(lambda x: _pct(np.log10(max(float(x), 1)), 7, 11)) * 0.10
        risk = part.get("drawdown_52w_pct", pd.Series(-50, index=part.index)).map(lambda x: _pct(x, -75, -5)) * 0.05
        supply_score = part["supply_score"] * 0.10
        part["ai_theme_score"] = (mom + health + liq + risk + supply_score).clip(0, 100).round(1)
        part["good_points"] = part.apply(lambda r: f"테마:{r.get('matched_keyword','')} · 120일RS {r.get('rs_120d',np.nan):.1f} · 거래대금 {_fmt_kor(r.get('avg_tv_60', r.get('trading_value',0)))}", axis=1)
        part["risk_points"] = part.apply(lambda r: _risk_text(r), axis=1)
        part["financial_brief"] = part.get("financial_notes", pd.Series("재무 데이터 부족", index=part.index)).astype(str)
        rows.append(part)
    if not rows:
        candidates = pd.DataFrame(columns=["theme", "stock_code", "stock_name", "ai_theme_score"])
        summary = pd.DataFrame()
    else:
        candidates = pd.concat(rows, ignore_index=True)
        candidates = candidates[candidates["ai_theme_score"] >= float(min_score)].copy()
        candidates = candidates.sort_values(["theme", "ai_theme_score", "avg_tv_60"], ascending=[True, False, False])
        candidates = candidates.groupby("theme", group_keys=False).head(int(max_per_theme)).reset_index(drop=True)
        summary = candidates.groupby("theme").agg(
            stocks=("stock_code", "nunique"),
            avg_score=("ai_theme_score", "mean"),
            top_score=("ai_theme_score", "max"),
            top_names=("stock_name", lambda x: ", ".join(map(str, list(x.head(5)))))
        ).reset_index().sort_values("top_score", ascending=False)
        summary["avg_score"] = summary["avg_score"].round(1)
    out_cols = [c for c in ["theme", "theme_description", "stock_code", "stock_name", "market", "ai_theme_score", "matched_keyword", "close", "ret_60d", "ret_120d", "ret_252d", "rs_120d", "drawdown_52w_pct", "avg_tv_60", "financial_health_score", "supply_score", "good_points", "risk_points", "financial_brief"] if c in candidates.columns]
    candidates[out_cols].to_csv(output_dir / "ai_theme_candidates.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(output_dir / "ai_theme_summary.csv", index=False, encoding="utf-8-sig")
    html_path = output_dir / "ai_theme_report.html"
    html_path.write_text(_html_report(candidates[out_cols] if out_cols else candidates, summary), encoding="utf-8")
    return candidates, summary, html_path


def _fmt_kor(v) -> str:
    try:
        x=float(v)
        if x >= 1e12: return f"{x/1e12:.1f}조"
        if x >= 1e8: return f"{x/1e8:.1f}억"
        return f"{x:,.0f}"
    except Exception:
        return "-"


def _risk_text(r) -> str:
    risks=[]
    dd = r.get("drawdown_52w_pct", np.nan)
    fh = r.get("financial_health_score", 50)
    vol = r.get("volatility_60", np.nan)
    if pd.notna(dd) and dd < -50: risks.append("52주 고점 대비 낙폭 큼")
    if pd.notna(fh) and fh < 45: risks.append("재무 건전성 주의")
    if pd.notna(vol) and vol > 70: risks.append("변동성 큼")
    if not risks: risks.append("특이 위험 낮음")
    return ", ".join(risks)


def _html_report(candidates: pd.DataFrame, summary: pd.DataFrame) -> str:
    cards=""
    if summary is not None and not summary.empty:
        for _, r in summary.iterrows():
            cards += f"<div class='card'><b>{r.get('theme')}</b><span>{int(r.get('stocks',0))}개 · 최고 {r.get('top_score',0):.1f}</span><p>{r.get('top_names','')}</p></div>"
    rows=""
    if candidates is not None and not candidates.empty:
        for _, r in candidates.head(500).iterrows():
            rows += f"<tr><td>{r.get('theme','')}</td><td><a href='/stock?code={r.get('stock_code','')}'>{r.get('stock_name','')}</a><br><small>{r.get('stock_code','')}</small></td><td>{r.get('ai_theme_score','')}</td><td>{r.get('good_points','')}</td><td>{r.get('financial_brief','')}</td><td>{r.get('risk_points','')}</td></tr>"
    return f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>AI 장기 테마 분석</title><style>body{{margin:0;background:#f5f7fb;color:#111827;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif}}.wrap{{max-width:1320px;margin:0 auto;padding:24px}}.hero{{background:#fff;border:1px solid #e5e7eb;border-radius:26px;padding:24px;box-shadow:0 12px 30px rgba(15,23,42,.06)}}h1{{margin:0;font-size:30px}}p{{color:#64748b;line-height:1.55}}a{{color:#2563eb;font-weight:800;text-decoration:none}}.grid{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:16px 0}}.card{{background:white;border:1px solid #e5e7eb;border-radius:18px;padding:14px}}.card b{{display:block;font-size:16px}}.card span{{font-weight:900;color:#2563eb}}table{{width:100%;border-collapse:collapse;background:white;border-radius:18px;overflow:hidden}}td,th{{padding:11px;border-bottom:1px solid #e5e7eb;text-align:left;font-size:13px;vertical-align:top}}th{{color:#64748b}}small{{color:#64748b}}@media(max-width:900px){{.grid{{grid-template-columns:1fr}}}}</style></head><body><main class='wrap'><section class='hero'><h1>AI 장기 테마 분석</h1><p>수소, 전고체배터리, 피지컬AI, 우주, 드론, 반도체, 자동차반도체 등 미래 기술 테마별로 종목을 최대 50개씩 정리합니다. 이 기능은 가격/재무/수급 CSV 기반의 경량 AI 모드이며, 뉴스 실시간 해석은 별도 API 연동 시 확장할 수 있습니다.</p><p><a href='/'>홈</a> · <a href='/terminal'>터미널</a> · <a href='ai_theme_candidates.csv'>CSV 다운로드</a></p></section><div class='grid'>{cards}</div><table><thead><tr><th>테마</th><th>종목</th><th>점수</th><th>긍정 근거</th><th>재무</th><th>주의점</th></tr></thead><tbody>{rows if rows else '<tr><td colspan=6>후보 없음</td></tr>'}</tbody></table></main></body></html>"""
