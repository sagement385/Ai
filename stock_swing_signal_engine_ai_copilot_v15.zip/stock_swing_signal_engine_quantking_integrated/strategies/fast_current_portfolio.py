from __future__ import annotations

from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd

from backtest.multi_strategy_backtester import _rolling_features, normalize_code, STRATEGY_NAMES, _apply_entry_quality
from .multi_strategy_portfolio import load_strategy_config


def _num(s, default=np.nan):
    return pd.to_numeric(s, errors="coerce").fillna(default)


def _pct_clip(s, low, high):
    s = _num(s, np.nan)
    return ((s - low) / (high - low) * 100).clip(0, 100).fillna(0)


def _inv_clip(s, low, high):
    s = _num(s, np.nan)
    return ((high - s) / (high - low) * 100).clip(0, 100).fillna(0)


def _signal(score, close, pivot, breakout):
    if breakout and score >= 70:
        return "BUY_BREAKOUT"
    if pd.notna(pivot) and pivot > 0 and close >= pivot * 0.97 and score >= 65:
        return "WATCH_NEAR_PIVOT"
    if score >= 75:
        return "WATCH_STRONG"
    if score >= 60:
        return "WATCH"
    return "IGNORE"


def _attach_names(latest: pd.DataFrame, universe: pd.DataFrame | None) -> pd.DataFrame:
    out = latest.copy()
    if universe is not None and not universe.empty:
        u = universe.copy().rename(columns={"name": "stock_name", "종목명": "stock_name", "회사명": "stock_name", "종목코드": "stock_code"})
        if "stock_code" in u:
            u["stock_code"] = u["stock_code"].astype(str).str.replace(".0", "", regex=False).str.zfill(6)
            cols = [c for c in ["stock_code", "stock_name", "market"] if c in u.columns]
            out = out.drop(columns=[c for c in ["stock_name", "market"] if c in out.columns], errors="ignore").merge(u[cols].drop_duplicates("stock_code"), on="stock_code", how="left")
    if "stock_name" not in out:
        out["stock_name"] = out.get("name", out["stock_code"])
    out["stock_name"] = out["stock_name"].fillna(out["stock_code"])
    if "market" not in out:
        out["market"] = "UNKNOWN"
    return out


def _make_rows(df: pd.DataFrame, sid: str, score: pd.Series, pivot: pd.Series, entry: pd.Series, stop: pd.Series, target: pd.Series, reason: str, min_score: float = 55, cfg: dict | None = None) -> pd.DataFrame:
    close = _num(df["close"], np.nan)
    vol = _num(df.get("volume"), 0)
    vol60 = _num(df.get("vol60"), np.nan)
    breakout = (close > pivot * 1.005) & (vol > vol60 * 1.2)
    out = df.copy()
    out["strategy_id"] = sid
    out["strategy_name"] = STRATEGY_NAMES.get(sid, sid)
    out["strategy_score"] = score.clip(0, 100).round(2)
    out["signal"] = [_signal(s, c, p, b) for s, c, p, b in zip(out["strategy_score"], close, pivot, breakout)]
    out["pivot_price"] = pivot
    out["entry_price"] = entry.round(2)
    out["stop_loss"] = stop.round(2)
    out["target_price"] = target.round(2)
    out["pivot_gap_pct"] = ((close / pivot.replace(0, np.nan) - 1) * 100).round(2)
    out["ma20_gap_pct"] = ((close / _num(df.get("ma20"), np.nan).replace(0, np.nan) - 1) * 100).round(2)
    out["ma60_gap_pct"] = ((close / _num(df.get("ma60"), np.nan).replace(0, np.nan) - 1) * 100).round(2)
    out["ret20_pct"] = (_num(df.get("ret20"), np.nan) * 100).round(2)
    out["stop_distance_pct"] = ((close / stop.replace(0, np.nan) - 1) * 100).round(2)
    if cfg is not None:
        ok_mask, audit = _apply_entry_quality(df, breakout.fillna(False), pivot, stop, sid, cfg, entry_type="CURRENT")
        chase = breakout.fillna(False) & (~ok_mask.fillna(False))
        out["entry_quality_status"] = np.where(chase, "CHASE_RISK", "OK")
        out["entry_filter_reason"] = ""
        # 사람이 읽기 쉽도록 주요 초과 조건을 그대로 기록한다.
        out.loc[out["pivot_gap_pct"] > 0, "entry_filter_reason"] = out.loc[out["pivot_gap_pct"] > 0, "entry_filter_reason"].astype(str)
    else:
        chase = pd.Series(False, index=out.index)
        out["entry_quality_status"] = "OK"
        out["entry_filter_reason"] = ""
    out.loc[chase, "signal"] = "WATCH_CHASE_RISK"
    out.loc[chase, "reason"] = reason + " | 추격매수 안전장치: 피벗/이평선/20일 급등/손절폭 조건 확인 필요"
    out.loc[~chase, "reason"] = reason
    cols = ["stock_code", "stock_name", "market", "date", "close", "volume", "trading_value", "strategy_id", "strategy_name", "strategy_score", "signal", "entry_price", "stop_loss", "target_price", "pivot_price", "pivot_gap_pct", "ma20_gap_pct", "ma60_gap_pct", "ret20_pct", "stop_distance_pct", "entry_quality_status", "entry_filter_reason", "reason"]
    for c in cols:
        if c not in out:
            out[c] = np.nan
    return out.loc[out["strategy_score"] >= min_score, cols].sort_values(["strategy_score", "trading_value"], ascending=[False, False]).reset_index(drop=True)


def build_fast_current_portfolio(prices: pd.DataFrame, universe: pd.DataFrame | None = None, financials: pd.DataFrame | None = None, config_path: str | Path | None = None, enabled_strategies: list[str] | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    cfg = load_strategy_config(config_path)
    if enabled_strategies:
        enabled = [x for x in enabled_strategies if x in {"vcp", "canslim", "stage2", "darvas", "deep_turnaround"}]
        if enabled:
            cfg["enabled_strategies"] = enabled
            cfg["weights"] = {k: v for k, v in cfg["weights"].items() if k in enabled}
            total = sum(cfg["weights"].values())
            cfg["weights"] = {k: v / total for k, v in cfg["weights"].items()} if total else cfg["weights"]
    enabled = set(cfg.get("enabled_strategies", cfg["weights"].keys()))
    feat = _rolling_features(prices)
    latest = feat.drop_duplicates("stock_code", keep="last").copy()
    latest = _attach_names(latest, universe)
    close = _num(latest["close"], np.nan)
    vol_ratio = _num(latest.get("vol20"), np.nan) / _num(latest.get("vol60"), np.nan).replace(0, np.nan)
    atr_ratio = _num(latest.get("atr_ratio"), np.nan)
    rs60 = _num(latest.get("rs60"), 0)
    rs120 = _num(latest.get("rs120"), 0)
    ret60 = _num(latest.get("ret60"), 0)
    ret120 = _num(latest.get("ret120"), 0)
    high20 = _num(latest.get("high20_prev"), np.nan)
    low20 = _num(latest.get("low20_prev"), np.nan)
    high60 = _num(latest.get("high60_prev"), np.nan)
    low60 = _num(latest.get("low60_prev"), np.nan)
    high120 = _num(latest.get("high120_prev"), np.nan)
    high252 = _num(latest.get("high252_prev"), np.nan)
    range20 = _num(latest.get("range20"), np.nan)
    range60 = _num(latest.get("range60"), np.nan)
    range120 = _num(latest.get("range120"), np.nan)
    ma50 = _num(latest.get("ma50"), np.nan)
    ma150 = _num(latest.get("ma150"), np.nan)
    ma200 = _num(latest.get("ma200"), np.nan)
    scans = []
    if "vcp" in enabled:
        trend = ((close > ma50).astype(int)*20 + (close > ma150).astype(int)*20 + (close > ma200).astype(int)*20 + (ma50 > ma150).astype(int)*20 + (ma150 > ma200*0.97).astype(int)*20)
        strength = _pct_clip(ret120, 0, .35)*.45 + _pct_clip(rs120, -.05, .20)*.35 + _inv_clip((close / high252.replace(0, np.nan) - 1).abs(), 0, .25)*.20
        contraction = _inv_clip(range120, .15, .65)*.20 + _inv_clip(range20 / range60.replace(0, np.nan), .35, 1.05)*.35 + _inv_clip(atr_ratio, .55, 1.15)*.25 + _inv_clip(vol_ratio, .45, 1.05)*.20
        pivot = high20.fillna(high60)
        score = trend*.25 + strength*.20 + contraction*.35 + _inv_clip((close/pivot.replace(0,np.nan)-1).abs(),0,.08)*.20
        scans.append(_make_rows(latest, "vcp", score, pivot, pivot*1.005, np.minimum(close*.93, low20*.99), close*1.18, "VCP: 강한 추세 + 52주 고점 근처 + 변동성/거래량 수축 + 피벗 근접", cfg=cfg))
    if "canslim" in enabled:
        pivot = high60
        leadership = _pct_clip(rs60, -.03, .18)*.35 + _pct_clip(rs120, -.05, .25)*.35 + _pct_clip(ret120, 0, .45)*.30
        base = _inv_clip((close/high252.replace(0,np.nan)-1).abs(),0,.20)*.55 + _inv_clip(range60,.12,.50)*.20 + _inv_clip((close/pivot.replace(0,np.nan)-1).abs(),0,.08)*.25
        trend = ((close > ma50).astype(int)*20 + (close > ma150).astype(int)*20 + (close > ma200).astype(int)*20 + (ma50 > ma150).astype(int)*15 + (_num(latest.get("ma200_slope20"),0)>=-0.0002).astype(int)*25)
        fin_score = pd.Series(50.0, index=latest.index)
        score = leadership*.30 + base*.24 + trend*.20 + _pct_clip(vol_ratio,.6,1.8)*.12 + fin_score*.14
        scans.append(_make_rows(latest, "canslim", score, pivot, pivot*1.005, close*.92, close*1.22, "CANSLIM: 상대강도/신고가 근처 베이스/거래량 돌파. 재무 CSV가 있으면 추후 C/A 요소 강화", cfg=cfg))
    if "stage2" in enabled:
        pivot = high120
        weekly_ok = latest.get("stage2_weekly", pd.Series(False, index=latest.index)).fillna(False).astype(bool)
        trend = ((close > ma150).astype(int)*20 + (close > ma200).astype(int)*20 + (ma50 > ma150).astype(int)*15 + (_num(latest.get("ma200_slope20"),0)>=-0.0001).astype(int)*20 + weekly_ok.astype(int)*25)
        base = _inv_clip((close/pivot.replace(0,np.nan)-1).abs(),0,.12)*.55 + _inv_clip(range120,.18,.75)*.25 + _pct_clip(rs120,-.05,.20)*.20
        weekly_score = ((close > _num(latest.get("ma_30w"), np.nan)).astype(int)*45 + (_num(latest.get("ma_30w_slope_4w"), np.nan)>0).astype(int)*35 + _inv_clip((close/_num(latest.get("high_26w_prev"), np.nan).replace(0,np.nan)-1).abs(),0,.14)*20)
        score = trend*.35 + base*.30 + weekly_score*.25 + _pct_clip(vol_ratio,.65,1.6)*.10
        scans.append(_make_rows(latest, "stage2", score, pivot, pivot*1.003, np.minimum(close*.90, ma50.fillna(close*.90)*.98), close*1.30, "Stage2: 주봉 30주선 상승 + 150/200일선 위 + 장기 저항 돌파/근접", cfg=cfg))
    if "darvas" in enabled:
        pivot = high20
        box = _inv_clip(range20 / range60.replace(0,np.nan), .35, 1.05)*.45 + _inv_clip(range20, .08, .35)*.25 + _pct_clip(rs60,-.04,.16)*.30
        score = box*.55 + _inv_clip((close/pivot.replace(0,np.nan)-1).abs(),0,.08)*.25 + ((close>ma50).astype(int)*20)
        target = close + (high20 - low20).clip(lower=0)*2
        scans.append(_make_rows(latest, "darvas", score, pivot, pivot*1.005, low20*.99, target, "Darvas: 20일 박스 상단 돌파/근접 + 박스폭 수축 + 손절선 명확", cfg=cfg))
    if "deep_turnaround" in enabled:
        # Deep Turnaround 10x: 폭락 후 살아남는 바닥 회복 후보. 거짓 저점 방지 필터 포함.
        drawdown = close / high252.replace(0, np.nan) - 1
        off_low = close / _num(latest.get("low252_prev"), np.nan).replace(0, np.nan) - 1
        low120 = _num(latest.get("low120_prev"), np.nan)
        low60 = _num(latest.get("low60_prev"), np.nan)
        ma120 = _num(latest.get("ma120"), np.nan)
        ma50_slope = _num(latest.get("ma50_slope20"), 0)
        ma200_slope = _num(latest.get("ma200_slope20"), 0)
        bottom = _pct_clip(off_low, .08, .70)*.30 + _pct_clip(close/low120.replace(0,np.nan)-1, .05, .45)*.25 + _pct_clip(low60/low120.replace(0,np.nan)-1, -.03, .20)*.20 + _inv_clip(atr_ratio, .55, 1.20)*.25
        recovery = ((close>ma50).astype(int)*25 + (close>ma120).astype(int)*20 + (ma50_slope>0).astype(int)*20 + (close>ma200*.92).astype(int)*20 + (ma200_slope>-0.0007).astype(int)*15)
        revival = _pct_clip(vol_ratio,.75,2.2)*.45 + _pct_clip(rs60,-.05,.20)*.30 + _pct_clip(ret60,-.05,.35)*.25
        # 현재 화면에서는 point-in-time 재무가 없을 수 있으므로 재무 생존력은 중립 50으로 시작.
        fin_score = pd.Series(50.0, index=latest.index)
        falling_knife = (_num(latest.get("ret20"),0) < -0.12) | ((close < ma50) & (ma50_slope < 0) & (ret60 < 0))
        no_base = (close < low120 * 1.05) & (ma50_slope < 0)
        lottery_spike = _num(latest.get("ret20"),0) > .85
        false_penalty = falling_knife.astype(int)*22 + no_base.astype(int)*18 + lottery_spike.astype(int)*15 + (drawdown < -0.92).astype(int)*30
        score = _pct_clip(abs(drawdown), .45, .85)*.20 + bottom*.23 + recovery*.22 + revival*.15 + fin_score*.20 - false_penalty
        pivot = pd.concat([high120, ma200*1.02], axis=1).max(axis=1)
        scans.append(_make_rows(latest, "deep_turnaround", score, pivot, pivot*1.005, np.minimum(close*.75, low120*.96), close*5.0, "Deep Turnaround 10x: 큰 낙폭 후 바닥 안정화·거래량/상대강도 회복·50/120/200일선 회복 조짐. 거짓 저점: 20일 급락 지속, 저점 재이탈, 복권성 급등은 감점", cfg=cfg))

    non_empty_scans = [x for x in scans if x is not None and not x.empty]
    all_signals = pd.concat(non_empty_scans, ignore_index=True) if non_empty_scans else pd.DataFrame()
    if all_signals.empty:
        return all_signals, pd.DataFrame()
    min_score = float(cfg.get("min_strategy_score", 60))
    selected_parts = []
    signal_rank = {"BUY_BREAKOUT":4,"WATCH_NEAR_PIVOT":3,"WATCH_STRONG":2,"WATCH":1,"IGNORE":0}
    for sid, g in all_signals.groupby("strategy_id", sort=False):
        n = int(cfg.get("max_positions", {}).get(sid, 5))
        gg = g[g["strategy_score"] >= min_score].copy()
        if "entry_quality_status" in gg.columns:
            gg = gg[gg["entry_quality_status"].astype(str).ne("CHASE_RISK")].copy()
        if gg.empty:
            continue
        gg["_rank"] = gg["signal"].map(signal_rank).fillna(0)
        gg = gg.sort_values(["_rank", "strategy_score", "trading_value"], ascending=[False,False,False]).head(n).drop(columns="_rank")
        w = float(cfg["weights"].get(sid, 0))
        gg["raw_position_weight"] = w / len(gg) if len(gg) else 0
        selected_parts.append(gg)
    if not selected_parts:
        return all_signals, pd.DataFrame()
    selected = pd.concat(selected_parts, ignore_index=True)
    max_single = float(cfg.get("max_single_stock_weight", .10))
    rows=[]
    for code, g in selected.groupby("stock_code", sort=False):
        g = g.sort_values("strategy_score", ascending=False)
        best = g.iloc[0]
        total = min(float(g["raw_position_weight"].sum()), max_single)
        rows.append({
            "stock_code": code, "stock_name": best.get("stock_name", code), "market": best.get("market", "UNKNOWN"), "date": best.get("date"), "close": best.get("close"),
            "portfolio_weight": total, "portfolio_weight_pct": round(total*100,2), "raw_weight_before_cap": float(g["raw_position_weight"].sum()),
            "strategy_count": int(g["strategy_id"].nunique()), "strategies": ", ".join(g["strategy_id"].astype(str)), "strategy_names": " / ".join(g["strategy_name"].astype(str)),
            "best_strategy_score": round(float(g["strategy_score"].max()),2), "avg_strategy_score": round(float(g["strategy_score"].mean()),2), "signals": ", ".join(g["signal"].astype(str)),
            "entry_price": round(float(pd.to_numeric(g["entry_price"], errors="coerce").median()),2), "stop_loss": round(float(pd.to_numeric(g["stop_loss"], errors="coerce").median()),2), "target_price": round(float(pd.to_numeric(g["target_price"], errors="coerce").median()),2),
            "pivot_price": round(float(pd.to_numeric(g.get("pivot_price", pd.Series(dtype=float)), errors="coerce").median()),2) if "pivot_price" in g else np.nan,
            "pivot_gap_pct": round(float(pd.to_numeric(g.get("pivot_gap_pct", pd.Series(dtype=float)), errors="coerce").median()),2) if "pivot_gap_pct" in g else np.nan,
            "entry_quality_status": " / ".join(g.get("entry_quality_status", pd.Series(["OK"])).astype(str).unique().tolist()),
            "entry_filter_reason": " | ".join([x for x in g.get("entry_filter_reason", pd.Series(dtype=str)).astype(str).tolist() if x and x != "nan"]),
            "reason": " | ".join(g["reason"].astype(str)),
        })
    portfolio = pd.DataFrame(rows).sort_values(["portfolio_weight", "best_strategy_score"], ascending=[False,False]).reset_index(drop=True)
    portfolio["cash_weight"] = max(0.0, 1.0 - float(portfolio["portfolio_weight"].sum()))
    return all_signals.sort_values(["strategy_id","strategy_score"], ascending=[True,False]).reset_index(drop=True), portfolio
