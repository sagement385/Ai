from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (
    attach_relative_strength,
    inv_pct_clip,
    latest_feature_frame,
    pct_clip,
    prepare_prices,
    prepare_universe,
    score_to_signal,
    stop_from_pct,
    target_from_pct,
)


def _base_latest(prices: pd.DataFrame, universe: pd.DataFrame | None = None) -> pd.DataFrame:
    p = prepare_prices(prices)
    latest = latest_feature_frame(p)
    latest = attach_relative_strength(latest, p)
    u = prepare_universe(universe, p)
    if not u.empty:
        latest = latest.drop(columns=[c for c in ["stock_name", "market"] if c in latest.columns], errors="ignore")
        latest = u.merge(latest, on="stock_code", how="inner")
    return latest


def _num(s: pd.Series | float | int | None, default: float = 0.0):
    return pd.to_numeric(s, errors="coerce").fillna(default) if isinstance(s, pd.Series) else (default if s is None or pd.isna(s) else float(s))


def _make_output(df: pd.DataFrame, strategy_id: str, strategy_name: str, weight: float, score_col: str, entry_col: str, stop_col: str, target_col: str, reason_col: str) -> pd.DataFrame:
    out = df.copy()
    out["strategy_id"] = strategy_id
    out["strategy_name"] = strategy_name
    out["strategy_weight"] = float(weight)
    out["strategy_score"] = _num(out[score_col]).round(2)
    out["entry_price"] = _num(out[entry_col], np.nan).round(2)
    out["stop_loss"] = _num(out[stop_col], np.nan).round(2)
    out["target_price"] = _num(out[target_col], np.nan).round(2)

    # 공통 진입 품질 지표: 기존 전략 점수는 건드리지 않고, 추격매수 위험만 별도 표시/필터링한다.
    close = _num(out.get("close"), np.nan)
    pivot = _num(out.get("pivot_price"), np.nan)
    if pivot.isna().all():
        # 대부분 entry_price = pivot * 1.003~1.005 구조이므로 근사 pivot을 복원한다.
        divisor = 1.003 if strategy_id == "stage2" else 1.005
        pivot = _num(out.get("entry_price"), np.nan) / divisor
        out["pivot_price"] = pivot
    ma20 = _num(out.get("ma20"), np.nan)
    ma60 = _num(out.get("ma60"), np.nan)
    ret20 = _num(out.get("ret_20d", out.get("ret20")), np.nan)
    stop = _num(out.get("stop_loss"), np.nan)

    out["pivot_gap_pct"] = ((close / pivot.replace(0, np.nan) - 1) * 100).round(2)
    out["ma20_gap_pct"] = ((close / ma20.replace(0, np.nan) - 1) * 100).round(2)
    out["ma60_gap_pct"] = ((close / ma60.replace(0, np.nan) - 1) * 100).round(2)
    out["ret20_pct"] = (ret20 * 100).round(2)
    out["stop_distance_pct"] = ((close / stop.replace(0, np.nan) - 1) * 100).round(2)

    # 한국 시장용 추격매수 방지 기본값. 상한가/급등 이후 뒤늦은 돌파매수를 줄이기 위한 오버레이다.
    max_pivot_gap = {"vcp": 7.0, "canslim": 8.0, "stage2": 11.0, "darvas": 7.5, "deep_turnaround": 14.0}.get(strategy_id, 8.0)
    max_ma20_gap = {"vcp": 18.0, "canslim": 20.0, "stage2": 25.0, "darvas": 18.0, "deep_turnaround": 35.0}.get(strategy_id, 20.0)
    max_ma60_gap = {"vcp": 36.0, "canslim": 42.0, "stage2": 50.0, "darvas": 38.0, "deep_turnaround": 80.0}.get(strategy_id, 42.0)
    max_ret20 = {"vcp": 40.0, "canslim": 45.0, "stage2": 55.0, "darvas": 35.0, "deep_turnaround": 90.0}.get(strategy_id, 45.0)
    max_stop_dist = {"vcp": 16.0, "canslim": 18.0, "stage2": 22.0, "darvas": 16.0, "deep_turnaround": 38.0}.get(strategy_id, 18.0)

    reasons = []
    chase = pd.Series(False, index=out.index)
    def flag(mask, label):
        nonlocal chase
        m = mask.fillna(False) if isinstance(mask, pd.Series) else pd.Series(False, index=out.index)
        chase = chase | m
        reasons.append((m, label))
    flag(out["pivot_gap_pct"] > max_pivot_gap, f"피벗 대비 +{max_pivot_gap:.0f}% 초과")
    flag(out["ma20_gap_pct"] > max_ma20_gap, f"20일선 이격 +{max_ma20_gap:.0f}% 초과")
    flag(out["ma60_gap_pct"] > max_ma60_gap, f"60일선 이격 +{max_ma60_gap:.0f}% 초과")
    flag(out["ret20_pct"] > max_ret20, f"최근 20일 +{max_ret20:.0f}% 초과")
    flag(out["stop_distance_pct"] > max_stop_dist, f"손절폭 {max_stop_dist:.0f}% 초과")

    out["entry_quality_status"] = np.where(chase, "CHASE_RISK", "OK")
    out["entry_filter_reason"] = ""
    for m, label in reasons:
        out.loc[m, "entry_filter_reason"] = (out.loc[m, "entry_filter_reason"].astype(str) + "; " + label).str.strip("; ").str.strip()
    out["reason"] = out[reason_col].astype(str)
    out.loc[chase, "signal"] = out.loc[chase, "signal"].astype(str).where(~out.loc[chase, "signal"].astype(str).str.startswith("BUY"), "WATCH_CHASE_RISK")
    out.loc[chase, "reason"] = out.loc[chase, "reason"] + " | 추격매수 안전장치: " + out.loc[chase, "entry_filter_reason"].astype(str)

    cols = [
        "stock_code", "stock_name", "market", "date", "close", "volume", "trading_value",
        "strategy_id", "strategy_name", "strategy_weight", "strategy_score", "signal",
        "entry_price", "stop_loss", "target_price", "pivot_price",
        "pivot_gap_pct", "ma20_gap_pct", "ma60_gap_pct", "ret20_pct", "stop_distance_pct",
        "entry_quality_status", "entry_filter_reason", "reason",
    ]
    for c in cols:
        if c not in out.columns:
            out[c] = np.nan
    return out[cols].sort_values(["strategy_score", "trading_value"], ascending=[False, False]).reset_index(drop=True)


def scan_vcp(prices: pd.DataFrame, universe: pd.DataFrame | None = None, weight: float = 0.20) -> pd.DataFrame:
    """Minervini-style VCP proxy: strong stock, near high, volatility/volume contraction, near pivot."""
    df = _base_latest(prices, universe)
    if df.empty:
        return pd.DataFrame()

    close = _num(df["close"], np.nan)
    high60 = _num(df.get("high60"), np.nan)
    low60 = _num(df.get("low60"), np.nan)
    high20 = _num(df.get("high20"), np.nan)
    range120 = _num(df.get("range_pct120"), np.nan)
    range60 = _num(df.get("range_pct60"), np.nan)
    range20 = _num(df.get("range_pct20"), np.nan)
    vol20 = _num(df.get("vol_ma20"), np.nan)
    vol60 = _num(df.get("vol_ma60"), np.nan)
    vol_ratio = vol20 / vol60.replace(0, np.nan)
    atr_ratio = _num(df.get("atr_ratio_20_60"), np.nan)
    dist_high = _num(df.get("dist_from_52w_high"), -1.0)
    ret120 = _num(df.get("ret_120d"), 0.0)
    rs120 = _num(df.get("rs_120d"), 0.0)

    trend_score = (
        np.where(close > _num(df.get("ma50"), np.inf), 15, 0) +
        np.where(close > _num(df.get("ma150"), np.inf), 15, 0) +
        np.where(close > _num(df.get("ma200"), np.inf), 15, 0) +
        np.where(_num(df.get("ma50"), -np.inf) > _num(df.get("ma150"), np.inf), 10, 0) +
        np.where(_num(df.get("ma150"), -np.inf) > _num(df.get("ma200"), np.inf), 10, 0)
    )
    trend_score = np.minimum(trend_score / 65 * 100, 100)

    strength_score = (
        pd.Series(ret120).map(lambda x: pct_clip(x, 0.00, 0.35)) * 0.45 +
        pd.Series(rs120).map(lambda x: pct_clip(x, -0.05, 0.20)) * 0.35 +
        pd.Series(dist_high).map(lambda x: inv_pct_clip(abs(x), 0.00, 0.25)) * 0.20
    )
    contraction_score = (
        pd.Series(range120).map(lambda x: inv_pct_clip(x, 0.15, 0.65)) * 0.20 +
        pd.Series(range20 / range60.replace(0, np.nan)).map(lambda x: inv_pct_clip(x, 0.35, 1.05)) * 0.35 +
        pd.Series(atr_ratio).map(lambda x: inv_pct_clip(x, 0.55, 1.15)) * 0.25 +
        pd.Series(vol_ratio).map(lambda x: inv_pct_clip(x, 0.45, 1.05)) * 0.20
    )
    pivot = high20.fillna(high60)
    pivot_distance = close / pivot.replace(0, np.nan) - 1
    pivot_score = pd.Series(abs(pivot_distance)).map(lambda x: inv_pct_clip(x, 0.00, 0.08))
    upper_area_score = pd.Series((close - low60) / (high60 - low60).replace(0, np.nan)).map(lambda x: pct_clip(x, 0.45, 0.90))

    df["vcp_score"] = (
        pd.Series(trend_score) * 0.25 + strength_score * 0.20 + contraction_score * 0.35 + pivot_score * 0.12 + upper_area_score * 0.08
    ).fillna(0).clip(0, 100)
    breakout = (close > pivot * 1.005) & (_num(df.get("volume"), 0) > vol60 * 1.3)
    df["signal"] = [score_to_signal(s, c, p, b) for s, c, p, b in zip(df["vcp_score"], close, pivot, breakout)]
    df["pivot_price"] = pivot
    df["vcp_entry"] = pivot * 1.005
    df["vcp_stop"] = np.minimum(stop_from_pct(1, 0) if False else close * 0.93, low20 := _num(df.get("low20"), np.nan) * 0.99)
    df["vcp_target"] = close * 1.18
    df["vcp_reason"] = (
        "VCP: 강한 추세/상대강도 + 고점 근처 + 변동성·거래량 수축 + 피벗 근접. "
        "박스 안 선매수보다 피벗 돌파/근접 관찰용."
    )
    return _make_output(df[df["vcp_score"] >= 55], "vcp", "Minervini VCP 변동성 수축", weight, "vcp_score", "vcp_entry", "vcp_stop", "vcp_target", "vcp_reason")


def scan_canslim(prices: pd.DataFrame, universe: pd.DataFrame | None = None, financials: pd.DataFrame | None = None, weight: float = 0.30) -> pd.DataFrame:
    """O'Neil CAN SLIM proxy: price leadership + new-high base + volume breakout + optional financial quality."""
    df = _base_latest(prices, universe)
    if df.empty:
        return pd.DataFrame()
    if financials is not None and not financials.empty:
        fin = financials.copy().rename(columns={"종목코드": "stock_code", "종목명": "stock_name"})
        fin["stock_code"] = fin["stock_code"].astype(str).str.zfill(6)
        df = df.merge(fin[[c for c in ["stock_code", "ROE", "roe", "PER", "PBR", "operating_profit", "net_income", "market_cap", "sales_growth_yoy", "revenue_yoy", "operating_profit_yoy", "operating_income_yoy", "net_income_yoy", "eps_yoy", "debt_ratio"] if c in fin.columns]], on="stock_code", how="left")

    close = _num(df["close"], np.nan)
    high60 = _num(df.get("high60"), np.nan)
    high252 = _num(df.get("high252"), np.nan)
    pivot = high60
    rs60 = _num(df.get("rs_60d"), 0.0)
    rs120 = _num(df.get("rs_120d"), 0.0)
    ret60 = _num(df.get("ret_60d"), 0.0)
    ret120 = _num(df.get("ret_120d"), 0.0)
    vol20 = _num(df.get("vol_ma20"), np.nan)
    vol60 = _num(df.get("vol_ma60"), np.nan)
    vol_ratio = vol20 / vol60.replace(0, np.nan)
    dist_high = close / high252.replace(0, np.nan) - 1

    leadership_score = (
        pd.Series(rs60).map(lambda x: pct_clip(x, -0.03, 0.18)) * 0.35 +
        pd.Series(rs120).map(lambda x: pct_clip(x, -0.05, 0.25)) * 0.35 +
        pd.Series(ret120).map(lambda x: pct_clip(x, 0.00, 0.45)) * 0.30
    )
    new_high_base_score = (
        pd.Series(dist_high).map(lambda x: inv_pct_clip(abs(x), 0.00, 0.20)) * 0.55 +
        pd.Series(_num(df.get("range_pct60"), np.nan)).map(lambda x: inv_pct_clip(x, 0.12, 0.50)) * 0.20 +
        pd.Series(close / pivot.replace(0, np.nan) - 1).map(lambda x: inv_pct_clip(abs(x), 0.00, 0.08)) * 0.25
    )
    volume_score = pd.Series(vol_ratio).map(lambda x: pct_clip(x, 0.60, 1.80))
    trend_score = (
        np.where(close > _num(df.get("ma50"), np.inf), 20, 0) +
        np.where(close > _num(df.get("ma150"), np.inf), 20, 0) +
        np.where(close > _num(df.get("ma200"), np.inf), 20, 0) +
        np.where(_num(df.get("ma50"), -np.inf) > _num(df.get("ma150"), np.inf), 15, 0) +
        np.where(_num(df.get("ma200_slope20"), -1) >= -0.0002, 25, 0)
    )
    # DART financial_quarterly.csv/financials.csv가 있으면 CANSLIM의 C/A 요소를 더 강하게 반영한다.
    roe = _num(df.get("ROE", df.get("roe")), np.nan) if ("ROE" in df.columns or "roe" in df.columns) else pd.Series(np.nan, index=df.index)
    op = _num(df.get("operating_profit"), np.nan) if "operating_profit" in df.columns else pd.Series(np.nan, index=df.index)
    ni = _num(df.get("net_income"), np.nan) if "net_income" in df.columns else pd.Series(np.nan, index=df.index)
    sales_yoy = _num(df.get("sales_growth_yoy", df.get("revenue_yoy")), np.nan) if ("sales_growth_yoy" in df.columns or "revenue_yoy" in df.columns) else pd.Series(np.nan, index=df.index)
    op_yoy = _num(df.get("operating_profit_yoy", df.get("operating_income_yoy")), np.nan) if ("operating_profit_yoy" in df.columns or "operating_income_yoy" in df.columns) else pd.Series(np.nan, index=df.index)
    ni_yoy = _num(df.get("net_income_yoy"), np.nan) if "net_income_yoy" in df.columns else pd.Series(np.nan, index=df.index)
    eps_yoy = _num(df.get("eps_yoy"), np.nan) if "eps_yoy" in df.columns else pd.Series(np.nan, index=df.index)

    growth_score = pd.Series(50.0, index=df.index)
    # O'Neil식으로 최근 분기 20~25% 이상 성장에 가산. 적자는 강한 감점.
    if not sales_yoy.isna().all():
        growth_score = growth_score * 0.50 + pd.Series(sales_yoy).map(lambda x: pct_clip(x, 0, 40)) * 0.50
    if not op_yoy.isna().all():
        growth_score = growth_score * 0.65 + pd.Series(op_yoy).map(lambda x: pct_clip(x, 0, 60)) * 0.35
    if not ni_yoy.isna().all():
        growth_score = growth_score * 0.75 + pd.Series(ni_yoy).map(lambda x: pct_clip(x, 0, 60)) * 0.25
    if not eps_yoy.isna().all():
        growth_score = growth_score * 0.75 + pd.Series(eps_yoy).map(lambda x: pct_clip(x, 0, 50)) * 0.25

    quality_score = pd.Series(50.0, index=df.index)
    quality_score = np.where(roe.notna(), pd.Series(roe).map(lambda x: pct_clip(x, 5, 25)), quality_score)
    quality_score = np.where((op.notna()) & (ni.notna()), np.where((op > 0) & (ni > 0), np.maximum(quality_score, 70), np.minimum(quality_score, 30)), quality_score)
    financial_score = (pd.Series(quality_score, index=df.index).astype(float) * 0.45 + pd.Series(growth_score, index=df.index).astype(float) * 0.55).fillna(50)

    df["canslim_score"] = (
        leadership_score * 0.26 + new_high_base_score * 0.22 + pd.Series(trend_score) * 0.18 + volume_score * 0.10 + financial_score * 0.24
    ).fillna(0).clip(0, 100)
    breakout = (close > pivot * 1.005) & (_num(df.get("volume"), 0) > vol60 * 1.5)
    df["signal"] = [score_to_signal(s, c, p, b) for s, c, p, b in zip(df["canslim_score"], close, pivot, breakout)]
    df["pivot_price"] = pivot
    df["canslim_entry"] = pivot * 1.005
    df["canslim_stop"] = close * 0.92
    df["canslim_target"] = close * 1.22
    df["canslim_reason"] = (
        "CANSLIM 유사: 시장대비 강한 상대강도, 52주 고점 근처 베이스, 거래량 동반 돌파 후보, "
        "재무 데이터가 있으면 ROE/이익 양수 여부를 보조 반영."
    )
    return _make_output(df[df["canslim_score"] >= 55], "canslim", "O'Neil CAN SLIM 성장주 돌파", weight, "canslim_score", "canslim_entry", "canslim_stop", "canslim_target", "canslim_reason")


def scan_stage2(prices: pd.DataFrame, universe: pd.DataFrame | None = None, weight: float = 0.40) -> pd.DataFrame:
    """Weinstein Stage 2 proxy: price above rising long MA after base/resistance breakout."""
    df = _base_latest(prices, universe)
    if df.empty:
        return pd.DataFrame()
    # Weinstein 원형에 더 가까운 주봉 30주선 지표를 최신 일봉 스캔에도 보조 반영한다.
    try:
        from data_sources.weekly_features import build_weekly_prices
        weekly = build_weekly_prices(prices)
        if weekly is not None and not weekly.empty:
            wlast = weekly.sort_values("date").groupby("stock_code", as_index=False).tail(1)
            keep = [c for c in ["stock_code", "ma_30w", "ma_30w_slope_4w", "high_26w_prev", "high_52w_prev", "stage2_weekly"] if c in wlast.columns]
            df = df.merge(wlast[keep], on="stock_code", how="left")
    except Exception:
        pass
    close = _num(df["close"], np.nan)
    ma150 = _num(df.get("ma150"), np.nan)
    ma200 = _num(df.get("ma200"), np.nan)
    ma50 = _num(df.get("ma50"), np.nan)
    ma200_slope = _num(df.get("ma200_slope20"), -1.0)
    high120 = _num(df.get("high120"), np.nan)
    low120 = _num(df.get("low120"), np.nan)
    vol20 = _num(df.get("vol_ma20"), np.nan)
    vol60 = _num(df.get("vol_ma60"), np.nan)
    vol_ratio = vol20 / vol60.replace(0, np.nan)
    rs120 = _num(df.get("rs_120d"), 0.0)
    ret60 = _num(df.get("ret_60d"), 0.0)

    trend_score = (
        np.where(close > ma150, 20, 0) +
        np.where(close > ma200, 20, 0) +
        np.where(ma50 > ma150, 15, 0) +
        np.where(ma150 >= ma200 * 0.98, 15, 0) +
        np.where(ma200_slope >= -0.0001, 15, 0) +
        np.where(ma200_slope > 0.00005, 15, 0)
    )
    base_breakout_score = (
        pd.Series(close / high120.replace(0, np.nan) - 1).map(lambda x: inv_pct_clip(abs(x), 0.00, 0.12)) * 0.45 +
        pd.Series(_num(df.get("range_pct120"), np.nan)).map(lambda x: inv_pct_clip(x, 0.18, 0.75)) * 0.25 +
        pd.Series((close - low120) / (high120 - low120).replace(0, np.nan)).map(lambda x: pct_clip(x, 0.50, 0.92)) * 0.30
    )
    strength_score = (
        pd.Series(rs120).map(lambda x: pct_clip(x, -0.05, 0.20)) * 0.55 +
        pd.Series(ret60).map(lambda x: pct_clip(x, -0.03, 0.20)) * 0.45
    )
    volume_score = pd.Series(vol_ratio).map(lambda x: pct_clip(x, 0.65, 1.60))
    weekly_score = pd.Series(50.0, index=df.index)
    if "ma_30w" in df.columns:
        ma30w = _num(df.get("ma_30w"), np.nan)
        slope30w = _num(df.get("ma_30w_slope_4w"), np.nan)
        high26w = _num(df.get("high_26w_prev"), np.nan)
        weekly_score = (
            np.where(close > ma30w, 35, 0) +
            np.where(slope30w > 0, 35, 0) +
            pd.Series(close / high26w.replace(0, np.nan) - 1).map(lambda x: inv_pct_clip(abs(x), 0.00, 0.14)) * 30
        )
    df["stage2_score"] = (
        pd.Series(trend_score) * 0.30 + base_breakout_score * 0.25 + strength_score * 0.18 + volume_score * 0.08 + pd.Series(weekly_score) * 0.19
    ).fillna(0).clip(0, 100)
    breakout = (close > high120 * 1.003) & (_num(df.get("volume"), 0) > vol60 * 1.3)
    df["signal"] = [score_to_signal(s, c, p, b) for s, c, p, b in zip(df["stage2_score"], close, high120, breakout)]
    df["pivot_price"] = high120
    df["stage2_entry"] = high120 * 1.003
    df["stage2_stop"] = np.minimum(close * 0.90, ma50.fillna(close * 0.90) * 0.98)
    df["stage2_target"] = close * 1.30
    df["stage2_reason"] = (
        "Weinstein Stage2 유사: 일봉 장기 이평선 위 + 주봉 30주선 상승/상단 돌파 여부 + 120일 저항/베이스 돌파 근처, "
        "중기 보유 중심 전략."
    )
    return _make_output(df[df["stage2_score"] >= 55], "stage2", "Weinstein Stage 2 상승단계", weight, "stage2_score", "stage2_entry", "stage2_stop", "stage2_target", "stage2_reason")


def scan_darvas(prices: pd.DataFrame, universe: pd.DataFrame | None = None, weight: float = 0.10) -> pd.DataFrame:
    """Darvas Box proxy: recent box, buy stop above top, stop below box bottom."""
    df = _base_latest(prices, universe)
    if df.empty:
        return pd.DataFrame()
    close = _num(df["close"], np.nan)
    high20 = _num(df.get("high20"), np.nan)
    low20 = _num(df.get("low20"), np.nan)
    high60 = _num(df.get("high60"), np.nan)
    low60 = _num(df.get("low60"), np.nan)
    range20 = _num(df.get("range_pct20"), np.nan)
    range60 = _num(df.get("range_pct60"), np.nan)
    vol20 = _num(df.get("vol_ma20"), np.nan)
    vol60 = _num(df.get("vol_ma60"), np.nan)
    vol_ratio = vol20 / vol60.replace(0, np.nan)
    rs60 = _num(df.get("rs_60d"), 0.0)

    box_quality = (
        pd.Series(range20).map(lambda x: inv_pct_clip(x, 0.08, 0.35)) * 0.32 +
        pd.Series(range20 / range60.replace(0, np.nan)).map(lambda x: inv_pct_clip(x, 0.30, 0.95)) * 0.23 +
        pd.Series((close - low20) / (high20 - low20).replace(0, np.nan)).map(lambda x: pct_clip(x, 0.50, 0.93)) * 0.25 +
        pd.Series(rs60).map(lambda x: pct_clip(x, -0.04, 0.16)) * 0.20
    )
    breakout_readiness = (
        pd.Series(close / high20.replace(0, np.nan) - 1).map(lambda x: inv_pct_clip(abs(x), 0.00, 0.08)) * 0.65 +
        pd.Series(vol_ratio).map(lambda x: pct_clip(x, 0.50, 1.70)) * 0.35
    )
    trend_filter = (
        np.where(close > _num(df.get("ma50"), np.inf), 35, 0) +
        np.where(close > _num(df.get("ma150"), np.inf), 25, 0) +
        np.where(close > _num(df.get("ma200"), np.inf), 25, 0) +
        np.where(_num(df.get("ma50_slope20"), -1) >= -0.0003, 15, 0)
    )
    df["darvas_score"] = (box_quality * 0.42 + breakout_readiness * 0.36 + pd.Series(trend_filter) * 0.22).fillna(0).clip(0, 100)
    breakout = (close > high20 * 1.005) & (_num(df.get("volume"), 0) > vol60 * 1.3)
    df["signal"] = [score_to_signal(s, c, p, b) for s, c, p, b in zip(df["darvas_score"], close, high20, breakout)]
    df["pivot_price"] = high20
    df["darvas_entry"] = high20 * 1.005
    df["darvas_stop"] = low20 * 0.99
    df["darvas_target"] = close + (high20 - low20) * 2.0
    df["darvas_reason"] = (
        "Darvas Box 유사: 최근 고점/저점 박스, 상단 돌파 대기, 박스 하단 이탈 시 손절. "
        "거짓 돌파 방지를 위해 추세/거래량 필터 포함."
    )
    return _make_output(df[df["darvas_score"] >= 55], "darvas", "Darvas Box 박스 돌파", weight, "darvas_score", "darvas_entry", "darvas_stop", "darvas_target", "darvas_reason")



def _fin_series(df: pd.DataFrame, names: list[str], default=np.nan) -> pd.Series:
    for name in names:
        if name in df.columns:
            return _num(df.get(name), default)
    return pd.Series(default, index=df.index)


def scan_deep_turnaround(prices: pd.DataFrame, universe: pd.DataFrame | None = None, financials: pd.DataFrame | None = None, weight: float = 0.10) -> pd.DataFrame:
    """Deep Turnaround 10x proxy.

    목적
    - 기존 VCP/CANSLIM/Stage2/Darvas를 건드리지 않고, 폭락 후 살아남는 턴어라운드 후보를 별도 탐색한다.
    - '거짓 저점' 방지를 위해 낙폭만 보지 않고 바닥 안정화, 추세 회복, 유동성, 재무 생존성을 같이 본다.

    연구 근거 요약
    - De Bondt & Thaler식 장기 loser reversal: 장기 과잉반응 후 반전 가능성.
    - Piotroski F-Score: 저평가/낙폭주 중 재무 개선 종목과 value trap 구분.
    - Distress anomaly / lottery-stock evidence: 부실·복권형 급등주를 무작정 사면 기대수익이 낮을 수 있어 안전장치 필요.
    """
    df = _base_latest(prices, universe)
    if df.empty:
        return pd.DataFrame()
    if financials is not None and not financials.empty:
        fin = financials.copy().rename(columns={"종목코드": "stock_code", "종목명": "stock_name", "회사명": "stock_name"})
        if "stock_code" in fin.columns:
            fin["stock_code"] = fin["stock_code"].astype(str).str.replace(".0", "", regex=False).str.zfill(6)
            cols = [c for c in [
                "stock_code", "ROE", "roe", "PBR", "pbr", "PER", "per", "debt_ratio", "부채비율",
                "operating_profit", "operating_income", "영업이익", "net_income", "당기순이익",
                "revenue_yoy", "sales_growth_yoy", "operating_profit_yoy", "operating_income_yoy", "net_income_yoy"
            ] if c in fin.columns]
            if cols:
                df = df.merge(fin[cols].drop_duplicates("stock_code", keep="last"), on="stock_code", how="left")

    close = _num(df["close"], np.nan)
    high252 = _num(df.get("high252"), np.nan)
    low252 = _num(df.get("low252"), np.nan)
    high120 = _num(df.get("high120"), np.nan)
    low120 = _num(df.get("low120"), np.nan)
    low60 = _num(df.get("low60"), np.nan)
    ma50 = _num(df.get("ma50"), np.nan)
    ma120 = _num(df.get("ma120"), np.nan)
    ma200 = _num(df.get("ma200"), np.nan)
    ma50_slope = _num(df.get("ma50_slope20"), 0)
    ma200_slope = _num(df.get("ma200_slope20"), 0)
    ret20 = _num(df.get("ret_20d"), 0)
    ret60 = _num(df.get("ret_60d"), 0)
    ret120 = _num(df.get("ret_120d"), 0)
    rs60 = _num(df.get("rs_60d"), 0)
    vol20 = _num(df.get("vol_ma20"), np.nan)
    vol60 = _num(df.get("vol_ma60"), np.nan)
    vol_ratio = vol20 / vol60.replace(0, np.nan)
    atr_ratio = _num(df.get("atr_ratio_20_60"), np.nan)

    drawdown = close / high252.replace(0, np.nan) - 1
    off_low = close / low252.replace(0, np.nan) - 1
    # 낙폭은 충분히 커야 하지만 -95% 이상은 구조적 부실 가능성 때문에 감점한다.
    drawdown_score = pd.Series(drawdown).map(lambda x: pct_clip(abs(x), 0.45, 0.85))
    extreme_penalty = pd.Series(drawdown).map(lambda x: 30 if pd.notna(x) and x < -0.92 else 0)

    bottom_stability = (
        pd.Series(off_low).map(lambda x: pct_clip(x, 0.08, 0.70)) * 0.30 +
        pd.Series(close / low120.replace(0, np.nan) - 1).map(lambda x: pct_clip(x, 0.05, 0.45)) * 0.25 +
        pd.Series(low60 / low120.replace(0, np.nan) - 1).map(lambda x: pct_clip(x, -0.03, 0.20)) * 0.20 +
        pd.Series(atr_ratio).map(lambda x: inv_pct_clip(x, 0.55, 1.20)) * 0.25
    )
    trend_recovery = (
        np.where(close > ma50, 25, 0) +
        np.where(close > ma120, 20, 0) +
        np.where(ma50_slope > 0, 20, 0) +
        np.where(close > ma200 * 0.92, 20, 0) +
        np.where(ma200_slope > -0.0007, 15, 0)
    )
    liquidity_revival = (
        pd.Series(vol_ratio).map(lambda x: pct_clip(x, 0.75, 2.2)) * 0.45 +
        pd.Series(rs60).map(lambda x: pct_clip(x, -0.05, 0.20)) * 0.30 +
        pd.Series(ret60).map(lambda x: pct_clip(x, -0.05, 0.35)) * 0.25
    )

    # 재무 안전장치: CSV가 없으면 중립. 있으면 value trap/부실 위험을 낮추는 요소만 가산.
    roe = _fin_series(df, ["ROE", "roe"], np.nan)
    pbr = _fin_series(df, ["PBR", "pbr"], np.nan)
    debt = _fin_series(df, ["debt_ratio", "부채비율"], np.nan)
    op = _fin_series(df, ["operating_profit", "operating_income", "영업이익"], np.nan)
    ni = _fin_series(df, ["net_income", "당기순이익"], np.nan)
    rev_yoy = _fin_series(df, ["revenue_yoy", "sales_growth_yoy"], np.nan)
    op_yoy = _fin_series(df, ["operating_profit_yoy", "operating_income_yoy"], np.nan)
    ni_yoy = _fin_series(df, ["net_income_yoy"], np.nan)
    fin_score = pd.Series(50.0, index=df.index)
    if not pbr.isna().all():
        fin_score = fin_score * 0.85 + pd.Series(pbr).map(lambda x: inv_pct_clip(x, 0.3, 3.0)) * 0.15
    if not debt.isna().all():
        fin_score = fin_score * 0.70 + pd.Series(debt).map(lambda x: inv_pct_clip(x, 50, 350)) * 0.30
    if not roe.isna().all():
        fin_score = fin_score * 0.75 + pd.Series(roe).map(lambda x: pct_clip(x, -10, 15)) * 0.25
    for growth in [rev_yoy, op_yoy, ni_yoy]:
        if not growth.isna().all():
            fin_score = fin_score * 0.82 + pd.Series(growth).map(lambda x: pct_clip(x, -20, 60)) * 0.18
    if not op.isna().all() and not ni.isna().all():
        fin_score = np.where((op > 0) & (ni > 0), np.maximum(fin_score, 70), fin_score)
        fin_score = np.where((op < 0) & (ni < 0), np.minimum(fin_score, 35), fin_score)
    fin_score = pd.Series(fin_score, index=df.index).astype(float).fillna(50)

    # 거짓 저점 방지 장치: 떨어지는 칼날/복권성 급등/유동성 취약을 감점 또는 제외.
    falling_knife = (ret20 < -0.12) | ((close < ma50) & (ma50_slope < 0) & (ret60 < 0))
    no_base = (close < low120 * 1.05) & (ma50_slope < 0)
    lottery_spike = ret20 > 0.85  # 단기간 과열 추격 방지
    structural_distress = ((fin_score < 35) & (close < ma200 * 0.85))
    false_bottom_penalty = (
        np.where(falling_knife, 22, 0) +
        np.where(no_base, 18, 0) +
        np.where(lottery_spike, 15, 0) +
        np.where(structural_distress, 20, 0) +
        extreme_penalty
    )

    df["deep_turnaround_score"] = (
        pd.Series(drawdown_score) * 0.20 +
        pd.Series(bottom_stability) * 0.23 +
        pd.Series(trend_recovery) * 0.22 +
        pd.Series(liquidity_revival) * 0.15 +
        fin_score * 0.20 -
        pd.Series(false_bottom_penalty, index=df.index).astype(float)
    ).fillna(0).clip(0, 100)

    pivot = pd.concat([high120, ma200 * 1.02], axis=1).max(axis=1)
    breakout = (close > pivot * 1.005) & (vol_ratio > 1.05) & (~falling_knife)
    df["signal"] = [score_to_signal(s, c, p, b) for s, c, p, b in zip(df["deep_turnaround_score"], close, pivot, breakout)]
    df["pivot_price"] = pivot
    df["deep_entry"] = pivot * 1.005
    # 넓은 손절 + 낮은 비중으로 운용: 저점 전략은 손절을 너무 짧게 잡으면 noise에 털린다.
    df["deep_stop"] = np.minimum(close * 0.75, low120 * 0.96)
    # 10배를 고정 목표가로 두면 거래가 거의 닫히지 않아, 1차 백테스트 목표는 5배로 두고 트레일링으로 열어둔다.
    df["deep_target"] = close * 5.0
    df["deep_reason"] = (
        "Deep Turnaround 10x: 52주 고점 대비 큰 낙폭 + 바닥 안정화 + 50/120/200일선 회복 조짐 + 거래량/상대강도 회복. "
        "거짓 저점 안전장치: 20일 급락 지속, 120일 저점 재이탈, 구조적 부실/부채 과다, 단기 복권성 급등을 감점."
    )
    return _make_output(df[df["deep_turnaround_score"] >= 55], "deep_turnaround", "Deep Turnaround 10x 저점회복", weight, "deep_turnaround_score", "deep_entry", "deep_stop", "deep_target", "deep_reason")
