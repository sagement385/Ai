from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .trader_strategies import scan_canslim, scan_darvas, scan_stage2, scan_vcp, scan_deep_turnaround


DEFAULT_CONFIG: dict[str, Any] = {
    "enabled_strategies": ["vcp", "canslim", "stage2", "darvas", "deep_turnaround"],
    "weights": {
        "vcp": 0.20,
        "canslim": 0.30,
        "stage2": 0.30,
        "darvas": 0.10,
        "deep_turnaround": 0.10,
    },
    "max_positions": {
        "vcp": 5,
        "canslim": 5,
        "stage2": 8,
        "darvas": 3,
        "deep_turnaround": 4,
    },
    "min_strategy_score": 60,
    "max_single_stock_weight": 0.10,
    "score_weighted_inside_strategy": False,
}


def load_strategy_config(path: str | Path | None = None) -> dict[str, Any]:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if path is None:
        path = Path("configs/multi_strategy_config.json")
    path = Path(path)
    if path.exists():
        user = json.loads(path.read_text(encoding="utf-8"))
        for k, v in user.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
    enabled = cfg.get("enabled_strategies") or ["vcp", "canslim", "stage2", "darvas", "deep_turnaround"]
    enabled = [str(x).strip().lower() for x in enabled if str(x).strip().lower() in cfg.get("weights", {})]
    if not enabled:
        enabled = ["vcp", "canslim", "stage2", "darvas"]
    cfg["enabled_strategies"] = enabled
    cfg["weights"] = {k: float(v) for k, v in cfg.get("weights", {}).items() if k in enabled}
    total = sum(float(x) for x in cfg["weights"].values())
    if total <= 0:
        raise ValueError("선택된 전략 비중 합계가 0입니다.")
    # 선택한 전략만 100%가 되도록 normalize.
    cfg["weights"] = {k: float(v) / total for k, v in cfg["weights"].items()}
    cfg["max_positions"] = {k: v for k, v in cfg.get("max_positions", {}).items() if k in enabled}
    return cfg


def _select_strategy_candidates(df: pd.DataFrame, strategy_id: str, cfg: dict[str, Any]) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    min_score = float(cfg.get("min_strategy_score", 60))
    max_n = int(cfg.get("max_positions", {}).get(strategy_id, 5))
    out = df[df["strategy_score"] >= min_score].copy()
    if "entry_quality_status" in out.columns:
        out = out[out["entry_quality_status"].astype(str).ne("CHASE_RISK")].copy()
    if out.empty:
        return out
    # Prefer actionable signals near/beyond pivot, then score.
    signal_rank = {
        "BUY_BREAKOUT": 4,
        "WATCH_NEAR_PIVOT": 3,
        "WATCH_STRONG": 2,
        "WATCH": 1,
        "IGNORE": 0,
    }
    out["_signal_rank"] = out["signal"].map(signal_rank).fillna(0)
    out = out.sort_values(["_signal_rank", "strategy_score", "trading_value"], ascending=[False, False, False]).head(max_n)
    out = out.drop(columns=["_signal_rank"], errors="ignore")
    return out.reset_index(drop=True)


def _allocate_within_strategy(selected: pd.DataFrame, strategy_id: str, cfg: dict[str, Any]) -> pd.DataFrame:
    if selected.empty:
        return selected
    weight = float(cfg["weights"].get(strategy_id, 0.0))
    selected = selected.copy()
    if bool(cfg.get("score_weighted_inside_strategy", False)):
        score = pd.to_numeric(selected["strategy_score"], errors="coerce").fillna(0).clip(lower=0)
        if score.sum() > 0:
            selected["raw_position_weight"] = weight * score / score.sum()
        else:
            selected["raw_position_weight"] = weight / len(selected)
    else:
        selected["raw_position_weight"] = weight / len(selected)
    return selected


def build_multi_strategy_portfolio(
    prices: pd.DataFrame,
    universe: pd.DataFrame | None = None,
    financials: pd.DataFrame | None = None,
    config_path: str | Path | None = None,
    enabled_strategies: list[str] | tuple[str, ...] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Run four independent trader-style strategies and combine them into one portfolio.

    Returns
    -------
    all_signals:
        All candidates from all strategies before top-N allocation.
    portfolio:
        Selected multi-strategy portfolio after strategy allocation and duplicate aggregation.
    """
    cfg = load_strategy_config(config_path)
    if enabled_strategies is not None:
        enabled = [str(x).strip().lower() for x in enabled_strategies if str(x).strip().lower() in {"vcp", "canslim", "stage2", "darvas", "deep_turnaround"}]
        if enabled:
            cfg["enabled_strategies"] = enabled
            cfg["weights"] = {k: v for k, v in cfg["weights"].items() if k in enabled}
            total = sum(cfg["weights"].values())
            cfg["weights"] = {k: v / total for k, v in cfg["weights"].items()} if total > 0 else cfg["weights"]
    weights = cfg["weights"]
    enabled = set(cfg.get("enabled_strategies", weights.keys()))

    scans = []
    if "vcp" in enabled:
        scans.append(scan_vcp(prices, universe=universe, weight=weights.get("vcp", 0.20)))
    if "canslim" in enabled:
        scans.append(scan_canslim(prices, universe=universe, financials=financials, weight=weights.get("canslim", 0.30)))
    if "stage2" in enabled:
        scans.append(scan_stage2(prices, universe=universe, weight=weights.get("stage2", 0.40)))
    if "darvas" in enabled:
        scans.append(scan_darvas(prices, universe=universe, weight=weights.get("darvas", 0.10)))
    if "deep_turnaround" in enabled:
        scans.append(scan_deep_turnaround(prices, universe=universe, financials=financials, weight=weights.get("deep_turnaround", 0.10)))
    non_empty = [s for s in scans if s is not None and not s.empty]
    if not non_empty:
        empty_cols = ["stock_code", "stock_name", "market", "strategy_id", "strategy_name", "strategy_score", "signal", "raw_position_weight"]
        return pd.DataFrame(columns=empty_cols), pd.DataFrame(columns=empty_cols)
    all_signals = pd.concat(non_empty, ignore_index=True)

    selected_parts = []
    for sid, g in all_signals.groupby("strategy_id", sort=False):
        selected = _select_strategy_candidates(g, sid, cfg)
        if selected.empty:
            continue
        selected_parts.append(_allocate_within_strategy(selected, sid, cfg))

    if not selected_parts:
        return all_signals.sort_values(["strategy_id", "strategy_score"], ascending=[True, False]).reset_index(drop=True), pd.DataFrame()

    selected_all = pd.concat(selected_parts, ignore_index=True)

    max_single = float(cfg.get("max_single_stock_weight", 0.10))
    agg_rows = []
    for code, g in selected_all.groupby("stock_code", sort=False):
        g = g.sort_values("strategy_score", ascending=False)
        total_raw = float(g["raw_position_weight"].sum())
        capped = min(total_raw, max_single)
        best = g.iloc[0]
        agg_rows.append({
            "stock_code": code,
            "stock_name": best.get("stock_name", code),
            "market": best.get("market", "UNKNOWN"),
            "date": best.get("date", pd.NaT),
            "close": best.get("close", np.nan),
            "portfolio_weight": capped,
            "portfolio_weight_pct": round(capped * 100, 2),
            "raw_weight_before_cap": total_raw,
            "strategy_count": int(g["strategy_id"].nunique()),
            "strategies": ", ".join(g["strategy_id"].astype(str).tolist()),
            "strategy_names": " / ".join(g["strategy_name"].astype(str).tolist()),
            "best_strategy_score": round(float(pd.to_numeric(g["strategy_score"], errors="coerce").max()), 2),
            "avg_strategy_score": round(float(pd.to_numeric(g["strategy_score"], errors="coerce").mean()), 2),
            "signals": ", ".join(g["signal"].astype(str).tolist()),
            "entry_price": round(float(pd.to_numeric(g["entry_price"], errors="coerce").median()), 2),
            "stop_loss": round(float(pd.to_numeric(g["stop_loss"], errors="coerce").median()), 2),
            "target_price": round(float(pd.to_numeric(g["target_price"], errors="coerce").median()), 2),
            "pivot_price": round(float(pd.to_numeric(g.get("pivot_price", pd.Series(dtype=float)), errors="coerce").median()), 2) if "pivot_price" in g else np.nan,
            "pivot_gap_pct": round(float(pd.to_numeric(g.get("pivot_gap_pct", pd.Series(dtype=float)), errors="coerce").median()), 2) if "pivot_gap_pct" in g else np.nan,
            "entry_quality_status": " / ".join(g.get("entry_quality_status", pd.Series(["OK"])).astype(str).unique().tolist()),
            "entry_filter_reason": " | ".join([x for x in g.get("entry_filter_reason", pd.Series(dtype=str)).astype(str).tolist() if x and x != "nan"]),
            "reason": " | ".join(g["reason"].astype(str).tolist()),
        })
    portfolio = pd.DataFrame(agg_rows).sort_values(["portfolio_weight", "best_strategy_score"], ascending=[False, False]).reset_index(drop=True)
    if not portfolio.empty:
        invested = portfolio["portfolio_weight"].sum()
        portfolio["cash_weight"] = max(0.0, 1.0 - invested)
    all_signals = all_signals.sort_values(["strategy_id", "strategy_score"], ascending=[True, False]).reset_index(drop=True)
    return all_signals, portfolio


def _fmt_pct(v: Any) -> str:
    try:
        return f"{float(v):.2f}%"
    except Exception:
        return ""


def save_multi_strategy_reports(all_signals: pd.DataFrame, portfolio: pd.DataFrame, output_dir: str | Path = "reports/output") -> dict[str, str]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    signals_csv = out / "multi_strategy_signals_all.csv"
    portfolio_csv = out / "multi_strategy_portfolio.csv"
    html_path = out / "multi_strategy_portfolio.html"
    json_path = out / "multi_strategy_portfolio.json"
    all_signals.to_csv(signals_csv, index=False, encoding="utf-8-sig")
    portfolio.to_csv(portfolio_csv, index=False, encoding="utf-8-sig")
    json_path.write_text(portfolio.to_json(orient="records", force_ascii=False, indent=2), encoding="utf-8")

    rows = []
    if portfolio is not None and not portfolio.empty:
        for i, r in portfolio.iterrows():
            rows.append(f"""
<tr>
  <td>{i+1}</td>
  <td><a href='/stock?code={html.escape(str(r.get('stock_code','')))}'><b>{html.escape(str(r.get('stock_name','')))}</b></a><br><span>{html.escape(str(r.get('stock_code','')))}</span></td>
  <td>{html.escape(str(r.get('strategies','')))}</td>
  <td>{_fmt_pct(r.get('portfolio_weight_pct',''))}</td>
  <td>{html.escape(str(r.get('signals','')))}</td>
  <td>{html.escape(str(r.get('best_strategy_score','')))}</td>
  <td>{html.escape(str(r.get('entry_price','')))}</td>
  <td>{html.escape(str(r.get('stop_loss','')))}</td>
  <td>{html.escape(str(r.get('target_price','')))}</td>
  <td>{html.escape(str(r.get('reason','')))[:600]}</td>
</tr>""")
    total_weight = float(portfolio["portfolio_weight"].sum()) if portfolio is not None and not portfolio.empty and "portfolio_weight" in portfolio.columns else 0.0
    html_text = f"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>멀티 전략 포트폴리오</title>
<style>
body{{margin:0;background:#f6f7fb;color:#172033;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif}}
.wrap{{max-width:1240px;margin:0 auto;padding:28px 18px 60px}}
.hero{{background:linear-gradient(135deg,#111827,#2563eb);color:white;border-radius:24px;padding:28px;box-shadow:0 18px 40px rgba(15,23,42,.18)}}
.hero h1{{margin:0 0 8px;font-size:30px}}.hero p{{margin:6px 0;color:#dbeafe;line-height:1.55}}
.cards{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:18px 0}}
.card{{background:white;border:1px solid #e5e7eb;border-radius:18px;padding:16px;box-shadow:0 8px 22px rgba(15,23,42,.06)}}
.card b{{font-size:20px}}.card span{{color:#64748b;font-size:13px}}
table{{width:100%;border-collapse:separate;border-spacing:0 8px;margin-top:18px}}
th{{text-align:left;font-size:12px;color:#475569;padding:10px;background:#e8eefc}}
td{{background:white;border-top:1px solid #e5e7eb;border-bottom:1px solid #e5e7eb;padding:12px;vertical-align:top;font-size:13px;line-height:1.45}}
td:first-child, th:first-child{{border-radius:12px 0 0 12px}}td:last-child, th:last-child{{border-radius:0 12px 12px 0}}
td span{{color:#64748b}}a{{color:#2563eb;font-weight:800;text-decoration:none}}.note{{color:#64748b;line-height:1.5}}
@media(max-width:900px){{.cards{{grid-template-columns:repeat(2,1fr)}} table{{font-size:12px;display:block;overflow-x:auto}}}}
</style></head><body><main class="wrap">
<section class="hero"><h1>4개 독립 알고리즘 멀티 전략 포트폴리오</h1>
<p>RL 없이 VCP, CANSLIM, Weinstein Stage2, Darvas Box를 독립 전략으로 스캔하고, 설정 비중에 따라 포트폴리오를 구성합니다.</p>
<p>총 편입 비중: <b>{total_weight*100:.2f}%</b> · 미편입/현금: <b>{max(0,1-total_weight)*100:.2f}%</b></p></section>
<div class="cards"><div class="card"><b>20%</b><br><span>VCP 변동성 수축</span></div><div class="card"><b>30%</b><br><span>CANSLIM 성장주 돌파</span></div><div class="card"><b>30%</b><br><span>Stage2 상승단계</span></div><div class="card"><b>10%</b><br><span>Darvas Box 돌파</span></div><div class="card"><b>10%</b><br><span>Deep Turnaround 10x</span></div></div>
<p><a href="multi_strategy_portfolio.csv">포트폴리오 CSV</a> · <a href="multi_strategy_signals_all.csv">전체 전략 신호 CSV</a> · <a href="multi_strategy_portfolio.json">JSON</a></p>
<p class="note">이 결과는 매수 추천이 아니라 규칙 기반 후보입니다. 5년치 OHLCV만으로 계산하므로 수급/실적 데이터가 없으면 CANSLIM의 재무 조건은 중립 처리됩니다.</p>
<table><thead><tr><th>#</th><th>종목</th><th>전략</th><th>비중</th><th>신호</th><th>최고점수</th><th>진입가</th><th>손절</th><th>목표</th><th>근거</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
</main></body></html>"""
    html_path.write_text(html_text, encoding="utf-8")
    return {
        "signals_csv": str(signals_csv),
        "portfolio_csv": str(portfolio_csv),
        "html": str(html_path),
        "json": str(json_path),
    }
