from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd


def normalize_code(code: str | int) -> str:
    return str(code).strip().replace(".0", "").zfill(6)


def _safe_float(v, default: float = np.nan) -> float:
    try:
        if pd.isna(v):
            return default
        return float(v)
    except Exception:
        return default


def pct_clip(value: float, low: float, high: float) -> float:
    """Map value linearly to 0~100 where low is 0 and high is 100."""
    if pd.isna(value):
        return 0.0
    if high == low:
        return 0.0
    return float(np.clip((value - low) / (high - low) * 100.0, 0.0, 100.0))


def inv_pct_clip(value: float, low: float, high: float) -> float:
    """Inverse version: low is 100 and high is 0."""
    if pd.isna(value):
        return 0.0
    if high == low:
        return 0.0
    return float(np.clip((high - value) / (high - low) * 100.0, 0.0, 100.0))


def prepare_prices(prices: pd.DataFrame) -> pd.DataFrame:
    if prices is None or prices.empty:
        return pd.DataFrame()
    df = prices.copy()
    rename = {
        "종목코드": "stock_code", "종목명": "stock_name", "회사명": "stock_name", "name": "stock_name",
        "날짜": "date", "시가": "open", "고가": "high", "저가": "low", "종가": "close", "거래량": "volume", "거래대금": "trading_value",
    }
    df = df.rename(columns={k: v for k, v in rename.items() if k in df.columns})
    if "stock_code" not in df.columns:
        raise ValueError("prices 데이터에는 stock_code 컬럼이 필요합니다.")
    if "stock_name" not in df.columns:
        df["stock_name"] = df["stock_code"].astype(str)
    if "market" not in df.columns:
        df["market"] = "UNKNOWN"
    df["stock_code"] = df["stock_code"].map(normalize_code)
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for col in ["open", "high", "low", "close", "adj_close", "volume", "trading_value"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    if "trading_value" not in df.columns:
        df["trading_value"] = df["close"] * df["volume"]
    df["trading_value"] = df["trading_value"].fillna(df["close"] * df["volume"])
    return df.dropna(subset=["date", "close"]).sort_values(["stock_code", "date"]).reset_index(drop=True)


def prepare_universe(universe: pd.DataFrame, prices: pd.DataFrame | None = None) -> pd.DataFrame:
    if universe is None or universe.empty:
        if prices is None or prices.empty:
            return pd.DataFrame(columns=["stock_code", "stock_name", "market"])
        base = prices[["stock_code", "stock_name", "market"]].drop_duplicates("stock_code")
    else:
        base = universe.copy()
    base = base.rename(columns={"종목코드": "stock_code", "종목명": "stock_name", "회사명": "stock_name", "name": "stock_name", "시장구분": "market"})
    if "stock_code" not in base.columns:
        return pd.DataFrame(columns=["stock_code", "stock_name", "market"])
    base["stock_code"] = base["stock_code"].map(normalize_code)
    if "stock_name" not in base.columns:
        base["stock_name"] = base["stock_code"]
    if "market" not in base.columns:
        base["market"] = "UNKNOWN"
    return base[["stock_code", "stock_name", "market"]].drop_duplicates("stock_code")


def _linreg_slope_last(values: pd.Series, window: int) -> float:
    s = values.dropna().tail(window)
    if len(s) < max(5, window // 2):
        return np.nan
    x = np.arange(len(s), dtype=float)
    y = s.to_numpy(dtype=float)
    if np.nanstd(y) == 0:
        return 0.0
    slope = np.polyfit(x, y, 1)[0]
    return float(slope / np.nanmean(y))


def add_indicators(g: pd.DataFrame) -> pd.DataFrame:
    g = g.sort_values("date").copy()
    close = g["close"]
    high = g["high"] if "high" in g.columns else close
    low = g["low"] if "low" in g.columns else close
    volume = g["volume"].fillna(0) if "volume" in g.columns else pd.Series(0, index=g.index)

    for w in [5, 10, 20, 30, 50, 60, 120, 150, 200]:
        g[f"ma{w}"] = close.rolling(w, min_periods=max(5, w // 3)).mean()
        g[f"vol_ma{w}"] = volume.rolling(w, min_periods=max(5, w // 3)).mean()
        g[f"high{w}"] = high.rolling(w, min_periods=max(5, w // 3)).max()
        g[f"low{w}"] = low.rolling(w, min_periods=max(5, w // 3)).min()
        g[f"range_pct{w}"] = (g[f"high{w}"] - g[f"low{w}"]) / close.replace(0, np.nan)

    prev_close = close.shift(1)
    tr = pd.concat([(high - low).abs(), (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
    g["atr20"] = tr.rolling(20, min_periods=10).mean()
    g["atr60"] = tr.rolling(60, min_periods=20).mean()
    g["atr_pct20"] = g["atr20"] / close.replace(0, np.nan)
    g["atr_ratio_20_60"] = g["atr20"] / g["atr60"].replace(0, np.nan)

    ret = close.pct_change()
    g["ret_1d"] = ret
    for w in [20, 60, 120, 252]:
        g[f"ret_{w}d"] = close / close.shift(w) - 1
        g[f"volatility_{w}d"] = ret.rolling(w, min_periods=max(10, w // 3)).std()
    g["high252"] = high.rolling(252, min_periods=80).max()
    g["low252"] = low.rolling(252, min_periods=80).min()
    g["dist_from_52w_high"] = close / g["high252"].replace(0, np.nan) - 1
    g["dist_from_52w_low"] = close / g["low252"].replace(0, np.nan) - 1
    g["ma200_slope20"] = _linreg_slope_last(g["ma200"], 20)
    g["ma50_slope20"] = _linreg_slope_last(g["ma50"], 20)
    return g


def latest_feature_frame(prices: pd.DataFrame) -> pd.DataFrame:
    df = prepare_prices(prices)
    if df.empty:
        return pd.DataFrame()
    frames = []
    for code, g in df.groupby("stock_code", sort=False):
        try:
            ind = add_indicators(g)
            last = ind.tail(1).copy()
            last["days"] = len(g)
            frames.append(last)
        except Exception:
            continue
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def market_proxy_returns(prices: pd.DataFrame) -> pd.Series:
    df = prepare_prices(prices)
    if df.empty:
        return pd.Series(dtype=float)
    wide = df.pivot_table(index="date", columns="stock_code", values="close", aggfunc="last").sort_index()
    # equal-weight market proxy: reduce single large cap bias, but still captures broad trend.
    return wide.pct_change(fill_method=None).median(axis=1).fillna(0)


def attach_relative_strength(latest: pd.DataFrame, prices: pd.DataFrame) -> pd.DataFrame:
    latest = latest.copy()
    mret = market_proxy_returns(prices)
    if mret.empty:
        latest["rs_60d"] = 0.0
        latest["rs_120d"] = 0.0
        latest["rs_252d"] = 0.0
        return latest
    m_close = (1 + mret).cumprod()
    def market_return(days: int) -> float:
        if len(m_close) <= days:
            return float(m_close.iloc[-1] / m_close.iloc[0] - 1) if len(m_close) > 1 else 0.0
        return float(m_close.iloc[-1] / m_close.iloc[-days] - 1)
    for d in [60, 120, 252]:
        latest[f"rs_{d}d"] = pd.to_numeric(latest.get(f"ret_{d}d"), errors="coerce").fillna(0) - market_return(min(d, len(m_close) - 1))
    return latest


def score_to_signal(score: float, close: float, pivot: float | None = None, breakout: bool = False) -> str:
    if breakout and score >= 70:
        return "BUY_BREAKOUT"
    if pivot and pivot > 0 and close >= pivot * 0.97 and score >= 65:
        return "WATCH_NEAR_PIVOT"
    if score >= 75:
        return "WATCH_STRONG"
    if score >= 60:
        return "WATCH"
    return "IGNORE"


def stop_from_pct(close: float, pct: float) -> float:
    return round(float(close) * (1 - pct), 2) if close and close > 0 else np.nan


def target_from_pct(close: float, pct: float) -> float:
    return round(float(close) * (1 + pct), 2) if close and close > 0 else np.nan
