from __future__ import annotations

import json
import os
import re
import shutil
import textwrap
import time
import urllib.request
import urllib.error
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd


DEFAULT_ALLOWED_PATCH_DIRS = [
    "configs",
    "strategies",
    "backtest",
    "tools",
    "features",
    "filters",
    "scoring",
    "reports",
    "docs",
]

BLOCKED_PATH_PARTS = {
    ".env",
    "data",
    "reports/output",
    "backups",
    "__pycache__",
    ".venv",
}


@dataclass
class CopilotSettings:
    provider: str = "offline"
    api_key: str = ""
    model: str = ""
    base_url: str = ""
    temperature: float = 0.2

    @classmethod
    def from_env(cls) -> "CopilotSettings":
        return cls(
            provider=os.getenv("AI_PROVIDER", "offline").strip() or "offline",
            api_key=os.getenv("AI_API_KEY", "").strip(),
            model=os.getenv("AI_MODEL", "").strip(),
            base_url=os.getenv("AI_BASE_URL", "").strip(),
            temperature=float(os.getenv("AI_TEMPERATURE", "0.2") or 0.2),
        )


def _read_csv(path: Path, nrows: int | None = None) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path, dtype={"stock_code": str}, nrows=nrows)
    except Exception:
        try:
            return pd.read_csv(path, nrows=nrows)
        except Exception:
            return pd.DataFrame()


def _safe_num(v: Any) -> float | None:
    try:
        if pd.isna(v):
            return None
        return float(v)
    except Exception:
        return None


def _latest_file_info(paths: list[Path]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for p in paths:
        if p.exists():
            out.append({
                "path": str(p),
                "size_kb": round(p.stat().st_size / 1024, 2),
                "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(p.stat().st_mtime)),
            })
    return out


def build_program_context(data_dir: Path, output_dir: Path, stock_code: str | None = None) -> dict[str, Any]:
    """Build a compact, token-conscious context for AI providers.

    The AI does not receive raw 3M-row CSV files. It receives summaries, schema,
    recent result snippets, and selected stock context only.
    """
    data_dir = Path(data_dir)
    output_dir = Path(output_dir)
    context: dict[str, Any] = {
        "program": {
            "name": "stock_swing_signal_engine",
            "purpose": "Korean stock swing/long-swing signal engine with multi-strategy analysis, backtesting, AI theme scanner, and terminal UI.",
            "strategies": ["vcp", "canslim", "stage2", "darvas", "deep_turnaround"],
            "principles": [
                "Do not blindly optimize on the test period.",
                "Preserve original strategy logic unless user explicitly approves a patch.",
                "Any code patch must be shown as a proposal first, then applied only after approval.",
                "Backtest changes must be checked with fees, tax, slippage, and benchmark comparison.",
            ],
        },
        "files": _latest_file_info([
            data_dir / "prices_daily.csv",
            data_dir / "universe.csv",
            data_dir / "financials.csv",
            data_dir / "supply_daily.csv",
            output_dir / "multi_strategy_portfolio.csv",
            output_dir / "multi_strategy_signals_all.csv",
            output_dir / "backtest_summary.csv",
            output_dir / "backtest_trades.csv",
            output_dir / "backtest_excess_summary.csv",
            output_dir / "backtest_entry_filter_audit.csv",
            output_dir / "algorithm_audit.csv",
            output_dir / "ai_theme_candidates.csv",
        ]),
    }
    prices = _read_csv(data_dir / "prices_daily.csv", nrows=5)
    if not prices.empty:
        context["data_schema_prices"] = list(prices.columns)
    full_prices = None
    if stock_code:
        # Read only selected symbol from the large CSV in chunks.
        rows = []
        try:
            for chunk in pd.read_csv(data_dir / "prices_daily.csv", dtype={"stock_code": str}, chunksize=200000):
                chunk["stock_code"] = chunk["stock_code"].astype(str).str.zfill(6)
                sub = chunk[chunk["stock_code"] == str(stock_code).zfill(6)]
                if not sub.empty:
                    rows.append(sub)
            if rows:
                full_prices = pd.concat(rows, ignore_index=True)
        except Exception:
            full_prices = None
    if full_prices is not None and not full_prices.empty:
        fp = full_prices.copy()
        fp["date"] = pd.to_datetime(fp["date"], errors="coerce")
        fp = fp.sort_values("date")
        for c in ["close", "volume", "trading_value"]:
            if c in fp:
                fp[c] = pd.to_numeric(fp[c], errors="coerce")
        last = fp.iloc[-1]
        stock_ctx = {
            "stock_code": str(stock_code).zfill(6),
            "last_date": str(last.get("date", ""))[:10],
            "latest_close": _safe_num(last.get("close")),
            "rows": int(len(fp)),
            "date_min": str(fp["date"].min())[:10],
            "date_max": str(fp["date"].max())[:10],
        }
        if "close" in fp:
            close = fp["close"]
            stock_ctx.update({
                "ret_20d_pct": _safe_num((close.iloc[-1] / close.iloc[-21] - 1) * 100) if len(close) > 21 and close.iloc[-21] else None,
                "ret_60d_pct": _safe_num((close.iloc[-1] / close.iloc[-61] - 1) * 100) if len(close) > 61 and close.iloc[-61] else None,
                "ret_252d_pct": _safe_num((close.iloc[-1] / close.iloc[-253] - 1) * 100) if len(close) > 253 and close.iloc[-253] else None,
                "drawdown_52w_pct": _safe_num((close.iloc[-1] / close.tail(252).max() - 1) * 100) if len(close) > 5 and close.tail(252).max() else None,
            })
        context["selected_stock"] = stock_ctx
    # Current portfolio/signals snippets.
    for name, fname, limit in [
        ("current_portfolio", "multi_strategy_portfolio.csv", 30),
        ("strategy_signals", "multi_strategy_signals_all.csv", 50),
        ("backtest_summary", "backtest_summary.csv", 5),
        ("backtest_excess", "backtest_excess_summary.csv", 10),
        ("entry_filter_audit", "backtest_entry_filter_audit.csv", 30),
        ("algorithm_audit", "algorithm_audit.csv", 10),
    ]:
        df = _read_csv(output_dir / fname)
        if not df.empty:
            context[name] = df.head(limit).fillna("").to_dict("records")
    if stock_code:
        trades = _read_csv(output_dir / "backtest_trades.csv")
        if not trades.empty and "stock_code" in trades:
            trades["stock_code"] = trades["stock_code"].astype(str).str.zfill(6)
            context["selected_stock_trades"] = trades[trades["stock_code"] == str(stock_code).zfill(6)].tail(20).fillna("").to_dict("records")
    return context


def build_system_prompt() -> str:
    return """
너는 사용자의 로컬 프로그램 'stock_swing_signal_engine' 전용 AI Copilot이다.
답변 언어는 한국어다. 역할은 종목 분석, 백테스트 진단, 전략 개선안 제안, 승인형 코드 패치 제안이다.
절대 지켜야 할 규칙:
1. 투자 조언을 확정적으로 말하지 말고, 신호/리스크/근거 중심으로 설명한다.
2. 기존 VCP, CANSLIM, Stage2, Darvas, Deep Turnaround 원형을 함부로 깨지 않는다.
3. 과거 데이터 과최적화 경고를 항상 고려한다. 테스트 구간을 반복 튜닝에 쓰지 말라고 경고한다.
4. 코드 수정이 필요하면 바로 적용하지 말고 JSON 패치 제안을 만든다.
5. 패치는 반드시 안전한 파일 범위 안에서만 제안한다.
6. API 키, 개인정보, .env 내용을 출력하지 않는다.
""".strip()


def build_task_prompt(tasks: list[str], user_prompt: str, context: dict[str, Any]) -> str:
    task_labels = {
        "stock_analysis": "선택 종목 분석",
        "backtest_diagnosis": "백테스트 진단",
        "strategy_improvement": "전략 개선안",
        "patch_proposal": "코드 패치 제안",
    }
    requested = [task_labels.get(t, t) for t in tasks]
    patch_schema = """
패치 제안이 필요한 경우, 답변 마지막에 아래 JSON 블록을 포함해라.
```json
{
  "title": "짧은 제목",
  "summary": "무엇을 왜 고치는지",
  "risk_level": "low|medium|high",
  "requires_backtest": true,
  "patches": [
    {
      "path": "configs/example.json 또는 strategies/example.py",
      "action": "replace|append|write",
      "find": "replace action일 때 정확히 찾을 기존 문자열",
      "replace": "replace action일 때 바꿀 문자열",
      "content": "append/write action일 때 추가 또는 새 파일 내용",
      "reason": "변경 이유"
    }
  ],
  "test_commands": ["python main.py backtest --strategies all"]
}
```
""".strip()
    return f"""
요청 작업: {', '.join(requested)}
사용자 요청: {user_prompt or '(별도 요청 없음)'}

프로그램 요약 컨텍스트(JSON):
{json.dumps(context, ensure_ascii=False, indent=2)[:24000]}

해야 할 일:
- 체크된 작업만 수행한다.
- 종목 분석은 현재 후보 신호, 백테스트 거래 이력, 진입가/손절가/목표가, 위험요인을 분리해서 설명한다.
- 백테스트 진단은 벤치마크, MDD, 거래 수, 초과수익, 과최적화 위험을 같이 본다.
- 전략 개선은 원형 보존/장기 스윙/공격형/10x 실험 프로필 중 어디를 바꿔야 하는지 구분한다.
- 패치 제안이 체크되어 있으면 실제 적용 가능한 JSON 패치 제안을 포함한다.

{patch_schema if 'patch_proposal' in tasks else ''}
""".strip()


def _post_json(url: str, headers: dict[str, str], payload: dict[str, Any], timeout: int = 80) -> dict[str, Any]:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", **headers}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def call_ai(settings: CopilotSettings, messages: list[dict[str, str]]) -> str:
    provider = (settings.provider or "offline").lower().strip()
    if provider in {"offline", "mock", "none"} or not settings.api_key and provider not in {"ollama", "local_ollama"}:
        return offline_copilot_response(messages)
    model = settings.model or {
        "openai": "gpt-4.1-mini",
        "openai_compatible": "gpt-4.1-mini",
        "ollama": "llama3.1",
        "local_ollama": "llama3.1",
    }.get(provider, "gpt-4.1-mini")
    try:
        if provider in {"openai", "openai_compatible", "deepseek", "openrouter", "groq"}:
            base = settings.base_url.strip().rstrip("/")
            if not base:
                if provider == "openai":
                    base = "https://api.openai.com/v1"
                else:
                    base = "https://api.openai.com/v1"
            url = base + "/chat/completions"
            payload = {"model": model, "messages": messages, "temperature": settings.temperature}
            data = _post_json(url, {"Authorization": f"Bearer {settings.api_key}"}, payload)
            return data.get("choices", [{}])[0].get("message", {}).get("content", "") or json.dumps(data, ensure_ascii=False)[:4000]
        if provider in {"ollama", "local_ollama"}:
            base = settings.base_url.strip().rstrip("/") or "http://127.0.0.1:11434"
            url = base + "/api/chat"
            payload = {"model": model, "messages": messages, "stream": False, "options": {"temperature": settings.temperature}}
            data = _post_json(url, {}, payload)
            return data.get("message", {}).get("content", "") or data.get("response", "") or json.dumps(data, ensure_ascii=False)[:4000]
    except urllib.error.HTTPError as e:
        return f"AI 호출 오류 HTTP {e.code}: {e.read().decode('utf-8', errors='ignore')[:2000]}"
    except Exception as e:
        return f"AI 호출 오류: {e}"
    return offline_copilot_response(messages)


def offline_copilot_response(messages: list[dict[str, str]]) -> str:
    prompt = messages[-1]["content"] if messages else ""
    # Very small deterministic fallback that still helps the user.
    lines = [
        "## 오프라인 Copilot 진단",
        "API 키가 없거나 provider가 offline이라 로컬 규칙 기반 진단만 수행했습니다.",
        "",
        "### 확인 포인트",
        "- 백테스트 결과는 반드시 벤치마크 대비 초과수익과 MDD를 같이 봐야 합니다.",
        "- 현재 후보 화면과 백테스트 실제 거래 화면을 분리해서 확인하세요.",
        "- 매수 화살표가 피벗보다 과도하게 위에 있으면 추격매수 필터를 강화해야 합니다.",
        "- 장기 스윙이면 작은 목표가 청산보다 20일선/50일선/30주선 추적이 더 일관됩니다.",
        "",
        "### 권장 개선안",
        "1. 원형 유지 모드에서는 손절/청산 기준을 직접 숫자로 변경하지 마세요.",
        "2. 공격형/10x 모드는 별도 실험 프로필로 분리하고, 테스트 구간 반복 튜닝을 금지하세요.",
        "3. 코드 변경은 아래 패치 제안처럼 문서/설정부터 작게 시작하는 것이 안전합니다.",
    ]
    if "패치" in prompt or "patch" in prompt or "코드" in prompt:
        proposal = {
            "title": "AI Copilot 오프라인 테스트 패치",
            "summary": "실제 AI 키 없이 패치 승인 흐름을 검증하기 위한 문서 파일 추가",
            "risk_level": "low",
            "requires_backtest": False,
            "patches": [
                {
                    "path": "docs/AI_COPILOT_OFFLINE_TEST.md",
                    "action": "write",
                    "content": "# AI Copilot Offline Test\n\n이 파일은 AI Copilot의 패치 미리보기/승인/백업 적용 흐름을 검증하기 위한 문서입니다.\n",
                    "reason": "패치 승인 기능 동작 검증",
                }
            ],
            "test_commands": ["python main.py serve"],
        }
        lines.append("\n```json\n" + json.dumps(proposal, ensure_ascii=False, indent=2) + "\n```")
    return "\n".join(lines)


def extract_patch_proposal(text: str) -> dict[str, Any] | None:
    candidates: list[str] = []
    for m in re.finditer(r"```json\s*(\{.*?\})\s*```", text, re.S | re.I):
        candidates.append(m.group(1))
    # Fallback: last large JSON object.
    if not candidates:
        m = re.search(r"(\{\s*\"title\".*\})", text, re.S)
        if m:
            candidates.append(m.group(1))
    for raw in candidates:
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict) and isinstance(obj.get("patches"), list):
                return obj
        except Exception:
            continue
    return None


def _is_safe_patch_path(path: str) -> tuple[bool, str]:
    p = Path(path)
    norm = str(p).replace("\\", "/").lstrip("/")
    if ".." in Path(norm).parts:
        return False, "상위 디렉터리 접근은 허용되지 않습니다."
    for blocked in BLOCKED_PATH_PARTS:
        if norm == blocked or norm.startswith(blocked + "/") or blocked in norm:
            return False, f"차단된 경로입니다: {blocked}"
    if not any(norm == d or norm.startswith(d + "/") for d in DEFAULT_ALLOWED_PATCH_DIRS) and norm not in {"main.py", "requirements.txt"}:
        return False, "허용된 코드/설정/문서 경로가 아닙니다."
    if p.suffix.lower() not in {".py", ".json", ".md", ".txt", ".html", ".css", ".js"}:
        return False, "허용되지 않은 파일 확장자입니다."
    return True, norm


def save_copilot_result(output_dir: Path, result_text: str, proposal: dict[str, Any] | None, metadata: dict[str, Any]) -> dict[str, Path | None]:
    output_dir.mkdir(parents=True, exist_ok=True)
    result_path = output_dir / "ai_copilot_result.md"
    result_path.write_text(result_text, encoding="utf-8")
    meta_path = output_dir / "ai_copilot_metadata.json"
    meta_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    proposal_path = None
    if proposal:
        proposal["created_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        proposal_path = output_dir / "ai_copilot_patch_proposal.json"
        proposal_path.write_text(json.dumps(proposal, ensure_ascii=False, indent=2), encoding="utf-8")
    html_path = output_dir / "ai_copilot_result.html"
    html_path.write_text(render_copilot_result_html(result_text, proposal), encoding="utf-8")
    return {"result": result_path, "metadata": meta_path, "proposal": proposal_path, "html": html_path}


def render_copilot_result_html(result_text: str, proposal: dict[str, Any] | None) -> str:
    import html
    patch_html = ""
    if proposal:
        rows = []
        for i, p in enumerate(proposal.get("patches", []), 1):
            ok, msg = _is_safe_patch_path(str(p.get("path", "")))
            rows.append(f"<tr><td>{i}</td><td>{html.escape(str(p.get('path','')))}</td><td>{html.escape(str(p.get('action','')))}</td><td>{'허용' if ok else '차단'} · {html.escape(msg)}</td><td>{html.escape(str(p.get('reason','')))}</td></tr>")
        patch_html = f"""
        <section class='panel'>
          <h2>패치 미리보기</h2>
          <p class='warn'>패치는 아직 적용되지 않았습니다. 내용을 확인한 뒤 승인하면 자동 백업 후 적용됩니다.</p>
          <table><thead><tr><th>#</th><th>파일</th><th>작업</th><th>검사</th><th>이유</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
          <details><summary>원본 JSON 보기</summary><pre>{html.escape(json.dumps(proposal, ensure_ascii=False, indent=2))}</pre></details>
          <form method='post' action='/ai-apply-patch'><label class='check'><input type='checkbox' name='approve' value='yes'> 위 패치를 승인합니다. 자동 백업 후 적용</label><button>승인 후 패치 적용</button></form>
        </section>
        """
    return f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><title>AI Copilot 결과</title>
<style>body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;background:#f5f7fb;color:#111827;margin:0}}.wrap{{max-width:1100px;margin:0 auto;padding:24px}}.panel{{background:#fff;border:1px solid #e5e7eb;border-radius:22px;padding:20px;margin:14px 0;box-shadow:0 12px 30px rgba(15,23,42,.06)}}pre{{white-space:pre-wrap;line-height:1.55;background:#0f172a;color:#e5e7eb;border-radius:16px;padding:18px;overflow:auto}}table{{width:100%;border-collapse:collapse}}th,td{{border-bottom:1px solid #e5e7eb;padding:10px;text-align:left;font-size:13px}}button{{background:#2563eb;color:white;border:0;border-radius:12px;padding:12px 16px;font-weight:900;cursor:pointer}}a{{color:#2563eb;font-weight:800;text-decoration:none}}.warn{{color:#b45309;background:#fffbeb;border-left:4px solid #f59e0b;border-radius:10px;padding:10px}}.check{{display:block;margin:12px 0}}</style></head><body><main class='wrap'><p><a href='/ai-copilot'>AI Copilot</a> · <a href='/'>홈</a> · <a href='/terminal'>터미널</a></p><section class='panel'><h1>AI Copilot 결과</h1><pre>{html.escape(result_text)}</pre></section>{patch_html}</main></body></html>"""


def run_copilot(data_dir: Path, output_dir: Path, tasks: list[str], stock_code: str | None, user_prompt: str, settings: CopilotSettings | None = None) -> dict[str, Any]:
    settings = settings or CopilotSettings.from_env()
    context = build_program_context(data_dir, output_dir, stock_code=stock_code)
    messages = [
        {"role": "system", "content": build_system_prompt()},
        {"role": "user", "content": build_task_prompt(tasks, user_prompt, context)},
    ]
    result_text = call_ai(settings, messages)
    proposal = extract_patch_proposal(result_text)
    metadata = {"tasks": tasks, "stock_code": stock_code, "provider": settings.provider, "model": settings.model, "created_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    paths = save_copilot_result(output_dir, result_text, proposal, metadata)
    return {"text": result_text, "proposal": proposal, "paths": {k: str(v) if v else None for k, v in paths.items()}, "metadata": metadata}


def apply_patch_proposal(project_root: Path, proposal_path: Path, backup_root: Path | None = None) -> dict[str, Any]:
    project_root = Path(project_root).resolve()
    backup_root = Path(backup_root or (project_root / "backups" / "ai_patches"))
    if not proposal_path.exists():
        raise FileNotFoundError(f"패치 제안 파일이 없습니다: {proposal_path}")
    proposal = json.loads(proposal_path.read_text(encoding="utf-8"))
    patches = proposal.get("patches", [])
    stamp = time.strftime("%Y%m%d_%H%M%S")
    backup_dir = backup_root / stamp
    backup_dir.mkdir(parents=True, exist_ok=True)
    applied = []
    skipped = []
    for patch in patches:
        rel = str(patch.get("path", "")).strip()
        ok, safe_or_reason = _is_safe_patch_path(rel)
        if not ok:
            skipped.append({"path": rel, "reason": safe_or_reason})
            continue
        rel = safe_or_reason
        target = (project_root / rel).resolve()
        if not str(target).startswith(str(project_root)):
            skipped.append({"path": rel, "reason": "프로젝트 루트 밖 경로"})
            continue
        action = str(patch.get("action", "")).lower().strip()
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            b = backup_dir / rel
            b.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, b)
        old = target.read_text(encoding="utf-8") if target.exists() else ""
        if action == "replace":
            find = str(patch.get("find", ""))
            replace = str(patch.get("replace", ""))
            if not find:
                skipped.append({"path": rel, "reason": "replace인데 find가 비어 있음"})
                continue
            if find not in old:
                skipped.append({"path": rel, "reason": "find 문자열을 찾지 못함"})
                continue
            new = old.replace(find, replace, 1)
        elif action == "append":
            content = str(patch.get("content", ""))
            if not content:
                skipped.append({"path": rel, "reason": "append content가 비어 있음"})
                continue
            new = old + ("\n" if old and not old.endswith("\n") else "") + content
        elif action == "write":
            content = str(patch.get("content", ""))
            if target.exists() and rel == "main.py":
                skipped.append({"path": rel, "reason": "main.py 전체 write는 위험해서 차단. replace를 사용하세요."})
                continue
            new = content
        else:
            skipped.append({"path": rel, "reason": f"지원하지 않는 action: {action}"})
            continue
        target.write_text(new, encoding="utf-8")
        applied.append({"path": rel, "action": action, "backup": str((backup_dir / rel) if (backup_dir / rel).exists() else "")})
    result = {"applied": applied, "skipped": skipped, "backup_dir": str(backup_dir), "proposal_title": proposal.get("title", "")}
    (project_root / "reports" / "output").mkdir(parents=True, exist_ok=True)
    (project_root / "reports" / "output" / "ai_copilot_patch_apply_result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
