"""
volume_data.py

거래량·거래대금 보정 모듈.
거래대금이 없는 네이버 가격 데이터는 close*volume으로 추정한다.
"""
from __future__ import annotations
from pathlib import Path
import pandas as pd


def ensure_volume_columns(prices: pd.DataFrame) -> pd.DataFrame:
    df = prices.copy()
    for col in ["volume", "trading_value", "close"]:
        if col not in df.columns:
            df[col] = 0.0
    df["volume"] = pd.to_numeric(df["volume"], errors="coerce").fillna(0.0)
    df["close"] = pd.to_numeric(df["close"], errors="coerce").fillna(0.0)
    df["trading_value"] = pd.to_numeric(df["trading_value"], errors="coerce")
    df["trading_value"] = df["trading_value"].fillna(df["close"] * df["volume"])
    return df


def save_volume_checked_prices(input_csv: str | Path, output_csv: str | Path) -> pd.DataFrame:
    df = pd.read_csv(input_csv, dtype={"stock_code": str})
    df = ensure_volume_columns(df)
    Path(output_csv).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_csv, index=False, encoding="utf-8-sig")
    return df
