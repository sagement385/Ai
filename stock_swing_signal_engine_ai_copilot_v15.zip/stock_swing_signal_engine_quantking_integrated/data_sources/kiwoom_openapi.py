"""
kiwoom_openapi.py

Kiwoom OpenAPI+를 이용해 stock_swing_signal_engine CSV를 만드는 선택형 Windows 전용 브리지.

업로드된 QuantKingSetup.zip 분석 결과:
- KHOpenAPI.ocx, Interop.KHOpenAPILib.dll, AxInterop.KHOpenAPILib.dll 포함
- exe 내부 문자열에 axKHOpenAPI1, CommRqData 계열, Kiwoom 로그인/계좌 UI 흔적 존재

이 모듈은 QuantKing 실행파일을 역공학해 복사한 코드가 아니라,
공개적으로 알려진 Kiwoom OpenAPI+ COM 인터페이스를 호출하는 독립 구현이다.
실행 조건:
1) Windows
2) Kiwoom OpenAPI+ 설치 및 OCX 등록
3) `pip install pywin32 pandas`
4) 영웅문/키움 로그인 가능 계정
"""
from __future__ import annotations

import os
import platform
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import pandas as pd

PRICE_COLUMNS = [
    "stock_code", "stock_name", "date", "open", "high", "low", "close", "volume", "trading_value"
]
SUPPLY_COLUMNS = [
    "stock_code", "date", "institution_net_buy_value", "foreign_net_buy_value",
    "pension_net_buy_value", "individual_net_buy_value", "trading_value", "source"
]


def normalize_code(code: str | int) -> str:
    return str(code).strip().replace("A", "").replace(".0", "").zfill(6)


@dataclass
class _EventState:
    connected: bool = False
    tr_received: bool = False
    last_rqname: str = ""
    last_trcode: str = ""
    last_record: str = ""
    last_prev_next: str = "0"
    error_code: int | None = None
    rows: list[dict[str, Any]] = field(default_factory=list)


def _require_windows_pywin32():
    if platform.system().lower() != "windows":
        raise RuntimeError("Kiwoom OpenAPI는 Windows 전용입니다. 현재 환경에서는 naver/kis/pykrx 수집을 사용하세요.")
    try:
        import pythoncom  # type: ignore
        import win32com.client  # type: ignore
        return pythoncom, win32com.client
    except Exception as exc:
        raise RuntimeError("pywin32가 필요합니다. Windows에서 `pip install pywin32` 후 다시 실행하세요.") from exc


class KiwoomOpenApiClient:
    """최소 기능만 담은 blocking Kiwoom COM client."""

    def __init__(self, request_interval: float | None = None):
        self.pythoncom, self.win32 = _require_windows_pywin32()
        self.state = _EventState()
        outer = self

        class KiwoomEvents:
            def OnEventConnect(self, err_code):
                outer.state.error_code = int(err_code)
                outer.state.connected = int(err_code) == 0

            def OnReceiveTrData(self, screen_no, rqname, trcode, record_name, prev_next, *args):
                outer.state.last_rqname = str(rqname)
                outer.state.last_trcode = str(trcode)
                outer.state.last_record = str(record_name)
                outer.state.last_prev_next = str(prev_next)
                outer.state.tr_received = True

        self.api = self.win32.DispatchWithEvents("KHOPENAPI.KHOpenAPICtrl.1", KiwoomEvents)
        # Kiwoom은 초당/분당 제한이 있어 보수적으로 둔다.
        self.request_interval = request_interval if request_interval is not None else float(os.getenv("KIWOOM_REQUEST_INTERVAL", "0.35"))

    def _pump_until(self, predicate, timeout: float = 60.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            self.pythoncom.PumpWaitingMessages()
            if predicate():
                return
            time.sleep(0.03)
        raise TimeoutError("Kiwoom OpenAPI 응답 대기 시간이 초과되었습니다.")

    def login(self, timeout: float = 90.0) -> None:
        self.state.connected = False
        self.api.CommConnect()
        self._pump_until(lambda: self.state.error_code is not None, timeout=timeout)
        if not self.state.connected:
            raise RuntimeError(f"Kiwoom 로그인 실패: err_code={self.state.error_code}")

    def _set_input(self, key: str, value: str) -> None:
        self.api.SetInputValue(key, value)

    def _comm_rq_data(self, rqname: str, trcode: str, prev_next: int, screen_no: str) -> str:
        self.state.tr_received = False
        ret = self.api.CommRqData(rqname, trcode, prev_next, screen_no)
        if int(ret) != 0:
            raise RuntimeError(f"CommRqData 실패: rqname={rqname}, trcode={trcode}, ret={ret}")
        self._pump_until(lambda: self.state.tr_received, timeout=30)
        time.sleep(self.request_interval)
        return self.state.last_prev_next

    def _get_repeat_cnt(self, trcode: str, rqname: str) -> int:
        try:
            return int(self.api.GetRepeatCnt(trcode, rqname))
        except Exception:
            return 0

    def _get_comm_data(self, trcode: str, rqname: str, index: int, item: str) -> str:
        try:
            return str(self.api.GetCommData(trcode, rqname, index, item)).strip()
        except Exception:
            return ""

    @staticmethod
    def _num(value: str) -> float:
        value = str(value).strip().replace(",", "")
        if value in {"", "-", "+"}:
            return 0.0
        try:
            return abs(float(value))
        except Exception:
            return 0.0

    @staticmethod
    def _signed_num(value: str) -> float:
        value = str(value).strip().replace(",", "")
        if value in {"", "-", "+"}:
            return 0.0
        try:
            return float(value)
        except Exception:
            return 0.0

    def get_master_name(self, stock_code: str) -> str:
        try:
            return str(self.api.GetMasterCodeName(normalize_code(stock_code))).strip() or normalize_code(stock_code)
        except Exception:
            return normalize_code(stock_code)

    def get_daily_prices(self, stock_code: str, stock_name: str = "", days: int = 250) -> pd.DataFrame:
        """OPT10081: 주식일봉차트조회요청."""
        code = normalize_code(stock_code)
        name = stock_name or self.get_master_name(code)
        rows: list[dict[str, Any]] = []
        prev_next = 0
        screen = "9101"
        while True:
            self._set_input("종목코드", code)
            self._set_input("기준일자", datetime.now().strftime("%Y%m%d"))
            self._set_input("수정주가구분", "1")
            next_flag = self._comm_rq_data("주식일봉차트조회요청", "opt10081", prev_next, screen)
            cnt = self._get_repeat_cnt("opt10081", "주식일봉차트조회요청")
            for i in range(cnt):
                date = self._get_comm_data("opt10081", "주식일봉차트조회요청", i, "일자")
                if not date:
                    continue
                close = self._num(self._get_comm_data("opt10081", "주식일봉차트조회요청", i, "현재가"))
                volume = self._num(self._get_comm_data("opt10081", "주식일봉차트조회요청", i, "거래량"))
                rows.append({
                    "stock_code": code,
                    "stock_name": name,
                    "date": pd.to_datetime(date, format="%Y%m%d").strftime("%Y-%m-%d"),
                    "open": self._num(self._get_comm_data("opt10081", "주식일봉차트조회요청", i, "시가")),
                    "high": self._num(self._get_comm_data("opt10081", "주식일봉차트조회요청", i, "고가")),
                    "low": self._num(self._get_comm_data("opt10081", "주식일봉차트조회요청", i, "저가")),
                    "close": close,
                    "volume": volume,
                    "trading_value": close * volume,
                })
            if len(rows) >= days or str(next_flag) != "2":
                break
            prev_next = 2
        return pd.DataFrame(rows, columns=PRICE_COLUMNS).drop_duplicates(["stock_code", "date"]).sort_values("date").tail(days)

    def get_investor_supply(self, stock_code: str, days: int = 250) -> pd.DataFrame:
        """OPT10059: 종목별 투자자/기관별 거래대금. Kiwoom 버전에 따라 컬럼명이 다를 수 있다."""
        code = normalize_code(stock_code)
        rows: list[dict[str, Any]] = []
        prev_next = 0
        screen = "9102"
        while True:
            self._set_input("일자", datetime.now().strftime("%Y%m%d"))
            self._set_input("종목코드", code)
            self._set_input("금액수량구분", "1")  # 1 금액, 2 수량
            self._set_input("매매구분", "0")      # 0 순매수
            self._set_input("단위구분", "1")      # 1 천주/백만원 계열
            next_flag = self._comm_rq_data("종목별투자자기관별요청", "opt10059", prev_next, screen)
            cnt = self._get_repeat_cnt("opt10059", "종목별투자자기관별요청")
            for i in range(cnt):
                date = self._get_comm_data("opt10059", "종목별투자자기관별요청", i, "일자")
                if not date:
                    continue
                individual = self._signed_num(self._get_comm_data("opt10059", "종목별투자자기관별요청", i, "개인투자자"))
                foreign = self._signed_num(self._get_comm_data("opt10059", "종목별투자자기관별요청", i, "외국인투자자"))
                inst = self._signed_num(self._get_comm_data("opt10059", "종목별투자자기관별요청", i, "기관계"))
                pension = self._signed_num(self._get_comm_data("opt10059", "종목별투자자기관별요청", i, "연기금등"))
                # Kiwoom 금액 단위가 보통 백만원 단위라 원 단위 근사로 맞춘다.
                scale = 1_000_000
                rows.append({
                    "stock_code": code,
                    "date": pd.to_datetime(date, format="%Y%m%d").strftime("%Y-%m-%d"),
                    "institution_net_buy_value": inst * scale,
                    "foreign_net_buy_value": foreign * scale,
                    "pension_net_buy_value": pension * scale,
                    "individual_net_buy_value": individual * scale,
                    "trading_value": 0.0,
                    "source": "kiwoom_opt10059",
                })
            if len(rows) >= days or str(next_flag) != "2":
                break
            prev_next = 2
        return pd.DataFrame(rows, columns=SUPPLY_COLUMNS).drop_duplicates(["stock_code", "date"]).sort_values("date").tail(days)


def download_prices_kiwoom(universe_csv: str | Path, output_csv: str | Path, days: int = 250, limit: int | None = None) -> pd.DataFrame:
    universe = pd.read_csv(universe_csv, dtype={"stock_code": str, "종목코드": str}).rename(columns={"종목코드": "stock_code", "종목명": "stock_name"})
    universe["stock_code"] = universe["stock_code"].map(normalize_code)
    if "stock_name" not in universe.columns:
        universe["stock_name"] = universe["stock_code"]
    if limit:
        universe = universe.head(limit)
    client = KiwoomOpenApiClient()
    client.login()
    frames = []
    failures = []
    for _, row in universe.iterrows():
        try:
            frames.append(client.get_daily_prices(row["stock_code"], row.get("stock_name", ""), days=days))
        except Exception as exc:
            failures.append((row["stock_code"], str(exc)[:160]))
    result = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=PRICE_COLUMNS)
    Path(output_csv).parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_csv, index=False, encoding="utf-8-sig")
    if failures:
        pd.DataFrame(failures, columns=["stock_code", "reason"]).to_csv(Path(output_csv).parent / "kiwoom_price_failures.csv", index=False, encoding="utf-8-sig")
    return result


def download_supply_kiwoom(universe_csv: str | Path, output_csv: str | Path, days: int = 250, limit: int | None = None) -> pd.DataFrame:
    universe = pd.read_csv(universe_csv, dtype={"stock_code": str, "종목코드": str}).rename(columns={"종목코드": "stock_code"})
    universe["stock_code"] = universe["stock_code"].map(normalize_code)
    if limit:
        universe = universe.head(limit)
    client = KiwoomOpenApiClient()
    client.login()
    frames = []
    failures = []
    for code in universe["stock_code"].tolist():
        try:
            frames.append(client.get_investor_supply(code, days=days))
        except Exception as exc:
            failures.append((code, str(exc)[:160]))
    result = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=SUPPLY_COLUMNS)
    Path(output_csv).parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_csv, index=False, encoding="utf-8-sig")
    if failures:
        pd.DataFrame(failures, columns=["stock_code", "reason"]).to_csv(Path(output_csv).parent / "kiwoom_supply_failures.csv", index=False, encoding="utf-8-sig")
    return result
