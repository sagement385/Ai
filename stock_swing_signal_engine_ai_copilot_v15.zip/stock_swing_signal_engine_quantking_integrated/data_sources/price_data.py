"""
price_data.py

가격·거래량 CSV 생성/정규화 모듈.
- API 없이: Naver Finance chart XML fallback
- API 사용: KIS 국내주식 기간별 시세 API
- 종목 목록: pykrx가 있으면 KRX에서 생성 가능

논문 연결:
- Mandelbrot / Cont: 수익률 분포·극단 변동 feature의 원천 데이터
- Brock et al. / Lo et al.: 횡보장, 박스권, 고점·저점 feature의 원천 데이터
"""
from __future__ import annotations

import csv
import os
import time
import json
import math
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from pathlib import Path
from typing import Iterable, Optional

import pandas as pd
import requests

DATA_COLUMNS = [
    "stock_code", "stock_name", "date", "open", "high", "low", "close", "volume", "trading_value"
]


def normalize_code(code: str | int) -> str:
    return str(code).strip().replace(".0", "").zfill(6)


def load_universe(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"universe.csv가 없습니다: {path}")
    df = pd.read_csv(path, dtype={"stock_code": str, "종목코드": str})
    rename = {"종목코드": "stock_code", "종목명": "stock_name", "회사명": "stock_name", "name": "stock_name", "시장구분": "market"}
    df = df.rename(columns=rename)
    if "stock_code" not in df.columns:
        raise ValueError("universe.csv에는 stock_code 컬럼이 필요합니다.")
    if "stock_name" not in df.columns:
        df["stock_name"] = df["stock_code"]
    if "market" not in df.columns:
        df["market"] = "UNKNOWN"
    df["stock_code"] = df["stock_code"].map(normalize_code)
    return df[["stock_code", "stock_name", "market"]].drop_duplicates("stock_code")


def create_universe_template(output_path: str | Path) -> None:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sample = pd.DataFrame([
        {"stock_code": "005930", "stock_name": "삼성전자", "market": "KOSPI"},
        {"stock_code": "000660", "stock_name": "SK하이닉스", "market": "KOSPI"},
        {"stock_code": "035420", "stock_name": "NAVER", "market": "KOSPI"},
    ])
    sample.to_csv(output_path, index=False, encoding="utf-8-sig")


def download_universe_pykrx(output_path: str | Path, markets: Iterable[str] = ("KOSPI", "KOSDAQ")) -> pd.DataFrame:
    """pykrx로 종목 유니버스 생성. pykrx가 없거나 KRX 접속 실패 시 예외를 던진다."""
    from pykrx import stock  # type: ignore

    rows = []
    today = datetime.now().strftime("%Y%m%d")
    for market in markets:
        tickers = stock.get_market_ticker_list(today, market=market)
        for ticker in tickers:
            rows.append({
                "stock_code": ticker,
                "stock_name": stock.get_market_ticker_name(ticker),
                "market": market,
            })
    df = pd.DataFrame(rows).drop_duplicates("stock_code")
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False, encoding="utf-8-sig")
    return df


def download_naver_price(stock_code: str, stock_name: str = "", days: int = 250, timeout: int = 10) -> pd.DataFrame:
    """네이버 차트 XML에서 일봉 데이터를 가져온다. 거래대금은 close*volume으로 추정."""
    stock_code = normalize_code(stock_code)
    url = "https://fchart.stock.naver.com/sise.nhn"
    params = {"symbol": stock_code, "timeframe": "day", "count": str(days), "requestType": "0"}
    resp = requests.get(url, params=params, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
    resp.raise_for_status()
    root = ET.fromstring(resp.text)
    rows = []
    for item in root.iter("item"):
        data = item.attrib.get("data", "")
        parts = data.split("|")
        if len(parts) < 6:
            continue
        date, open_, high, low, close, volume = parts[:6]
        rows.append({
            "stock_code": stock_code,
            "stock_name": stock_name or stock_code,
            "date": pd.to_datetime(date).strftime("%Y-%m-%d"),
            "open": float(open_),
            "high": float(high),
            "low": float(low),
            "close": float(close),
            "volume": float(volume),
            "trading_value": float(close) * float(volume),
        })
    return pd.DataFrame(rows, columns=DATA_COLUMNS)


def _kis_get_token(app_key: str, app_secret: str, base_url: str) -> str:
    cache_dir = Path("data/cache")
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_path = cache_dir / "kis_token_cache.json"
    if cache_path.exists():
        try:
            cached = json.loads(cache_path.read_text(encoding="utf-8"))
            if cached.get("expires_at", 0) > time.time() + 300:
                return cached["access_token"]
        except Exception:
            pass
    url = f"{base_url.rstrip('/')}/oauth2/tokenP"
    payload = {"grant_type": "client_credentials", "appkey": app_key, "appsecret": app_secret}
    resp = requests.post(url, json=payload, timeout=15)
    resp.raise_for_status()
    data = resp.json()
    token = data["access_token"]
    expires_in = int(data.get("expires_in", 86400))
    cache_path.write_text(json.dumps({"access_token": token, "expires_at": time.time() + expires_in}, ensure_ascii=False), encoding="utf-8")
    return token


def download_kis_price(stock_code: str, stock_name: str = "", days: int = 250, timeout: int = 15) -> pd.DataFrame:
    """KIS 국내주식 기간별 시세 API로 일봉을 받는다. KIS 키는 .env 또는 환경변수 필요."""
    app_key = os.getenv("KIS_APP_KEY", "").strip()
    app_secret = os.getenv("KIS_APP_SECRET", "").strip()
    base_url = os.getenv("KIS_BASE_URL", "https://openapi.koreainvestment.com:9443").strip()
    if not app_key or not app_secret:
        raise RuntimeError("KIS_APP_KEY/KIS_APP_SECRET이 없습니다. .env 또는 웹 설정에 입력하세요.")
    token = _kis_get_token(app_key, app_secret, base_url)
    end = datetime.now()
    start = end - timedelta(days=max(days * 2, 365))
    url = f"{base_url.rstrip('/')}/uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice"
    headers = {
        "content-type": "application/json; charset=utf-8",
        "authorization": f"Bearer {token}",
        "appkey": app_key,
        "appsecret": app_secret,
        "tr_id": "FHKST03010100",
    }
    params = {
        "FID_COND_MRKT_DIV_CODE": "J",
        "FID_INPUT_ISCD": normalize_code(stock_code),
        "FID_INPUT_DATE_1": start.strftime("%Y%m%d"),
        "FID_INPUT_DATE_2": end.strftime("%Y%m%d"),
        "FID_PERIOD_DIV_CODE": "D",
        "FID_ORG_ADJ_PRC": "0",
    }
    resp = requests.get(url, headers=headers, params=params, timeout=timeout)
    resp.raise_for_status()
    payload = resp.json()
    out = payload.get("output2") or []
    rows = []
    for r in out:
        try:
            close = float(r.get("stck_clpr", 0))
            volume = float(r.get("acml_vol", 0))
            trading_value = float(r.get("acml_tr_pbmn", 0)) if r.get("acml_tr_pbmn") else close * volume
            rows.append({
                "stock_code": normalize_code(stock_code),
                "stock_name": stock_name or normalize_code(stock_code),
                "date": pd.to_datetime(r.get("stck_bsop_date")).strftime("%Y-%m-%d"),
                "open": float(r.get("stck_oprc", 0)),
                "high": float(r.get("stck_hgpr", 0)),
                "low": float(r.get("stck_lwpr", 0)),
                "close": close,
                "volume": volume,
                "trading_value": trading_value,
            })
        except Exception:
            continue
    df = pd.DataFrame(rows, columns=DATA_COLUMNS)
    if not df.empty:
        df = df.sort_values("date").tail(days)
    return df


def download_prices(universe_csv: str | Path, output_csv: str | Path, source: str = "naver", days: int = 250, limit: Optional[int] = None) -> pd.DataFrame:
    universe = load_universe(universe_csv)
    if limit:
        universe = universe.head(limit)
    frames = []
    failures = []
    rate_limit = float(os.getenv("KIS_RATE_LIMIT_PER_SEC", "2") or 2)
    sleep_sec = max(0.05, 1.0 / max(rate_limit, 0.1))
    for idx, row in universe.iterrows():
        code = row["stock_code"]
        name = row["stock_name"]
        try:
            if source.lower() == "kis":
                df = download_kis_price(code, name, days=days)
                time.sleep(sleep_sec)
            else:
                df = download_naver_price(code, name, days=days)
                time.sleep(0.05)
            if df.empty:
                failures.append((code, "empty"))
            else:
                frames.append(df)
        except Exception as e:
            failures.append((code, str(e)[:120]))
    if frames:
        result = pd.concat(frames, ignore_index=True)
        result["stock_code"] = result["stock_code"].map(normalize_code)
        result = result.sort_values(["stock_code", "date"])
    else:
        result = pd.DataFrame(columns=DATA_COLUMNS)
    output_csv = Path(output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_csv, index=False, encoding="utf-8-sig")
    if failures:
        fail_path = output_csv.parent / "price_download_failures.csv"
        pd.DataFrame(failures, columns=["stock_code", "reason"]).to_csv(fail_path, index=False, encoding="utf-8-sig")
    return result


def read_prices(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path, dtype={"stock_code": str, "종목코드": str})
    df = df.rename(columns={"종목코드": "stock_code", "종목명": "stock_name", "회사명": "stock_name", "name": "stock_name", "날짜": "date", "시가": "open", "고가": "high", "저가": "low", "종가": "close", "거래량": "volume", "거래대금": "trading_value"})
    df["stock_code"] = df["stock_code"].map(normalize_code)
    df["date"] = pd.to_datetime(df["date"])
    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    if "trading_value" not in df.columns:
        df["trading_value"] = df["close"] * df["volume"]
    df["trading_value"] = pd.to_numeric(df["trading_value"], errors="coerce").fillna(df["close"] * df["volume"])
    if "stock_name" not in df.columns:
        df["stock_name"] = df["stock_code"]
    return df.dropna(subset=["date", "close"]).sort_values(["stock_code", "date"])
