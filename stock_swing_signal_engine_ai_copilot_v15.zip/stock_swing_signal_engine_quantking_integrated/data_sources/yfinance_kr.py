"""
yfinance_kr.py

국내 전체 주식(KOSPI/KOSDAQ 중심)의 1년 일봉을 yfinance로 내려받아
stock_swing_signal_engine 표준 CSV(prices_daily.csv, universe.csv)로 저장하는 모듈.

주의:
- yfinance는 Yahoo Finance 데이터를 사용하므로 일부 국내 종목은 누락될 수 있다.
- KOSPI는 .KS, KOSDAQ/KONEX는 .KQ suffix를 붙인다.
- 거래대금(trading_value)은 Yahoo에서 직접 주지 않으므로 close*volume으로 추정한다.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable, Sequence

import pandas as pd

DATA_COLUMNS = [
    "stock_code",
    "stock_name",
    "date",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "trading_value",
]


def normalize_code(code: str | int) -> str:
    return str(code).strip().replace(".0", "").zfill(6)


def yahoo_suffix_for_market(market: str) -> str:
    """KRX 시장구분을 Yahoo Finance suffix로 변환."""
    market_u = str(market or "").upper()
    if market_u == "KOSPI":
        return ".KS"
    # Yahoo는 KOSDAQ을 .KQ로 제공한다. KONEX는 제공 범위가 제한적이다.
    return ".KQ"


def to_yahoo_ticker(stock_code: str | int, market: str) -> str:
    return f"{normalize_code(stock_code)}{yahoo_suffix_for_market(market)}"


def chunked(values: Sequence[str], size: int) -> Iterable[list[str]]:
    for start in range(0, len(values), size):
        yield list(values[start:start + size])


def build_krx_universe(
    output_csv: str | Path = "data/csv_import/universe.csv",
    markets: Iterable[str] = ("KOSPI", "KOSDAQ"),
) -> pd.DataFrame:
    """pykrx로 국내 주식 유니버스를 생성한다."""
    from pykrx import stock  # type: ignore

    base_date = datetime.now().strftime("%Y%m%d")
    rows: list[dict[str, str]] = []
    for market in markets:
        tickers = stock.get_market_ticker_list(base_date, market=market)
        for ticker in tickers:
            rows.append(
                {
                    "stock_code": normalize_code(ticker),
                    "stock_name": stock.get_market_ticker_name(ticker),
                    "market": market,
                    "yahoo_ticker": to_yahoo_ticker(ticker, market),
                }
            )
    universe = pd.DataFrame(rows).drop_duplicates("stock_code").sort_values(["market", "stock_code"])
    output_csv = Path(output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    # 엔진 호환성을 위해 yahoo_ticker는 포함해도 되고, 분석기는 필요한 컬럼만 읽는다.
    universe.to_csv(output_csv, index=False, encoding="utf-8-sig")
    return universe


@dataclass
class YFinanceDownloadResult:
    universe: pd.DataFrame
    prices: pd.DataFrame
    failures: pd.DataFrame


def _normalize_yfinance_single_frame(
    raw: pd.DataFrame,
    stock_code: str,
    stock_name: str,
) -> pd.DataFrame:
    if raw is None or raw.empty:
        return pd.DataFrame(columns=DATA_COLUMNS)

    df = raw.copy()
    if isinstance(df.columns, pd.MultiIndex):
        # 단일 ticker 요청이어도 환경에 따라 MultiIndex가 올 수 있다.
        df.columns = [str(c[-1] if c[-1] else c[0]).lower() for c in df.columns]
    else:
        df.columns = [str(c).lower().replace(" ", "_") for c in df.columns]

    # yfinance는 auto_adjust=True면 adj_close가 없을 수 있다.
    rename = {
        "open": "open",
        "high": "high",
        "low": "low",
        "close": "close",
        "adj_close": "adj_close",
        "volume": "volume",
    }
    df = df.rename(columns=rename)
    required = ["open", "high", "low", "close", "volume"]
    missing = [col for col in required if col not in df.columns]
    if missing:
        return pd.DataFrame(columns=DATA_COLUMNS)

    out = df.reset_index()
    date_col = "Date" if "Date" in out.columns else "date" if "date" in out.columns else out.columns[0]
    out["date"] = pd.to_datetime(out[date_col]).dt.strftime("%Y-%m-%d")
    out["stock_code"] = normalize_code(stock_code)
    out["stock_name"] = stock_name or normalize_code(stock_code)
    for col in ["open", "high", "low", "close", "volume"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out["trading_value"] = out["close"] * out["volume"]
    out = out[DATA_COLUMNS].dropna(subset=["date", "close"])
    return out


def download_prices_yfinance(
    universe_csv: str | Path = "data/csv_import/universe.csv",
    output_csv: str | Path = "data/csv_import/prices_daily.csv",
    period: str = "1y",
    interval: str = "1d",
    batch_size: int = 50,
    sleep_sec: float = 1.0,
    limit: int | None = None,
    progress: bool = True,
) -> YFinanceDownloadResult:
    """universe.csv 기준으로 yfinance 일봉을 내려받아 prices_daily.csv로 저장한다."""
    import yfinance as yf  # type: ignore

    universe = pd.read_csv(universe_csv, dtype={"stock_code": str})
    if "market" not in universe.columns:
        universe["market"] = "KOSPI"
    if "stock_name" not in universe.columns:
        universe["stock_name"] = universe["stock_code"]
    universe["stock_code"] = universe["stock_code"].map(normalize_code)
    universe["yahoo_ticker"] = universe.apply(
        lambda r: r.get("yahoo_ticker") or to_yahoo_ticker(r["stock_code"], r.get("market", "KOSPI")),
        axis=1,
    )
    if limit:
        universe = universe.head(limit).copy()

    ticker_to_meta = {
        row["yahoo_ticker"]: {
            "stock_code": row["stock_code"],
            "stock_name": row.get("stock_name", row["stock_code"]),
            "market": row.get("market", ""),
        }
        for _, row in universe.iterrows()
    }

    frames: list[pd.DataFrame] = []
    failures: list[dict[str, str]] = []
    tickers = list(ticker_to_meta.keys())

    for batch_no, batch in enumerate(chunked(tickers, batch_size), start=1):
        if progress:
            print(f"[{batch_no}] yfinance 다운로드: {len(batch)}개 / 누적 {min(batch_no * batch_size, len(tickers))}/{len(tickers)}")
        try:
            raw = yf.download(
                tickers=batch,
                period=period,
                interval=interval,
                group_by="ticker",
                auto_adjust=False,
                threads=True,
                progress=False,
            )
        except Exception as exc:
            for ticker in batch:
                meta = ticker_to_meta[ticker]
                failures.append({"stock_code": meta["stock_code"], "yahoo_ticker": ticker, "reason": str(exc)[:200]})
            time.sleep(sleep_sec)
            continue

        for ticker in batch:
            meta = ticker_to_meta[ticker]
            try:
                if len(batch) == 1:
                    one = raw
                elif isinstance(raw.columns, pd.MultiIndex) and ticker in raw.columns.get_level_values(0):
                    one = raw[ticker]
                else:
                    failures.append({"stock_code": meta["stock_code"], "yahoo_ticker": ticker, "reason": "ticker missing in batch result"})
                    continue
                df = _normalize_yfinance_single_frame(one, meta["stock_code"], meta["stock_name"])
                if df.empty:
                    failures.append({"stock_code": meta["stock_code"], "yahoo_ticker": ticker, "reason": "empty or invalid OHLCV"})
                else:
                    frames.append(df)
            except Exception as exc:
                failures.append({"stock_code": meta["stock_code"], "yahoo_ticker": ticker, "reason": str(exc)[:200]})
        time.sleep(sleep_sec)

    prices = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=DATA_COLUMNS)
    if not prices.empty:
        prices = prices.sort_values(["stock_code", "date"]).drop_duplicates(["stock_code", "date"], keep="last")

    output_csv = Path(output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    prices.to_csv(output_csv, index=False, encoding="utf-8-sig")

    failures_df = pd.DataFrame(failures, columns=["stock_code", "yahoo_ticker", "reason"])
    failures_df.to_csv(output_csv.parent / "yfinance_download_failures.csv", index=False, encoding="utf-8-sig")
    universe.to_csv(output_csv.parent / "universe.csv", index=False, encoding="utf-8-sig")
    return YFinanceDownloadResult(universe=universe, prices=prices, failures=failures_df)


if __name__ == "__main__":
    build_krx_universe()
    result = download_prices_yfinance()
    print(f"universe: {len(result.universe):,} rows")
    print(f"prices: {len(result.prices):,} rows")
    print(f"failures: {len(result.failures):,} rows")
