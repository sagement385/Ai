"""
supply_data.py

기관/외국인/연기금 수급 CSV 생성·정규화 모듈.
API 키 없이 pykrx 기반으로 수집 가능하다.

논문 연결:
- Lakonishok, Shleifer & Vishny: 기관투자자 거래 영향, herding
- Chordia, Roll & Subrahmanyam: order imbalance, liquidity, returns
- Gabaix et al.: 큰 투자자 거래와 power-law 시장 변동
"""
from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
import time

import pandas as pd


def normalize_code(code: str | int) -> str:
    return str(code).strip().replace(".0", "").zfill(6)


def create_supply_template(output_path: str | Path) -> None:
    sample = pd.DataFrame([
        {"stock_code": "005930", "date": "2026-05-27", "institution_net_buy_value": 0, "foreign_net_buy_value": 0, "pension_net_buy_value": 0, "individual_net_buy_value": 0, "trading_value": 0, "source": "template"}
    ])
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    sample.iloc[0:0].to_csv(output_path, index=False, encoding="utf-8-sig")


def read_supply(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        return pd.DataFrame(columns=["stock_code", "date", "institution_net_buy_value", "foreign_net_buy_value", "pension_net_buy_value", "individual_net_buy_value", "trading_value", "source"])
    df = pd.read_csv(path, dtype={"stock_code": str, "종목코드": str})
    df = df.rename(columns={
        "종목코드": "stock_code",
        "날짜": "date",
        "기관순매수금액": "institution_net_buy_value",
        "외국인순매수금액": "foreign_net_buy_value",
        "연기금순매수금액": "pension_net_buy_value",
        "개인순매수금액": "individual_net_buy_value",
        "거래대금": "trading_value",
    })
    required = ["stock_code", "date", "institution_net_buy_value", "foreign_net_buy_value", "pension_net_buy_value", "individual_net_buy_value", "trading_value"]
    for col in required:
        if col not in df.columns:
            df[col] = 0
    df["stock_code"] = df["stock_code"].map(normalize_code)
    df["date"] = pd.to_datetime(df["date"])
    for col in required[2:]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)
    if "source" not in df.columns:
        df["source"] = "csv"
    return df.sort_values(["stock_code", "date"])


def download_supply_pykrx(universe_csv: str | Path, output_csv: str | Path, days: int = 250, limit: Optional[int] = None) -> pd.DataFrame:
    """pykrx로 개별종목 투자자별 거래대금을 수집한다. 네트워크/pykrx 필요."""
    from pykrx import stock  # type: ignore

    universe = pd.read_csv(universe_csv, dtype={"stock_code": str, "종목코드": str}).rename(columns={"종목코드": "stock_code"})
    universe["stock_code"] = universe["stock_code"].map(normalize_code)
    if limit:
        universe = universe.head(limit)
    end = datetime.now()
    start = end - timedelta(days=max(days * 2, 365))
    start_s, end_s = start.strftime("%Y%m%d"), end.strftime("%Y%m%d")
    rows = []
    failures = []
    for _, r in universe.iterrows():
        code = r["stock_code"]
        try:
            df = stock.get_market_trading_value_by_date(start_s, end_s, code, detail=True)
            if df is None or df.empty:
                failures.append((code, "empty")); continue
            df = df.tail(days).copy()
            df.index = pd.to_datetime(df.index)
            for dt, row in df.iterrows():
                # pykrx 컬럼명은 버전에 따라 조금씩 다를 수 있어 유연하게 처리
                foreign = float(row.get("외국인합계", row.get("외국인", 0)) or 0)
                individual = float(row.get("개인", 0) or 0)
                pension = float(row.get("연기금", row.get("연기금등", 0)) or 0)
                known_non_inst = {"개인", "외국인", "외국인합계", "기타법인", "전체"}
                inst_sum = 0.0
                for c, v in row.items():
                    if c not in known_non_inst:
                        try: inst_sum += float(v or 0)
                        except Exception: pass
                rows.append({
                    "stock_code": code,
                    "date": dt.strftime("%Y-%m-%d"),
                    "institution_net_buy_value": inst_sum,
                    "foreign_net_buy_value": foreign,
                    "pension_net_buy_value": pension,
                    "individual_net_buy_value": individual,
                    "trading_value": 0.0,
                    "source": "pykrx",
                })
            time.sleep(0.08)
        except Exception as e:
            failures.append((code, str(e)[:120]))
    result = pd.DataFrame(rows)
    Path(output_csv).parent.mkdir(parents=True, exist_ok=True)
    if not result.empty:
        result.to_csv(output_csv, index=False, encoding="utf-8-sig")
    else:
        create_supply_template(output_csv)
    if failures:
        pd.DataFrame(failures, columns=["stock_code", "reason"]).to_csv(Path(output_csv).parent / "supply_download_failures.csv", index=False, encoding="utf-8-sig")
    return result
