"""섹터/업종 주도주 순위 계산.

sector_map.csv가 있으면 해당 섹터를 사용하고, 없으면 market 단위로만 계산한다.
"""
from __future__ import annotations

from pathlib import Path
import pandas as pd


def normalize_code(code: str | int | float) -> str:
    return str(code).strip().replace(".0", "").zfill(6)


def read_sector_map(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        return pd.DataFrame(columns=["stock_code", "sector", "industry"])
    df = pd.read_csv(p, dtype={"stock_code": str, "종목코드": str}).rename(columns={"종목코드": "stock_code", "업종": "sector", "업종명": "sector", "industry_name": "industry"})
    if "sector" not in df.columns:
        df["sector"] = df.get("market", "UNKNOWN")
    if "industry" not in df.columns:
        df["industry"] = df["sector"]
    df["stock_code"] = df["stock_code"].map(normalize_code)
    return df[["stock_code", "sector", "industry"]].drop_duplicates("stock_code")


def build_sector_strength(prices: pd.DataFrame, sector_map: pd.DataFrame | None = None, output_csv: str | Path | None = None) -> pd.DataFrame:
    if prices is None or prices.empty:
        return pd.DataFrame()
    df = prices.copy()
    df["stock_code"] = df["stock_code"].map(normalize_code)
    df["date"] = pd.to_datetime(df["date"])
    df["close"] = pd.to_numeric(df["close"], errors="coerce")
    if "market" not in df.columns:
        df["market"] = "UNKNOWN"
    if sector_map is not None and not sector_map.empty:
        sm = sector_map.copy()
        sm["stock_code"] = sm["stock_code"].map(normalize_code)
        df = df.merge(sm[["stock_code", "sector"]], on="stock_code", how="left")
    if "sector" not in df.columns:
        df["sector"] = df["market"]
    df["sector"] = df["sector"].fillna(df["market"]).fillna("UNKNOWN")
    df = df.sort_values(["stock_code", "date"])
    for w in [20, 60, 120]:
        df[f"ret_{w}d"] = df.groupby("stock_code")["close"].pct_change(w) * 100
    latest = df.groupby("stock_code", as_index=False).tail(1)
    rows = []
    for sector, g in latest.groupby("sector", dropna=False):
        row = {"date": latest["date"].max().strftime("%Y-%m-%d"), "sector": sector, "stock_count": int(g["stock_code"].nunique())}
        for w in [20, 60, 120]:
            row[f"sector_ret_{w}d_median"] = float(pd.to_numeric(g[f"ret_{w}d"], errors="coerce").median())
        rows.append(row)
    out = pd.DataFrame(rows)
    if not out.empty:
        for w in [20, 60, 120]:
            out[f"sector_rank_{w}d"] = out[f"sector_ret_{w}d_median"].rank(ascending=False, method="min")
            out[f"sector_pct_rank_{w}d"] = out[f"sector_ret_{w}d_median"].rank(pct=True, ascending=True)
        out = out.sort_values("sector_rank_60d")
    if output_csv:
        p = Path(output_csv)
        p.parent.mkdir(parents=True, exist_ok=True)
        out.to_csv(p, index=False, encoding="utf-8-sig")
    return out
