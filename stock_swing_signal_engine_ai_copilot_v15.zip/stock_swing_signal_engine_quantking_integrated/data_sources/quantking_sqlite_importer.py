"""
quantking_sqlite_importer.py

QuantKing류 Windows 프로그램이 내부 SQLite DB에 저장한 종목/일봉 데이터를
stock_swing_signal_engine CSV 형식으로 변환하는 보조 모듈.

중요:
- 업로드된 QuantKingSetup.zip에는 실제 SQLite DB 파일이 없고, exe/dll만 있었다.
- 따라서 이 모듈은 사용자가 별도로 찾은 QuantKing 데이터베이스(.db/.sqlite)를
  변환하기 위한 안전한 브리지다.
- QuantKing 내부 컬럼명은 c101, c2002 같은 코드형 컬럼으로 보이며 버전에 따라
  다를 수 있다. 기본 매핑은 내부 문자열 분석에서 추정한 값이므로, 변환 후
  결과 CSV의 가격/거래량을 반드시 샘플 검증해야 한다.
"""
from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

PRICE_COLUMNS = [
    "stock_code", "stock_name", "date", "open", "high", "low", "close", "volume", "trading_value"
]

DEFAULT_COLUMN_MAP = {
    # QuantKing 문자열에서 `select c101`, `max(c2003)`, `min(c2004)` 사용 흔적이 확인됨.
    # c2003/c2004는 high/low 가능성이 높고, c101은 종가로 추정한다.
    # c2002/c602는 open/volume 추정치라 DB 샘플 확인 후 바꿀 수 있게 설계했다.
    "open": "c2002",
    "high": "c2003",
    "low": "c2004",
    "close": "c101",
    "volume": "c602",
    "date": "date",
    "code": "codeIdx",
}


@dataclass
class QuantKingImportResult:
    prices: pd.DataFrame
    universe: pd.DataFrame
    source_table: str
    warnings: list[str]


def _connect(db_path: str | Path) -> sqlite3.Connection:
    path = Path(db_path)
    if not path.exists():
        raise FileNotFoundError(f"SQLite DB 파일을 찾을 수 없습니다: {path}")
    return sqlite3.connect(str(path))


def list_sqlite_tables(db_path: str | Path) -> pd.DataFrame:
    """DB 안의 테이블과 컬럼을 요약한다."""
    with _connect(db_path) as con:
        tables = pd.read_sql_query(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name", con
        )
        rows: list[dict[str, Any]] = []
        for name in tables["name"].tolist():
            try:
                cols = pd.read_sql_query(f"PRAGMA table_info('{name}')", con)
                cnt = pd.read_sql_query(f"SELECT COUNT(*) AS n FROM '{name}'", con)["n"].iloc[0]
                rows.append({
                    "table": name,
                    "rows": int(cnt),
                    "columns": ",".join(cols["name"].astype(str).tolist()),
                })
            except Exception as exc:
                rows.append({"table": name, "rows": None, "columns": f"읽기 실패: {exc}"})
        return pd.DataFrame(rows)


def _table_columns(con: sqlite3.Connection, table: str) -> set[str]:
    cols = pd.read_sql_query(f"PRAGMA table_info('{table}')", con)
    return set(cols["name"].astype(str).tolist())


def _pick_price_table(con: sqlite3.Connection, column_map: dict[str, str]) -> str:
    tables = pd.read_sql_query(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name", con
    )["name"].astype(str).tolist()
    required = {column_map.get("date", "date"), column_map.get("code", "codeIdx"), column_map.get("close", "c101")}
    candidates: list[tuple[int, str]] = []
    for table in tables:
        cols = _table_columns(con, table)
        if required.issubset(cols):
            try:
                n = int(pd.read_sql_query(f"SELECT COUNT(*) AS n FROM '{table}'", con)["n"].iloc[0])
            except Exception:
                n = 0
            boost = 1000000000 if table.startswith("t_data") else 0
            candidates.append((boost + n, table))
    if not candidates:
        raise ValueError(
            "가격 테이블을 자동 탐지하지 못했습니다. `python main.py inspect-quantking-db --db 파일`로 "
            "테이블/컬럼을 확인한 뒤 --table 옵션과 --column-map을 지정하세요."
        )
    return sorted(candidates, reverse=True)[0][1]


def _normalize_code(value: Any) -> str:
    s = str(value).strip().replace(".0", "")
    digits = "".join(ch for ch in s if ch.isdigit())
    if len(digits) >= 6:
        return digits[-6:]
    return s.zfill(6) if s else ""


def _date_to_iso(value: Any) -> str | None:
    if pd.isna(value):
        return None
    s = str(value).strip().replace(".0", "")
    # QuantKing 계열은 보통 20260531 같은 정수 날짜를 사용한다.
    try:
        if len(s) == 8 and s.isdigit():
            return pd.to_datetime(s, format="%Y%m%d").strftime("%Y-%m-%d")
        return pd.to_datetime(value).strftime("%Y-%m-%d")
    except Exception:
        return None


def _read_company_map(con: sqlite3.Connection) -> tuple[pd.DataFrame, dict[str, dict[str, str]]]:
    """t_company_basic/t_company_user가 있으면 종목코드·종목명 맵을 만든다."""
    tables = set(pd.read_sql_query(
        "SELECT name FROM sqlite_master WHERE type='table'", con
    )["name"].astype(str))
    if "t_company_basic" not in tables:
        return pd.DataFrame(columns=["stock_code", "stock_name", "market"]), {}

    basic = pd.read_sql_query("SELECT * FROM t_company_basic", con)
    if basic.empty:
        return pd.DataFrame(columns=["stock_code", "stock_name", "market"]), {}

    # 자주 보이는 후보 컬럼들: idx, codeIdx, name, kosdaq, sectors
    idx_col = "idx" if "idx" in basic.columns else None
    code_col = "codeIdx" if "codeIdx" in basic.columns else None
    name_col = "name" if "name" in basic.columns else "stock_name" if "stock_name" in basic.columns else None
    market_col = "kosdaq" if "kosdaq" in basic.columns else "market" if "market" in basic.columns else None

    rows: list[dict[str, str]] = []
    mapping: dict[str, dict[str, str]] = {}
    for _, r in basic.iterrows():
        raw_code = r.get(code_col) if code_col else r.get(idx_col)
        stock_code = _normalize_code(raw_code)
        if not stock_code:
            continue
        stock_name = str(r.get(name_col, stock_code)) if name_col else stock_code
        market = "KOSDAQ" if market_col and str(r.get(market_col)) in {"1", "True", "true"} else "UNKNOWN"
        rows.append({"stock_code": stock_code, "stock_name": stock_name, "market": market})
        if idx_col:
            mapping[str(r.get(idx_col)).replace(".0", "")] = {"stock_code": stock_code, "stock_name": stock_name, "market": market}
        if code_col:
            mapping[str(r.get(code_col)).replace(".0", "")] = {"stock_code": stock_code, "stock_name": stock_name, "market": market}
    universe = pd.DataFrame(rows).drop_duplicates("stock_code") if rows else pd.DataFrame(columns=["stock_code", "stock_name", "market"])
    return universe, mapping


def _load_column_map(column_map_path: str | Path | None = None) -> dict[str, str]:
    mapping = dict(DEFAULT_COLUMN_MAP)
    if column_map_path:
        user_map = json.loads(Path(column_map_path).read_text(encoding="utf-8"))
        # example 파일처럼 최상위에 price_column_map이 있거나 바로 맵이 있는 경우 둘 다 지원
        if "price_column_map" in user_map:
            user_map = user_map["price_column_map"]
        mapping.update({k: v for k, v in user_map.items() if v})
    return mapping


def convert_quantking_sqlite_to_csv(
    db_path: str | Path,
    output_dir: str | Path = "data/csv_import",
    table: str | None = None,
    column_map_path: str | Path | None = None,
    limit_rows: int | None = None,
) -> QuantKingImportResult:
    """QuantKing SQLite DB를 engine CSV 2종(universe/prices_daily)으로 변환한다."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    column_map = _load_column_map(column_map_path)
    warnings: list[str] = []

    with _connect(db_path) as con:
        source_table = table or _pick_price_table(con, column_map)
        cols = _table_columns(con, source_table)
        missing = [v for k, v in column_map.items() if k in {"date", "code", "close"} and v not in cols]
        if missing:
            raise ValueError(f"필수 컬럼이 없습니다: {missing}. table={source_table}, columns={sorted(cols)}")
        optional_missing = [v for k, v in column_map.items() if k in {"open", "high", "low", "volume"} and v not in cols]
        if optional_missing:
            warnings.append(f"선택 컬럼 없음: {optional_missing}. close 또는 0으로 보완합니다.")

        select_cols = sorted({v for v in column_map.values() if v in cols})
        sql = f"SELECT {', '.join(select_cols)} FROM '{source_table}'"
        if limit_rows:
            sql += f" LIMIT {int(limit_rows)}"
        raw = pd.read_sql_query(sql, con)
        universe, code_map = _read_company_map(con)

    if raw.empty:
        prices = pd.DataFrame(columns=PRICE_COLUMNS)
    else:
        def col(name: str, fallback: Any = pd.NA) -> pd.Series:
            c = column_map.get(name)
            if c and c in raw.columns:
                return raw[c]
            return pd.Series([fallback] * len(raw))

        code_raw = col("code", "")
        mapped_codes = []
        mapped_names = []
        for v in code_raw:
            key = str(v).replace(".0", "").strip()
            info = code_map.get(key)
            if info:
                mapped_codes.append(info["stock_code"])
                mapped_names.append(info["stock_name"])
            else:
                mapped_codes.append(_normalize_code(v))
                mapped_names.append(_normalize_code(v))

        close = pd.to_numeric(col("close"), errors="coerce")
        open_ = pd.to_numeric(col("open", pd.NA), errors="coerce").fillna(close)
        high = pd.to_numeric(col("high", pd.NA), errors="coerce").fillna(pd.concat([open_, close], axis=1).max(axis=1))
        low = pd.to_numeric(col("low", pd.NA), errors="coerce").fillna(pd.concat([open_, close], axis=1).min(axis=1))
        volume = pd.to_numeric(col("volume", 0), errors="coerce").fillna(0)

        prices = pd.DataFrame({
            "stock_code": mapped_codes,
            "stock_name": mapped_names,
            "date": [_date_to_iso(v) for v in col("date")],
            "open": open_,
            "high": high,
            "low": low,
            "close": close,
            "volume": volume,
        })
        prices = prices.dropna(subset=["stock_code", "date", "close"])
        prices["trading_value"] = prices["close"] * prices["volume"]
        prices = prices[PRICE_COLUMNS].sort_values(["stock_code", "date"])

        if universe.empty:
            universe = prices[["stock_code", "stock_name"]].drop_duplicates("stock_code")
            universe["market"] = "UNKNOWN"

    prices.to_csv(output_dir / "prices_daily.csv", index=False, encoding="utf-8-sig")
    universe.to_csv(output_dir / "universe.csv", index=False, encoding="utf-8-sig")
    if warnings:
        (output_dir / "quantking_import_warnings.txt").write_text("\n".join(warnings), encoding="utf-8")
    return QuantKingImportResult(prices=prices, universe=universe, source_table=source_table, warnings=warnings)


def write_table_inventory(db_path: str | Path, output_path: str | Path) -> pd.DataFrame:
    inv = list_sqlite_tables(db_path)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    inv.to_csv(output_path, index=False, encoding="utf-8-sig")
    return inv
