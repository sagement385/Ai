"""
financial_data.py

재무 CSV 생성·정규화 모듈.
1차 목적은 '추천 가점'보다 부실/가치함정 제거다.
"""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
from typing import Optional
import pandas as pd


def normalize_code(code: str | int) -> str:
    return str(code).strip().replace(".0", "").zfill(6)


def create_financial_template(output_path: str | Path) -> None:
    sample = pd.DataFrame(columns=["stock_code", "stock_name", "PER", "PBR", "ROE", "debt_ratio", "operating_profit", "net_income", "market_cap"])
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    sample.to_csv(output_path, index=False, encoding="utf-8-sig")


def read_financials(path: str | Path) -> pd.DataFrame:
    if not Path(path).exists():
        return pd.DataFrame(columns=["stock_code", "stock_name", "PER", "PBR", "ROE", "debt_ratio", "operating_profit", "net_income", "market_cap"])
    df = pd.read_csv(path, dtype={"stock_code": str, "종목코드": str})
    df = df.rename(columns={"종목코드": "stock_code", "종목명": "stock_name", "시가총액": "market_cap", "부채비율": "debt_ratio", "영업이익": "operating_profit", "순이익": "net_income"})
    if "stock_code" not in df.columns:
        return pd.DataFrame()
    df["stock_code"] = df["stock_code"].map(normalize_code)
    for col in ["PER", "PBR", "ROE", "debt_ratio", "operating_profit", "net_income", "market_cap"]:
        if col not in df.columns: df[col] = pd.NA
        df[col] = pd.to_numeric(df[col], errors="coerce")
    if "stock_name" not in df.columns:
        df["stock_name"] = df["stock_code"]
    return df.drop_duplicates("stock_code")


def download_financials_pykrx(universe_csv: str | Path, output_csv: str | Path) -> pd.DataFrame:
    from pykrx import stock  # type: ignore
    date = datetime.now().strftime("%Y%m%d")
    f = stock.get_market_fundamental_by_ticker(date, market="ALL").reset_index().rename(columns={"티커": "stock_code"})
    cap = stock.get_market_cap_by_ticker(date, market="ALL").reset_index().rename(columns={"티커": "stock_code", "시가총액": "market_cap"})
    universe = pd.read_csv(universe_csv, dtype={"stock_code": str, "종목코드": str}).rename(columns={"종목코드": "stock_code", "종목명": "stock_name"})
    universe["stock_code"] = universe["stock_code"].map(normalize_code)
    f["stock_code"] = f["stock_code"].map(normalize_code)
    cap["stock_code"] = cap["stock_code"].map(normalize_code)
    out = universe[["stock_code", "stock_name"]].merge(f, on="stock_code", how="left").merge(cap[["stock_code", "market_cap"]], on="stock_code", how="left")
    out = out.rename(columns={"PER": "PER", "PBR": "PBR"})
    for col in ["ROE", "debt_ratio", "operating_profit", "net_income"]:
        if col not in out.columns: out[col] = pd.NA
    cols = ["stock_code", "stock_name", "PER", "PBR", "ROE", "debt_ratio", "operating_profit", "net_income", "market_cap"]
    out = out[cols]
    Path(output_csv).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_csv, index=False, encoding="utf-8-sig")
    return out
