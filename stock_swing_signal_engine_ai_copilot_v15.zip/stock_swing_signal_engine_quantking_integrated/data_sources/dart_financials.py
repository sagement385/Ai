"""OpenDART 분기 재무 CSV 수집기.

목적
- CANSLIM의 분기 매출/영업이익/순이익 성장률을 CSV로 저장한다.
- 전체 2,000~3,000개 종목을 part/parts로 분할 수집할 수 있다.
- API 호출 결과는 data/csv_import/dart_cache 에 원본 JSON으로 캐시한다.

주의
- OpenDART 인증키가 필요하다.
- 네트워크/API 응답은 실행 환경에 따라 달라질 수 있으므로 실패 목록을 CSV로 남긴다.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable, Any
import json
import math
import os
import re
import time
import zipfile
import xml.etree.ElementTree as ET

import pandas as pd
import requests

DART_BASE = "https://opendart.fss.or.kr/api"
REPORT_CODES = {
    "Q1": "11013",
    "H1": "11012",
    "Q3": "11014",
    "FY": "11011",
}
REPORT_LABELS = {v: k for k, v in REPORT_CODES.items()}


def normalize_code(code: str | int | float) -> str:
    if pd.isna(code):
        return ""
    s = str(code).strip().replace(".0", "")
    return s.zfill(6) if s.isdigit() else s


def _to_number(v: Any) -> float | None:
    if v is None:
        return None
    s = str(v).strip()
    if s in {"", "-", "nan", "None"}:
        return None
    s = s.replace(",", "").replace(" ", "")
    # DART 음수는 (123) 형태로 표시되는 경우가 있다.
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()")
    try:
        x = float(s)
        return -x if neg else x
    except Exception:
        return None


def _safe_div(a: float | None, b: float | None) -> float | None:
    if a is None or b in (None, 0):
        return None
    try:
        return a / b
    except Exception:
        return None


def _clean_account_name(name: str) -> str:
    return re.sub(r"[\s\[\]\(\)\-_/·ㆍ]", "", str(name).lower())


def _is_revenue(name: str) -> bool:
    n = _clean_account_name(name)
    return any(k in n for k in ["매출액", "수익매출", "영업수익", "영업수익매출"])


def _is_operating_income(name: str) -> bool:
    n = _clean_account_name(name)
    return "영업이익" in n or "영업손실" in n


def _is_net_income(name: str) -> bool:
    n = _clean_account_name(name)
    # 지배기업 소유주지분 순이익이 있으면 더 좋지만, 일단 당기순이익 계열을 사용한다.
    return ("당기순이익" in n or "분기순이익" in n or "반기순이익" in n or "연결당기순이익" in n) and "기타" not in n


def _is_eps(name: str) -> bool:
    n = _clean_account_name(name)
    return "기본주당" in n or n in {"주당이익", "eps"} or "기본주당이익" in n


def _is_assets(name: str) -> bool:
    n = _clean_account_name(name)
    return n in {"자산총계", "총자산"}


def _is_liabilities(name: str) -> bool:
    n = _clean_account_name(name)
    return n in {"부채총계", "총부채"}


def _is_equity(name: str) -> bool:
    n = _clean_account_name(name)
    return n in {"자본총계", "총자본"}


@dataclass
class DartDownloadResult:
    quarterly: pd.DataFrame
    summary: pd.DataFrame
    failures: pd.DataFrame
    part_file: Path
    merged_file: Path


def download_corp_codes(api_key: str, cache_dir: str | Path) -> pd.DataFrame:
    """OpenDART corpCode.xml을 받아 stock_code-corp_code 매핑을 만든다."""
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    csv_path = cache_dir / "corp_codes.csv"
    if csv_path.exists() and csv_path.stat().st_size > 0:
        df = pd.read_csv(csv_path, dtype={"stock_code": str, "corp_code": str})
        if not df.empty:
            return df

    url = f"{DART_BASE}/corpCode.xml"
    r = requests.get(url, params={"crtfc_key": api_key}, timeout=60)
    r.raise_for_status()
    zpath = cache_dir / "corpCode.zip"
    zpath.write_bytes(r.content)
    with zipfile.ZipFile(zpath) as zf:
        xml_bytes = zf.read(zf.namelist()[0])
    root = ET.fromstring(xml_bytes)
    rows = []
    for item in root.findall("list"):
        stock_code = (item.findtext("stock_code") or "").strip()
        if not stock_code:
            continue
        rows.append({
            "corp_code": (item.findtext("corp_code") or "").strip(),
            "corp_name": (item.findtext("corp_name") or "").strip(),
            "stock_code": normalize_code(stock_code),
            "modify_date": (item.findtext("modify_date") or "").strip(),
        })
    df = pd.DataFrame(rows).drop_duplicates("stock_code")
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    return df


def _request_financial(api_key: str, corp_code: str, year: int, report_code: str, fs_div: str, cache_dir: Path) -> dict[str, Any]:
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / f"{corp_code}_{year}_{report_code}_{fs_div}.json"
    if cache_file.exists() and cache_file.stat().st_size > 0:
        try:
            return json.loads(cache_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    url = f"{DART_BASE}/fnlttSinglAcntAll.json"
    params = {
        "crtfc_key": api_key,
        "corp_code": corp_code,
        "bsns_year": str(year),
        "reprt_code": report_code,
        "fs_div": fs_div,
    }
    data = requests.get(url, params=params, timeout=40).json()
    cache_file.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return data


def _extract_accounts(rows: list[dict[str, Any]]) -> dict[str, float | None]:
    out = {
        "revenue": None,
        "operating_income": None,
        "net_income": None,
        "eps": None,
        "assets": None,
        "liabilities": None,
        "equity": None,
    }
    # CFS/OFS 전체 계정에서 우선순위에 따라 첫 매칭값을 사용한다.
    for row in rows:
        name = row.get("account_nm", "")
        value = _to_number(row.get("thstrm_amount"))
        if value is None:
            continue
        if out["revenue"] is None and _is_revenue(name):
            out["revenue"] = value
        elif out["operating_income"] is None and _is_operating_income(name):
            out["operating_income"] = value
        elif out["net_income"] is None and _is_net_income(name):
            out["net_income"] = value
        elif out["eps"] is None and _is_eps(name):
            out["eps"] = value
        elif out["assets"] is None and _is_assets(name):
            out["assets"] = value
        elif out["liabilities"] is None and _is_liabilities(name):
            out["liabilities"] = value
        elif out["equity"] is None and _is_equity(name):
            out["equity"] = value
    return out


def _years_to_collect(years: int, end_year: int | None = None) -> list[int]:
    end_year = end_year or datetime.now().year
    return list(range(end_year - years + 1, end_year + 1))


def _partition(df: pd.DataFrame, part: int, parts: int) -> pd.DataFrame:
    if parts <= 1:
        return df
    if part < 1 or part > parts:
        raise ValueError(f"part는 1~{parts} 사이여야 합니다.")
    idx = pd.Series(range(len(df)), index=df.index)
    return df[(idx % parts) == (part - 1)].copy()


def _add_growth(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    df = df.sort_values(["stock_code", "report_code", "year"]).copy()
    for col in ["revenue", "operating_income", "net_income", "eps"]:
        prev = df.groupby(["stock_code", "report_code"])[col].shift(1)
        df[f"{col}_yoy"] = (df[col] / prev - 1.0) * 100.0
    df["roe"] = df.apply(lambda r: (_safe_div(r.get("net_income"), r.get("equity")) or math.nan) * 100, axis=1)
    df["debt_ratio"] = df.apply(lambda r: (_safe_div(r.get("liabilities"), r.get("equity")) or math.nan) * 100, axis=1)
    return df


def _build_summary(quarterly: pd.DataFrame) -> pd.DataFrame:
    if quarterly.empty:
        return pd.DataFrame()
    q = quarterly.sort_values(["stock_code", "year", "report_order"]).copy()
    latest = q.groupby("stock_code", as_index=False).tail(1).copy()
    cols = [
        "stock_code", "stock_name", "corp_code", "year", "quarter", "report_code",
        "revenue", "operating_income", "net_income", "eps",
        "revenue_yoy", "operating_income_yoy", "net_income_yoy", "eps_yoy",
        "roe", "debt_ratio",
    ]
    for c in cols:
        if c not in latest.columns:
            latest[c] = pd.NA
    out = latest[cols].rename(columns={
        "operating_income": "operating_profit",
        "revenue_yoy": "sales_growth_yoy",
        "operating_income_yoy": "operating_profit_yoy",
    })
    return out.reset_index(drop=True)


def merge_quarterly_files(output_csv: str | Path, part_dir: str | Path) -> pd.DataFrame:
    output_csv = Path(output_csv)
    part_dir = Path(part_dir)
    frames = []
    for p in sorted(part_dir.glob("financial_quarterly_part*.csv")):
        try:
            frames.append(pd.read_csv(p, dtype={"stock_code": str, "corp_code": str}))
        except Exception:
            pass
    if output_csv.exists():
        try:
            frames.append(pd.read_csv(output_csv, dtype={"stock_code": str, "corp_code": str}))
        except Exception:
            pass
    if not frames:
        return pd.DataFrame()
    merged = pd.concat(frames, ignore_index=True)
    key = ["stock_code", "corp_code", "year", "report_code", "fs_div"]
    for c in key:
        if c not in merged.columns:
            merged[c] = ""
    merged = merged.drop_duplicates(key, keep="last")
    merged = _add_growth(merged)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(output_csv, index=False, encoding="utf-8-sig")
    summary = _build_summary(merged)
    summary_path = output_csv.parent / "financials.csv"
    summary.to_csv(summary_path, index=False, encoding="utf-8-sig")
    return merged


def download_dart_financials(
    api_key: str,
    universe_csv: str | Path,
    output_csv: str | Path,
    years: int = 5,
    part: int = 1,
    parts: int = 3,
    limit: int | None = None,
    sleep_sec: float = 0.15,
    fs_div_preference: tuple[str, ...] = ("CFS", "OFS"),
) -> DartDownloadResult:
    """분기 재무를 part 단위로 수집하고 financial_quarterly.csv/financials.csv를 저장한다."""
    if not api_key:
        raise ValueError("DART_API_KEY가 없습니다. UI 또는 .env에 키를 저장하세요.")
    universe_csv = Path(universe_csv)
    output_csv = Path(output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    cache_dir = output_csv.parent / "dart_cache"
    corp_codes = download_corp_codes(api_key, cache_dir)

    universe = pd.read_csv(universe_csv, dtype={"stock_code": str, "종목코드": str}).rename(columns={"종목코드": "stock_code", "종목명": "stock_name", "name": "stock_name"})
    if "stock_name" not in universe.columns:
        universe["stock_name"] = universe.get("name", universe.get("stock_code", ""))
    universe["stock_code"] = universe["stock_code"].map(normalize_code)
    work = universe.merge(corp_codes[["stock_code", "corp_code", "corp_name"]], on="stock_code", how="inner")
    work = work.drop_duplicates("stock_code").sort_values("stock_code").reset_index(drop=True)
    if limit:
        work = work.head(limit)
    work = _partition(work, part=part, parts=parts).reset_index(drop=True)

    target_years = _years_to_collect(years)
    rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    report_items = list(REPORT_CODES.items())

    total = len(work) * len(target_years) * len(report_items)
    done = 0
    for _, s in work.iterrows():
        code = normalize_code(s["stock_code"])
        name = str(s.get("stock_name") or s.get("corp_name") or code)
        corp_code = str(s["corp_code"])
        for year in target_years:
            for order, (quarter, report_code) in enumerate(report_items, start=1):
                done += 1
                ok = False
                last_status = ""
                for fs_div in fs_div_preference:
                    try:
                        data = _request_financial(api_key, corp_code, year, report_code, fs_div, cache_dir / "financial_json")
                        status = str(data.get("status", ""))
                        last_status = f"{status}:{data.get('message','')}"
                        if status != "000" or not data.get("list"):
                            continue
                        acc = _extract_accounts(data.get("list", []))
                        rows.append({
                            "stock_code": code,
                            "stock_name": name,
                            "corp_code": corp_code,
                            "year": year,
                            "quarter": quarter,
                            "report_code": report_code,
                            "report_order": order,
                            "fs_div": fs_div,
                            **acc,
                            "source": "opendart",
                        })
                        ok = True
                        break
                    except Exception as e:
                        last_status = str(e)[:180]
                    time.sleep(max(0.0, sleep_sec))
                if not ok:
                    failures.append({
                        "stock_code": code,
                        "stock_name": name,
                        "corp_code": corp_code,
                        "year": year,
                        "quarter": quarter,
                        "report_code": report_code,
                        "reason": last_status,
                    })
                if done % 100 == 0:
                    print(f"DART 수집 진행: {done}/{total} requests · rows={len(rows)} · failures={len(failures)}")

    quarterly = pd.DataFrame(rows)
    quarterly = _add_growth(quarterly) if not quarterly.empty else quarterly
    failures_df = pd.DataFrame(failures)
    part_dir = output_csv.parent / "dart_parts"
    part_dir.mkdir(parents=True, exist_ok=True)
    part_file = part_dir / f"financial_quarterly_part{part}_of_{parts}.csv"
    quarterly.to_csv(part_file, index=False, encoding="utf-8-sig")
    failures_file = part_dir / f"financial_quarterly_failures_part{part}_of_{parts}.csv"
    failures_df.to_csv(failures_file, index=False, encoding="utf-8-sig")
    merged = merge_quarterly_files(output_csv, part_dir)
    summary = _build_summary(merged)
    return DartDownloadResult(quarterly=quarterly, summary=summary, failures=failures_df, part_file=part_file, merged_file=output_csv)
