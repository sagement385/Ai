"""일봉 prices_daily.csv를 주봉으로 변환하고 Weinstein 30주선 지표를 만든다."""
from __future__ import annotations

from pathlib import Path
import pandas as pd


def normalize_code(code: str | int | float) -> str:
    return str(code).strip().replace(".0", "").zfill(6)


def build_weekly_prices(prices: pd.DataFrame, output_csv: str | Path | None = None) -> pd.DataFrame:
    if prices is None or prices.empty:
        return pd.DataFrame()
    df = prices.copy()
    df["stock_code"] = df["stock_code"].map(normalize_code)
    if "stock_name" not in df.columns:
        df["stock_name"] = df.get("name", df["stock_code"])
    if "market" not in df.columns:
        df["market"] = "UNKNOWN"
    if "yf_ticker" not in df.columns:
        df["yf_ticker"] = ""
    df["date"] = pd.to_datetime(df["date"])
    for col in ["open", "high", "low", "close", "volume", "trading_value"]:
        if col not in df.columns:
            df[col] = 0
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["date", "close"]).sort_values(["stock_code", "date"]).reset_index(drop=True)
    # pandas resample을 종목별 루프로 돌리면 2700개 종목에서 느리다. W-FRI period key로 vectorized groupby 처리.
    df["week_date"] = df["date"].dt.to_period("W-FRI").dt.end_time.dt.normalize()
    weekly = (
        df.groupby(["stock_code", "week_date"], sort=False)
        .agg({
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
            "volume": "sum",
            "trading_value": "sum",
            "stock_name": "last",
            "market": "last",
            "yf_ticker": "last",
        })
        .reset_index()
        .rename(columns={"week_date": "date"})
        .sort_values(["stock_code", "date"])
        .reset_index(drop=True)
    )
    g = weekly.groupby("stock_code", sort=False)
    weekly["ma_10w"] = g["close"].rolling(10, min_periods=6).mean().reset_index(level=0, drop=True)
    weekly["ma_30w"] = g["close"].rolling(30, min_periods=20).mean().reset_index(level=0, drop=True)
    weekly["ma_40w"] = g["close"].rolling(40, min_periods=26).mean().reset_index(level=0, drop=True)
    weekly["ma_30w_slope_4w"] = g["ma_30w"].diff(4)
    high_shift = g["high"].shift(1)
    weekly["_high_shift"] = high_shift
    weekly["high_26w_prev"] = weekly.groupby("stock_code", sort=False)["_high_shift"].rolling(26, min_periods=10).max().reset_index(level=0, drop=True)
    weekly["high_52w_prev"] = weekly.groupby("stock_code", sort=False)["_high_shift"].rolling(52, min_periods=20).max().reset_index(level=0, drop=True)
    weekly["volume_10w"] = g["volume"].rolling(10, min_periods=4).mean().reset_index(level=0, drop=True)
    weekly["volume_30w"] = g["volume"].rolling(30, min_periods=10).mean().reset_index(level=0, drop=True)
    weekly["stage2_weekly"] = (
        (weekly["close"] > weekly["ma_30w"]) &
        (weekly["ma_30w_slope_4w"] > 0) &
        ((weekly["close"] >= weekly["high_26w_prev"] * 0.98) | (weekly["close"] >= weekly["high_52w_prev"] * 0.95))
    )
    weekly = weekly.drop(columns=["_high_shift"], errors="ignore")
    if output_csv:
        out = Path(output_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        weekly.to_csv(out, index=False, encoding="utf-8-sig")
    return weekly.reset_index(drop=True)
