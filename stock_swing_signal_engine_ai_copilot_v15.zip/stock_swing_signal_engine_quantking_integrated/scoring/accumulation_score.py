"""accumulation_score.py - 조용한 매집 점수화."""
from __future__ import annotations
import pandas as pd
import numpy as np


def score_accumulation(features: pd.DataFrame) -> pd.DataFrame:
    df = features.copy()
    def row_score(r):
        s = 40
        if r.get("obv_trend_positive", 0) > 0: s += 20
        uv = r.get("up_down_volume_ratio_20", np.nan)
        if pd.notna(uv): s += np.clip((uv - 1.0) * 20, -15, 20)
        if r.get("higher_low", 0) > 0: s += 10
        if r.get("quiet_accumulation", 0) > 0: s += 25
        # 가격이 이미 60일 30% 이상 오르면 매집이 아니라 추격 위험으로 감점
        pr = r.get("price_return_60", 0) or 0
        if pr > 0.30: s -= 20
        return float(np.clip(s, 0, 100))
    df["accumulation_score"] = df.apply(row_score, axis=1)
    return df[["stock_code", "accumulation_score"]]
