"""sideways_score.py - 횡보장 점수화."""
from __future__ import annotations
import pandas as pd
import numpy as np


def _clip_score(x):
    return float(np.clip(x, 0, 100))


def score_sideways(features: pd.DataFrame) -> pd.DataFrame:
    df = features.copy()
    def row_score(r):
        # 이상적: 60일 폭 10~30%, 120일 폭 15~45%, MA 수렴도 낮음, 박스권 중하단, 지속성 높음
        rw60 = r.get("range_width_60", np.nan)
        rw120 = r.get("range_width_120", np.nan)
        ma = r.get("ma_convergence", np.nan)
        pos = r.get("box_position_120", np.nan)
        pers = r.get("box_persistence_60", np.nan)
        s = 0
        if pd.notna(rw60): s += max(0, 30 - abs(rw60 - 0.22) * 120)
        if pd.notna(rw120): s += max(0, 25 - abs(rw120 - 0.32) * 70)
        if pd.notna(ma): s += max(0, 25 - ma * 500)
        if pd.notna(pos): s += max(0, 10 - abs(pos - 0.45) * 20)
        if pd.notna(pers): s += pers * 10
        return _clip_score(s)
    df["sideways_score"] = df.apply(row_score, axis=1)
    return df[["stock_code", "sideways_score"]]
