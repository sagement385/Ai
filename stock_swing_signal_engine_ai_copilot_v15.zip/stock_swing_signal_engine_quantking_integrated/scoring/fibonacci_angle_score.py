"""fibonacci_angle_score.py - 피보나치/빗각 보조 점수화.

이 점수는 최종 점수의 6순위 보조 확인이다. 단독으로 종목을 끌어올리지 않도록 0~100점으로 계산하되 final_ranker에서 최대 5점 수준만 반영한다.
"""
from __future__ import annotations
import numpy as np
import pandas as pd


def score_fibonacci_angle(features: pd.DataFrame) -> pd.DataFrame:
    df = features.copy()
    if df.empty:
        return pd.DataFrame(columns=["stock_code", "fibonacci_angle_score"])
    fib = pd.to_numeric(df.get("fib_zone_score_raw", 0), errors="coerce").fillna(0)
    angle = pd.to_numeric(df.get("angle_score_raw", 0), errors="coerce").fillna(0)
    # 피보나치는 약하게, 빗각 지지/수렴은 조금 더 반영
    score = fib * 0.35 + angle * 0.65
    # 피보나치/빗각 둘 중 하나만 강할 때 과대평가 방지
    score = np.where((fib < 20) & (angle < 45), np.minimum(score, 45), score)
    df["fibonacci_angle_score"] = pd.Series(score).clip(0, 100).round(2)
    keep = ["stock_code", "fibonacci_angle_score"]
    for extra in ["fib_nearest_ratio", "fib_distance", "low_trend_slope_norm", "low_trend_distance", "channel_convergence"]:
        if extra in df.columns:
            keep.append(extra)
    return df[keep]
