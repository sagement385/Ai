"""
final_ranker.py

최종 우선순위:
1순위 횡보장
2순위 지지·저항
3순위 기관/외국인 수급
4순위 조용한 매집
5순위 변동성 수축
6순위 피보나치/빗각 보조 확인

점수는 단순 합산이 아니라 종속 관계를 반영한다.
- 횡보장 기반이 약하면 수급 점수만으로 높은 점수 불가
- 지지·저항이 약하면 기술적 점수 캡
- 기관/외국인 수급은 횡보·지지 구조가 받쳐줄 때 더 의미 있게 반영
- 피보나치/빗각은 6순위 보조 확인으로만 최대 소폭 가산
- 과열/극단 변동/재무 위험은 감점 또는 등급 제한
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def _merge_optional(df: pd.DataFrame, part: pd.DataFrame | None) -> pd.DataFrame:
    if part is not None and not part.empty and "stock_code" in part.columns:
        part = part.copy()
        part["stock_code"] = part["stock_code"].astype(str).str.zfill(6)
        return df.merge(part, on="stock_code", how="left")
    return df


def build_final_ranking(
    universe: pd.DataFrame,
    latest_price: pd.DataFrame,
    sideways_score: pd.DataFrame,
    support_score: pd.DataFrame,
    supply_score: pd.DataFrame,
    accumulation_score: pd.DataFrame,
    valuation_score: pd.DataFrame,
    risk_score: pd.DataFrame,
    fibonacci_angle_score: pd.DataFrame | None = None,
    extra_features: dict[str, pd.DataFrame] | None = None,
) -> pd.DataFrame:
    df = universe.copy()
    df["stock_code"] = df["stock_code"].astype(str).str.zfill(6)

    latest = latest_price.sort_values(["stock_code", "date"]).groupby("stock_code").tail(1)
    latest = latest[["stock_code", "date", "close", "volume", "trading_value"]]

    for part in [latest, sideways_score, support_score, supply_score, accumulation_score, valuation_score, risk_score, fibonacci_angle_score]:
        df = _merge_optional(df, part)

    default_cols = {
        "sideways_score": 50,
        "support_resistance_score": 50,
        "supply_score": 45,
        "accumulation_score": 50,
        "valuation_score": 50,
        "fibonacci_angle_score": 0,
        "risk_penalty": 0,
    }
    for col, default in default_cols.items():
        if col not in df.columns:
            df[col] = default
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(default)

    # 1~4순위는 주 점수, 5~6순위는 보조 점수로 제한한다.
    base = (
        df["sideways_score"] * 0.30 +
        df["support_resistance_score"] * 0.20 +
        df["supply_score"] * 0.20 +
        df["accumulation_score"] * 0.15 +
        df["valuation_score"] * 0.10
    )

    # 5순위: 변동성 수축. ATR/Bollinger 수축이 있을 때 최대 5점 보조.
    volatility_bonus = pd.Series(0.0, index=df.index)
    if extra_features:
        vc = extra_features.get("volatility_contraction")
        if vc is not None and not vc.empty:
            df = _merge_optional(df, vc)
            atr_ratio = pd.to_numeric(df.get("atr_ratio_20_60"), errors="coerce")
            bb_con = pd.to_numeric(df.get("bb_contraction"), errors="coerce")
            volatility_bonus += np.where(atr_ratio < 0.90, 3.0, 0.0)
            volatility_bonus += np.where(bb_con < 0.85, 2.0, 0.0)
            volatility_bonus += np.where((atr_ratio < 0.80) & (bb_con < 0.75), 1.0, 0.0)
            volatility_bonus = volatility_bonus.clip(0, 5)

    # 6순위: 피보나치/빗각. 단독으로 끌어올리지 못하게 최대 4점만 반영.
    fib_angle_bonus = (df["fibonacci_angle_score"] / 100.0 * 4.0).clip(0, 4)
    # 횡보/지지 구조가 약하면 피보나치/빗각 보조 점수 제거.
    fib_angle_bonus = np.where(
        (df["sideways_score"] >= 55) & (df["support_resistance_score"] >= 45),
        fib_angle_bonus,
        0.0,
    )

    raw = base + volatility_bonus + fib_angle_bonus - df["risk_penalty"]

    # 종속 캡: 장기 스윙 엔진은 횡보장과 지지·저항이 가장 중요하다.
    cap = pd.Series(100.0, index=df.index)
    cap = np.where(df["sideways_score"] < 45, 68, cap)
    cap = np.where(df["support_resistance_score"] < 35, np.minimum(cap, 75), cap)
    cap = np.where((df["supply_score"] < 40) & (df["accumulation_score"] < 45), np.minimum(cap, 82), cap)
    cap = np.where(df["risk_penalty"] >= 40, np.minimum(cap, 60), cap)

    # 핵심 시너지: 1~4순위가 동시에 맞고 5순위 변동성 수축까지 있으면 가산.
    core_synergy = (
        (df["sideways_score"] >= 70) &
        (df["support_resistance_score"] >= 60) &
        (df["supply_score"] >= 60) &
        (df["accumulation_score"] >= 65) &
        (df["risk_penalty"] < 25)
    )
    volatility_synergy = core_synergy & (pd.Series(volatility_bonus, index=df.index) >= 3)

    final = np.minimum(raw + np.where(core_synergy, 6, 0) + np.where(volatility_synergy, 2, 0), cap)
    df["volatility_bonus"] = pd.Series(volatility_bonus, index=df.index).round(2)
    df["fibonacci_angle_bonus"] = pd.Series(fib_angle_bonus, index=df.index).round(2)
    df["final_score"] = pd.Series(final).clip(0, 100).round(2)
    df["grade"] = pd.cut(df["final_score"], bins=[-1, 55, 70, 85, 101], labels=["D 제외", "C 관망", "B 관심", "A 핵심관찰"])

    reasons: list[str] = []
    priority_summary: list[str] = []
    for _, r in df.iterrows():
        rs = []
        pri = []
        if r["sideways_score"] >= 70:
            rs.append("1순위 횡보장 양호")
            pri.append("횡보")
        if r["support_resistance_score"] >= 60:
            rs.append("2순위 지지·저항 신뢰")
            pri.append("지지")
        if r["supply_score"] >= 60:
            rs.append("3순위 기관/외국인 수급")
            pri.append("수급")
        if r["accumulation_score"] >= 65:
            rs.append("4순위 조용한 매집")
            pri.append("매집")
        if r.get("volatility_bonus", 0) >= 3:
            rs.append("5순위 변동성 수축")
            pri.append("수축")
        if r.get("fibonacci_angle_bonus", 0) >= 2:
            rs.append("6순위 피보나치/빗각 보조")
            pri.append("피보/빗각")
        if r["valuation_score"] >= 60:
            rs.append("재무/밸류 보조")
        if r["risk_penalty"] >= 25:
            rs.append("위험감점 존재")
        reasons.append(", ".join(rs) if rs else "뚜렷한 우위 없음")
        priority_summary.append(" → ".join(pri) if pri else "조건 부족")
    df["reason"] = reasons
    df["priority_summary"] = priority_summary

    cols = [
        "stock_code", "stock_name", "market", "date", "close", "final_score", "grade",
        "sideways_score", "support_resistance_score", "supply_score", "accumulation_score",
        "volatility_bonus", "fibonacci_angle_score", "fibonacci_angle_bonus", "valuation_score", "risk_penalty",
        "priority_summary", "reason",
    ]
    for c in cols:
        if c not in df.columns:
            df[c] = ""
    return df[cols].sort_values("final_score", ascending=False).reset_index(drop=True)
