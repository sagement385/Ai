"""risk_score.py - 극단 변동/과열/유동성/재무 위험 감점."""
from __future__ import annotations
import pandas as pd
import numpy as np


def score_risk(return_features: pd.DataFrame, *flag_frames: pd.DataFrame) -> pd.DataFrame:
    df = return_features[["stock_code", "ret_20", "ret_60", "kurt_60", "extreme_days_60", "vol_cluster_ratio"]].copy()
    def base_penalty(r):
        p = 0
        if (r.get("ret_20", 0) or 0) > 0.35: p += 15
        if (r.get("ret_60", 0) or 0) > 0.70: p += 20
        if (r.get("extreme_days_60", 0) or 0) >= 8: p += 10
        if pd.notna(r.get("vol_cluster_ratio", np.nan)) and r["vol_cluster_ratio"] > 1.6: p += 10
        if pd.notna(r.get("kurt_60", np.nan)) and r["kurt_60"] > 8: p += 5
        return p
    df["risk_penalty"] = df.apply(base_penalty, axis=1)
    for frame in flag_frames:
        if frame is not None and not frame.empty:
            penalty_cols = [c for c in frame.columns if c.endswith("_penalty")]
            use = frame[["stock_code"] + penalty_cols].copy()
            df = df.merge(use, on="stock_code", how="left")
            for c in penalty_cols:
                df["risk_penalty"] += pd.to_numeric(df[c], errors="coerce").fillna(0)
                df = df.drop(columns=[c])
    df["risk_penalty"] = df["risk_penalty"].clip(0, 100)
    return df[["stock_code", "risk_penalty"]]
