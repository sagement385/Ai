"""support_resistance_score.py - 지지·저항 점수화."""
from __future__ import annotations
import pandas as pd
import numpy as np


def score_support_resistance(features: pd.DataFrame) -> pd.DataFrame:
    df = features.copy()
    def row_score(r):
        dist = r.get("support_distance", np.nan)
        strength = r.get("support_strength", 0) or 0
        fail = r.get("breakdown_failure_count", 0) or 0
        resist = r.get("resistance_distance", np.nan)
        s = min(strength, 45)
        # 지지선과 너무 멀면 가점 감소. 0~12% 위가 좋음.
        if pd.notna(dist):
            if 0 <= dist <= 0.12: s += 30 * (1 - dist / 0.12)
            elif dist < 0: s -= 15
        s += min(fail, 5) * 4
        # 위 저항까지 여유가 있으면 조금 가점
        if pd.notna(resist) and resist > 0.08: s += 10
        return float(np.clip(s, 0, 100))
    df["support_resistance_score"] = df.apply(row_score, axis=1)
    return df[["stock_code", "support_resistance_score"]]
