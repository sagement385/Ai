"""valuation_score.py - 재무/밸류 보조 점수."""
from __future__ import annotations
import pandas as pd
import numpy as np


def score_valuation(features: pd.DataFrame) -> pd.DataFrame:
    if features is None or features.empty:
        return pd.DataFrame(columns=["stock_code", "valuation_score"])
    df = features.copy()
    def row_score(r):
        if not bool(r.get("valuation_data_available", False)):
            return 50.0
        s = 50
        pbr = r.get("pbr", np.nan)
        per = r.get("per", np.nan)
        roe = r.get("roe", np.nan)
        debt = r.get("debt_ratio", np.nan)
        op = r.get("operating_profit", np.nan)
        ni = r.get("net_income", np.nan)
        if pd.notna(pbr) and pbr > 0: s += np.clip((1.8 - pbr) * 12, -15, 20)
        if pd.notna(per) and per > 0: s += np.clip((25 - per) * 0.6, -10, 12)
        if pd.notna(roe): s += np.clip(roe * 0.4, -10, 12)
        if pd.notna(debt) and debt > 250: s -= 15
        if pd.notna(op) and op < 0: s -= 15
        if pd.notna(ni) and ni < 0: s -= 10
        return float(np.clip(s, 0, 100))
    df["valuation_score"] = df.apply(row_score, axis=1)
    return df[["stock_code", "valuation_score"]]
