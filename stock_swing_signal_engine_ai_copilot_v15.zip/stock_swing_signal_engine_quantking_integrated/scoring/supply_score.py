"""supply_score.py - 기관/외국인 수급 점수화."""
from __future__ import annotations
import pandas as pd
import numpy as np


def score_supply(features: pd.DataFrame) -> pd.DataFrame:
    df = features.copy()
    if df.empty:
        return pd.DataFrame(columns=["stock_code", "supply_score"])
    def row_score(r):
        if not bool(r.get("supply_data_available", False)):
            return 45.0  # 수급 데이터 없으면 중립-낮은 점수
        inst20 = r.get("inst_buy_ratio_20", 0) or 0
        inst60 = r.get("inst_buy_ratio_60", 0) or 0
        foreign20 = r.get("foreign_buy_ratio_20", 0) or 0
        foreign60 = r.get("foreign_buy_ratio_60", 0) or 0
        ip = r.get("inst_persistence_20", 0) or 0
        fp = r.get("foreign_persistence_20", 0) or 0
        s = 45
        s += np.clip(inst20 * 800, -20, 20)
        s += np.clip(inst60 * 500, -15, 15)
        s += np.clip(foreign20 * 600, -15, 15)
        s += np.clip(foreign60 * 400, -10, 10)
        s += (ip - 0.5) * 20
        s += (fp - 0.5) * 15
        return float(np.clip(s, 0, 100))
    df["supply_score"] = df.apply(row_score, axis=1)
    return df[["stock_code", "supply_score"]]
