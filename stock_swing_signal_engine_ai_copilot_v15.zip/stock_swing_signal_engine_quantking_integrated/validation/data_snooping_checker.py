"""
data_snooping_checker.py

Sullivan, Timmermann & White / White's Reality Check 아이디어의 간단 버전.
여러 feature를 만들다 우연히 잘 맞는 조합만 선택하는 문제를 방지하기 위한 permutation test.
"""
from __future__ import annotations
import numpy as np
import pandas as pd


def permutation_feature_check(df: pd.DataFrame, feature: str, target: str = "future_return", n_iter: int = 500, seed: int = 42) -> dict:
    clean = df[[feature, target]].dropna()
    if len(clean) < 20:
        return {"feature": feature, "n": len(clean), "observed_ic": np.nan, "p_value": np.nan}
    rng = np.random.default_rng(seed)
    observed = clean[feature].corr(clean[target], method="spearman")
    sims = []
    vals = clean[target].to_numpy().copy()
    for _ in range(n_iter):
        rng.shuffle(vals)
        sims.append(pd.Series(clean[feature].to_numpy()).corr(pd.Series(vals), method="spearman"))
    p = float((np.abs(sims) >= abs(observed)).mean())
    return {"feature": feature, "n": len(clean), "observed_ic": float(observed), "p_value": p}
