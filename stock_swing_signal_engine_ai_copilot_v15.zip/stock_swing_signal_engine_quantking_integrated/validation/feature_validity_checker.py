"""
feature_validity_checker.py

각 feature가 미래 수익률과 어느 정도 관련이 있는지 단순 검증한다.
개인 프로젝트에서는 RL보다 이 검증이 더 중요하다.
"""
from __future__ import annotations
import pandas as pd
import numpy as np


def future_return_table(prices: pd.DataFrame, scores: pd.DataFrame, horizon: int = 60) -> pd.DataFrame:
    p = prices.sort_values(["stock_code", "date"]).copy()
    p["future_close"] = p.groupby("stock_code")["close"].shift(-horizon)
    p["future_return"] = p["future_close"] / p["close"] - 1
    if "date" in scores.columns:
        scores = scores.copy(); scores["date"] = pd.to_datetime(scores["date"])
        merged = scores.merge(p[["stock_code", "date", "future_return"]], on=["stock_code", "date"], how="left")
    else:
        latest_dates = p.groupby("stock_code").tail(1)[["stock_code", "date"]]
        merged = scores.merge(latest_dates, on="stock_code", how="left").merge(p[["stock_code", "date", "future_return"]], on=["stock_code", "date"], how="left")
    return merged


def feature_ic(scores_with_future: pd.DataFrame, feature_cols: list[str], target_col: str = "future_return") -> pd.DataFrame:
    rows = []
    df = scores_with_future.dropna(subset=[target_col])
    for col in feature_cols:
        if col in df.columns and df[col].notna().sum() >= 10:
            rows.append({"feature": col, "spearman_ic": df[col].corr(df[target_col], method="spearman"), "pearson_ic": df[col].corr(df[target_col], method="pearson"), "n": int(df[col].notna().sum())})
    return pd.DataFrame(rows).sort_values("spearman_ic", ascending=False)
