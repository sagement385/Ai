"""daily_signal_report.py - CSV/Markdown/HTML 리포트 생성.

외부 차트 API를 쓰지 않고 prices_daily.csv 기준으로 상위 후보의 최근 가격/거래량 차트를 SVG로 그린다.
"""
from __future__ import annotations

from pathlib import Path
import html
import json
import pandas as pd
import numpy as np


def _fmt(v, digits: int = 2) -> str:
    try:
        if pd.isna(v):
            return ""
        if isinstance(v, (float, np.floating)):
            return f"{float(v):.{digits}f}"
        return str(v)
    except Exception:
        return str(v)


def _mini_chart_svg(price_rows: pd.DataFrame, width: int = 520, height: int = 210) -> str:
    """최근 120개 봉 기준 간단한 종가선 + 거래량 막대 SVG."""
    if price_rows is None or price_rows.empty:
        return "<div class='chart-empty'>차트 데이터 없음</div>"
    df = price_rows.sort_values("date").tail(120).copy()
    if df.empty or "close" not in df:
        return "<div class='chart-empty'>차트 데이터 없음</div>"
    close = pd.to_numeric(df["close"], errors="coerce").to_numpy(dtype=float)
    vol = pd.to_numeric(df.get("volume", pd.Series([0] * len(df))), errors="coerce").fillna(0).to_numpy(dtype=float)
    valid = np.isfinite(close)
    if valid.sum() < 2:
        return "<div class='chart-empty'>차트 데이터 부족</div>"
    close = close[valid]
    vol = vol[valid]
    n = len(close)
    left, right, top, bottom = 34, 12, 14, 56
    chart_w = width - left - right
    chart_h = height - top - bottom
    ymin, ymax = float(np.nanmin(close)), float(np.nanmax(close))
    if ymax <= ymin:
        ymax = ymin + 1
    xs = np.linspace(left, left + chart_w, n)
    ys = top + (ymax - close) / (ymax - ymin) * chart_h
    points = " ".join(f"{x:.1f},{y:.1f}" for x, y in zip(xs, ys))
    v_max = float(np.nanmax(vol)) if len(vol) else 0
    bars = []
    if v_max > 0:
        bar_w = max(1.0, chart_w / max(n, 1) * 0.55)
        base_y = height - 18
        max_bar_h = 34
        step = chart_w / max(n - 1, 1)
        # 너무 많은 bar는 간격상 자연스럽게 얇게 표시
        for i, v in enumerate(vol):
            bh = max(1.0, (float(v) / v_max) * max_bar_h) if v_max else 0
            x = left + i * step - bar_w / 2
            y = base_y - bh
            bars.append(f"<rect x='{x:.1f}' y='{y:.1f}' width='{bar_w:.1f}' height='{bh:.1f}' class='volbar'/>")
    last = close[-1]
    start = close[0]
    ret = (last / start - 1) * 100 if start else 0
    label = f"{last:,.0f} / {ret:+.1f}%"
    return f"""
<svg class='spark-chart' viewBox='0 0 {width} {height}' role='img' aria-label='최근 가격 차트'>
  <rect x='0' y='0' width='{width}' height='{height}' rx='14' class='chart-bg'/>
  <line x1='{left}' y1='{top}' x2='{left}' y2='{top + chart_h}' class='grid-axis'/>
  <line x1='{left}' y1='{top + chart_h}' x2='{left + chart_w}' y2='{top + chart_h}' class='grid-axis'/>
  <line x1='{left}' y1='{top + chart_h * 0.33}' x2='{left + chart_w}' y2='{top + chart_h * 0.33}' class='grid-line'/>
  <line x1='{left}' y1='{top + chart_h * 0.66}' x2='{left + chart_w}' y2='{top + chart_h * 0.66}' class='grid-line'/>
  {''.join(bars)}
  <polyline fill='none' class='price-line' points='{points}'/>
  <circle cx='{xs[-1]:.1f}' cy='{ys[-1]:.1f}' r='3.8' class='last-dot'/>
  <text x='{left}' y='{height - 6}' class='chart-label'>거래량</text>
  <text x='{left + chart_w - 92}' y='26' class='chart-value'>{html.escape(label)}</text>
  <text x='8' y='28' class='axis-label'>{ymax:,.0f}</text>
  <text x='8' y='{top + chart_h:.0f}' class='axis-label'>{ymin:,.0f}</text>
</svg>"""


def _chart_map(prices: pd.DataFrame | None, top_codes: list[str]) -> dict[str, str]:
    if prices is None or prices.empty:
        return {code: "<div class='chart-empty'>차트 데이터 없음</div>" for code in top_codes}
    prices = prices.copy()
    prices["stock_code"] = prices["stock_code"].astype(str).str.zfill(6)
    result = {}
    for code in top_codes:
        result[code] = _mini_chart_svg(prices[prices["stock_code"] == code])
    return result


def save_reports(ranking: pd.DataFrame, output_dir: str | Path = "reports/output", top_n: int = 30, prices: pd.DataFrame | None = None) -> dict:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    top = ranking.head(top_n).copy()
    csv_path = out / "daily_signal_report.csv"
    md_path = out / "daily_signal_report.md"
    html_path = out / "daily_signal_report.html"
    json_path = out / "daily_signal_report.json"
    top.to_csv(csv_path, index=False, encoding="utf-8-sig")
    top_codes = top["stock_code"].astype(str).str.zfill(6).tolist() if "stock_code" in top else []
    charts = _chart_map(prices, top_codes)

    lines = [
        "# 장기 스윙 관찰 후보 리포트",
        "",
        "투자 판단이 아니라, 횡보·지지·수급·매집 조건을 만족하는 관찰 후보입니다.",
        "",
        "우선순위: 1) 횡보장 → 2) 지지·저항 → 3) 기관/외국인 수급 → 4) 조용한 매집 → 5) 변동성 수축 → 6) 피보나치/빗각 보조",
        "",
    ]
    for _, r in top.iterrows():
        lines.append(f"## {r.get('stock_name','')} ({r.get('stock_code','')}) - {r.get('grade','')}")
        lines.append(f"- 최종점수: {r.get('final_score','')}")
        lines.append(f"- 종가: {r.get('close','')}")
        lines.append(
            f"- 횡보/지지/수급/매집/변동성/피보·빗각/밸류/위험: "
            f"{r.get('sideways_score','')}/{r.get('support_resistance_score','')}/{r.get('supply_score','')}/{r.get('accumulation_score','')}/"
            f"{r.get('volatility_bonus','')}/{r.get('fibonacci_angle_score','')}/{r.get('valuation_score','')}/{r.get('risk_penalty','')}"
        )
        lines.append(f"- 우선순위 충족: {r.get('priority_summary','')}")
        lines.append(f"- 근거: {r.get('reason','')}")
        lines.append("")
    md_path.write_text("\n".join(lines), encoding="utf-8")

    json_path.write_text(top.to_json(orient="records", force_ascii=False, indent=2), encoding="utf-8")

    cards = []
    for rank, (_, r) in enumerate(top.iterrows(), start=1):
        code = str(r.get("stock_code", "")).zfill(6)
        grade = html.escape(str(r.get("grade", "")))
        grade_cls = "grade-a" if "A" in grade else "grade-b" if "B" in grade else "grade-c" if "C" in grade else "grade-d"
        cards.append(f"""
<section class='stock-card'>
  <div class='card-head'>
    <div>
      <div class='rank'>#{rank}</div>
      <h2>{html.escape(str(r.get('stock_name','')))} <span>{html.escape(code)}</span></h2>
      <p class='muted'>{html.escape(str(r.get('priority_summary','')))}</p>
    </div>
    <div class='score-box {grade_cls}'>
      <div class='score'>{html.escape(str(r.get('final_score','')))}</div>
      <div>{grade}</div>
    </div>
  </div>
  <div class='chart-wrap'>{charts.get(code, "")}</div>
  <div class='metric-grid'>
    <div><b>횡보장</b><span>{_fmt(r.get('sideways_score',''))}</span></div>
    <div><b>지지·저항</b><span>{_fmt(r.get('support_resistance_score',''))}</span></div>
    <div><b>수급</b><span>{_fmt(r.get('supply_score',''))}</span></div>
    <div><b>조용한 매집</b><span>{_fmt(r.get('accumulation_score',''))}</span></div>
    <div><b>변동성 수축</b><span>{_fmt(r.get('volatility_bonus',''))}</span></div>
    <div><b>피보/빗각</b><span>{_fmt(r.get('fibonacci_angle_score',''))}</span></div>
    <div><b>밸류</b><span>{_fmt(r.get('valuation_score',''))}</span></div>
    <div><b>위험감점</b><span>{_fmt(r.get('risk_penalty',''))}</span></div>
  </div>
  <p class='reason'>{html.escape(str(r.get('reason','')))}</p>
</section>""")

    html_text = f"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>장기 스윙 후보</title>
<style>
:root {{ --bg:#f6f7fb; --card:#fff; --text:#162033; --muted:#687386; --line:#e4e7ef; --accent:#2563eb; }}
* {{ box-sizing:border-box; }}
body {{ margin:0; background:var(--bg); color:var(--text); font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif; }}
.container {{ max-width:1180px; margin:0 auto; padding:28px 18px 60px; }}
.hero {{ background:linear-gradient(135deg,#111827,#1d4ed8); color:#fff; border-radius:24px; padding:28px; box-shadow:0 18px 40px rgba(15,23,42,.18); }}
.hero h1 {{ margin:0 0 10px; font-size:30px; }}
.hero p {{ margin:6px 0; color:#dbeafe; line-height:1.55; }}
.priority {{ margin-top:16px; display:grid; grid-template-columns:repeat(6,minmax(0,1fr)); gap:8px; }}
.priority div {{ background:rgba(255,255,255,.12); border:1px solid rgba(255,255,255,.22); border-radius:12px; padding:10px; font-size:13px; }}
.toolbar {{ display:flex; justify-content:space-between; align-items:center; margin:22px 0 12px; gap:12px; flex-wrap:wrap; }}
.toolbar a {{ color:var(--accent); text-decoration:none; font-weight:700; }}
.stock-card {{ background:var(--card); border:1px solid var(--line); border-radius:22px; padding:18px; margin:16px 0; box-shadow:0 10px 28px rgba(15,23,42,.07); }}
.card-head {{ display:flex; justify-content:space-between; gap:18px; align-items:flex-start; }}
.rank {{ color:var(--accent); font-weight:800; font-size:14px; }}
h2 {{ margin:3px 0 4px; font-size:23px; }}
h2 span {{ color:var(--muted); font-size:15px; font-weight:600; }}
.muted {{ color:var(--muted); margin:0; }}
.score-box {{ min-width:112px; text-align:center; border-radius:16px; padding:12px; color:#fff; font-weight:800; }}
.score {{ font-size:28px; line-height:1; margin-bottom:4px; }}
.grade-a {{ background:#15803d; }} .grade-b {{ background:#2563eb; }} .grade-c {{ background:#ca8a04; }} .grade-d {{ background:#64748b; }}
.chart-wrap {{ margin:16px 0; overflow-x:auto; }}
.spark-chart {{ width:100%; max-width:720px; height:auto; display:block; }}
.chart-bg {{ fill:#f8fafc; stroke:#e5e7eb; }} .grid-axis {{ stroke:#cbd5e1; stroke-width:1; }} .grid-line {{ stroke:#e5e7eb; stroke-dasharray:4 4; }}
.price-line {{ stroke:#1d4ed8; stroke-width:2.6; }} .last-dot {{ fill:#1d4ed8; }} .volbar {{ fill:#cbd5e1; opacity:.85; }}
.axis-label,.chart-label {{ fill:#64748b; font-size:11px; }} .chart-value {{ fill:#0f172a; font-size:13px; font-weight:800; }}
.chart-empty {{ color:#64748b; padding:30px; border:1px dashed #cbd5e1; border-radius:14px; }}
.metric-grid {{ display:grid; grid-template-columns:repeat(8,minmax(0,1fr)); gap:9px; }}
.metric-grid div {{ background:#f8fafc; border:1px solid #e5e7eb; border-radius:12px; padding:10px; }}
.metric-grid b {{ display:block; color:#475569; font-size:12px; margin-bottom:5px; }}
.metric-grid span {{ font-size:18px; font-weight:800; }}
.reason {{ margin:14px 0 0; color:#334155; line-height:1.55; }}
.table-link {{ background:#fff; border:1px solid var(--line); border-radius:14px; padding:12px 14px; }}
.note {{ color:#64748b; font-size:13px; line-height:1.5; }}
@media (max-width:840px) {{ .priority {{ grid-template-columns:repeat(2,1fr); }} .metric-grid {{ grid-template-columns:repeat(2,1fr); }} .card-head {{ flex-direction:column; }} .score-box {{ width:100%; }} }}
</style></head>
<body><main class="container">
  <section class="hero">
    <h1>장기 스윙 관찰 후보</h1>
    <p>매수 추천이 아니라 CSV 데이터 기반 수학적 시그널 후보입니다. 과열주보다 횡보·지지·수급·매집 구조를 우선합니다.</p>
    <div class="priority">
      <div>1순위<br><b>횡보장</b></div><div>2순위<br><b>지지·저항</b></div><div>3순위<br><b>기관/외국인 수급</b></div>
      <div>4순위<br><b>조용한 매집</b></div><div>5순위<br><b>변동성 수축</b></div><div>6순위<br><b>피보나치/빗각 보조</b></div>
    </div>
  </section>
  <div class="toolbar"><div class="table-link"><a href="daily_signal_report.csv">CSV 다운로드</a> · <a href="daily_signal_report.json">JSON</a></div><div class="note">차트는 외부 API 없이 prices_daily.csv의 최근 최대 120개 봉으로 생성됩니다.</div></div>
  {''.join(cards)}
</main></body></html>"""
    html_path.write_text(html_text, encoding="utf-8")
    return {"csv": str(csv_path), "markdown": str(md_path), "html": str(html_path), "json": str(json_path)}
