"""ai_summary.py

API 없는 로컬 요약. Gemini/OpenAI 없이도 점수표를 사람이 읽기 쉽게 설명한다.
"""
from __future__ import annotations
import pandas as pd


def build_offline_summary(ranking: pd.DataFrame, top_n: int = 10) -> str:
    top = ranking.head(top_n)
    lines = [
        "오늘의 핵심 관찰 포인트",
        "- 우선순위: 1) 횡보장 → 2) 지지·저항 → 3) 기관/외국인 수급 → 4) 조용한 매집 → 5) 변동성 수축 → 6) 피보나치/빗각 보조",
    ]
    a_count = int((top["grade"].astype(str).str.contains("A")).sum()) if "grade" in top.columns else 0
    b_count = int((top["grade"].astype(str).str.contains("B")).sum()) if "grade" in top.columns else 0
    lines.append(f"- 상위 {min(top_n, len(top))}개 중 A급 후보: {a_count}개, B급 후보: {b_count}개")
    for _, r in top.iterrows():
        lines.append(
            f"- {r.get('stock_name','')}({r.get('stock_code','')}): "
            f"{r.get('grade','')} / {r.get('final_score','')}점 / "
            f"{r.get('priority_summary','')} / {r.get('reason','')}"
        )
    return "\n".join(lines)
