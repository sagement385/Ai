# 4개 독립 알고리즘 구현 메모

이 버전은 RL을 사용하지 않고, 공개적으로 알려진 트레이더 방법론의 핵심 아이디어를 규칙 기반으로 구현한다. 원저자의 모든 재량 판단이나 비공개 세부 규칙을 복제하는 것이 아니라, 5년치 OHLCV CSV에서 계산 가능한 조건으로 유사하게 구현했다.

## 전략 구성

기본 비중은 `configs/multi_strategy_config.json`에서 조정한다.

- `vcp`: 20% — Minervini VCP 변동성 수축
- `canslim`: 30% — O'Neil CAN SLIM 성장주 돌파 프록시
- `stage2`: 40% — Weinstein Stage 2 상승단계
- `darvas`: 10% — Darvas Box 박스 돌파

## 공통 원칙

1. 네 전략은 하나의 점수로 섞지 않는다.
2. 각 전략이 독립적으로 후보를 생성한다.
3. 전략별 예산 안에서 상위 후보를 편입한다.
4. 같은 종목이 여러 전략에서 중복되면 종목 단위로 합치되, `max_single_stock_weight`로 비중 상한을 둔다.
5. 현재 구현은 후보 스캔과 포트폴리오 구성까지다. 실거래 전에는 반드시 백테스트/워크포워드 검증이 필요하다.

## 출력 파일

`python main.py analyze` 실행 시 아래 파일이 생성된다.

- `reports/output/multi_strategy_signals_all.csv`
- `reports/output/multi_strategy_portfolio.csv`
- `reports/output/multi_strategy_portfolio.html`
- `reports/output/multi_strategy_portfolio.json`

## 전략별 구현 요약

### VCP

- 장기 이평선 위 여부
- `MA50 > MA150 > MA200` 구조
- 52주 고점 근처
- 최근 수익률과 시장 대비 상대강도
- 120일/60일/20일 range 축소
- ATR20/ATR60 감소
- 거래량 20일/60일 감소
- 피벗 근접 또는 거래량 동반 돌파

### CANSLIM 프록시

현재 CSV에 분기 EPS/매출 성장 데이터가 없을 수 있으므로 가격 기반 CANSLIM 프록시로 구현했다.

- 60일/120일 상대강도
- 52주 고점 근처 베이스
- 50/150/200일선 추세
- 거래량 확장
- 재무 CSV가 있으면 ROE, 영업이익, 순이익 양수 여부를 보조 반영

### Weinstein Stage 2

- 종가가 150/200일선 위
- 50일선이 150일선 위
- 200일선 기울기 개선
- 120일 저항 돌파 근처
- 상대강도 유지
- 거래량 확장

### Darvas Box

- 최근 20일 박스 고점/저점
- 박스폭이 과도하지 않은지
- 현재가가 박스 상단 근처인지
- 시장 대비 상대강도
- 추세 필터
- 박스 상단 돌파 시 진입 후보, 박스 하단 부근 손절
