# AI Copilot v15

이 버전은 특정 GPT에 고정되지 않는 승인형 AI Copilot을 추가합니다.

## 지원 Provider

- `offline`: API 키 없이 로컬 규칙 기반 테스트
- `openai`: OpenAI Chat Completions 호환
- `openai_compatible`: OpenAI 호환 엔드포인트를 직접 지정
- `openrouter`, `groq`, `deepseek`: OpenAI 호환 형식으로 호출
- `ollama`: 로컬 Ollama `/api/chat` 호출

## 웹 사용법

```powershell
python main.py serve
```

브라우저에서:

```text
http://127.0.0.1:8765/ai-copilot
```

## 기능

1. 종목 분석 AI
2. 백테스트 진단 AI
3. 전략 개선 AI
4. 코드 패치 제안 AI
5. 패치 미리보기
6. 승인 후 자동 백업 및 적용

## 안전장치

- `.env`, `data`, `reports/output`, `backups`, `.venv` 경로는 패치 차단
- 패치는 `replace`, `append`, `write` 형식의 구조화 JSON만 적용
- 적용 전 기존 파일은 `backups/ai_patches/YYYYMMDD_HHMMSS`에 백업
- `main.py` 전체 덮어쓰기(write)는 차단하고, 정확한 find/replace만 허용
- 테스트 구간 반복 튜닝으로 과최적화하지 말라는 지침을 시스템 프롬프트에 포함

## 추천 흐름

1. AI Copilot에서 종목 분석/백테스트 진단 실행
2. 개선 AI로 원형 훼손 없는 개선안 생성
3. 패치 제안 AI 체크
4. 패치 미리보기 확인
5. 승인 후 적용
6. `python main.py backtest`로 검증
