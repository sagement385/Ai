# Capital Injection 10x v10

## 목적

기존 4개 알고리즘과 Deep Turnaround 신호를 크게 바꾸지 않고, 백테스트/포트폴리오 단계에 `추가 자금 투입형` 고위험 프로필을 추가했다.

이 프로필은 손절을 주된 리스크 관리로 쓰기보다, 다음 조건에서 외부 자금을 추가 투입해 평균단가를 낮추는 방식이다.

- 기존 알고리즘이 고른 종목일 것
- 현재 가격이 평균단가 대비 단계적 손실 구간에 들어왔을 것
- falling knife, no-base, extreme distress 조건이 아닐 것
- 가격 기반 건강도 점수가 기준 이상일 것
- 총 외부 추가투입금 한도를 넘지 않을 것

## 중요한 주의

추가투입 전략은 단순 수익률이 부풀려질 수 있다. 예를 들어 초기 1,000만원으로 시작한 뒤 500만원을 추가로 넣고 최종 2,000만원이 되었다면, 초기자금 기준 수익률은 +100%지만 총투입원금 기준 수익률은 +33.3%다.

따라서 v10은 아래 지표를 추가로 저장한다.

- external_contributions
- total_contributed_cash
- net_profit_after_contributions
- return_on_total_contributed_pct
- backtest_capital_injections.csv

## 프로필 실행

```powershell
python main.py backtest --config configs/backtest_config_capital_injection_10x.json --strategies vcp,canslim,deep_turnaround
```

웹에서는 백테스트 프로필에서 `고위험 추가투입 10x`를 선택한다.

## 추가투입 조건

기본 트리거:

- 평균단가 대비 -18%
- 평균단가 대비 -32%
- 평균단가 대비 -48%

기본 추가투입 크기:

- 최초 진입금액의 50%
- 최초 진입금액의 75%
- 최초 진입금액의 100%

안전장치:

- 최근 20일 수익률 -12% 이하이면 falling knife로 판단
- 50일선 아래 + 50일선 하락 + 60일 수익률 음수이면 추가투입 거부
- 120일 저점 부근에서 다시 무너지면 no-base로 판단
- 52주 고점 대비 -92% 이상 폭락이면 구조적 부실 위험으로 판단
- 종목 하나의 평가금액이 총투입원금의 28%를 넘지 않게 제한
- 외부 추가투입 총액은 초기자금의 2배까지 제한
- 치명적 붕괴 방지용 catastrophic exit는 유지

## 연구 기반

- De Bondt & Thaler 장기 loser reversal: 낙폭과대주 반전 가능성
- Piotroski F-Score: 가치함정 제거와 재무 건전성 확인
- Distress anomaly: 부실주를 무작정 사는 것은 위험
- Martingale/averaging-down 위험: 추가투입은 승률을 높이는 것이 아니라 손실 인식을 지연할 수 있음
- Risk-constrained Kelly: 성장률과 드로다운 제약을 함께 고려

## 테스트 메모

개발 검증은 업로드된 5년치 prices_daily.csv에서 거래대금 상위 100개 종목으로 수행했다.

- 총수익률: 약 +104.66%
- 총투입원금 기준 수익률: 약 +78.51%
- 추가투입금: 약 146.5만원
- MDD: 약 -8.05%
- 거래 수: 27회
- 추가투입 기록: 13건

이 결과는 기능 검증용이며, 전체 300개/전체 종목 결과는 사용자의 PC에서 실행해야 한다.
