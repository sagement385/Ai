# Algorithm audit + benchmark comparison v7

## 목적

v6까지는 4개 스윙 전략의 결과와 백테스트 결과를 보여줬지만, 전략이 최근 강세장 덕을 본 것인지 판단하기 어려웠다. v7에서는 다음을 추가했다.

1. 4개 알고리즘 구현 상태 감사 파일 생성
2. 백테스트 유니버스 동일가중 벤치마크 비교
3. KOSPI/KOSDAQ 동일가중 proxy 비교
4. 전략 수익률, CAGR, MDD, Sharpe의 초과 성과 계산

## 알고리즘 감사 기준

감사 결과는 `reports/output/algorithm_audit.csv`에 저장된다.

- VCP: OHLCV 기반 핵심 구조 구현. 추세, 고점 근접, 변동성/거래량 수축, 피벗 돌파를 반영한다.
- CANSLIM: 가격/거래량 리더십은 구현되어 있으나, 정확한 CANSLIM식 분기 EPS/매출 성장률은 `financial_quarterly.csv`가 있어야 포인트인타임으로 반영 가능하다. 최신 `financials.csv`를 과거 백테스트에 그대로 쓰면 미래정보 누수 위험이 있으므로 백테스트에서는 가격/거래량 프록시를 사용한다.
- Stage2: 주봉 30주선, 30주선 기울기, 120일 저항 돌파, 150/200일선 추세를 반영한다.
- Darvas: 20일 박스 상단 돌파, 박스 하단 손절, 박스폭 기반 목표가를 반영한다.

## 벤치마크 산출물

백테스트 실행 후 다음 파일이 생성된다.

- `backtest_benchmark_equity.csv`
- `backtest_benchmark_summary.csv`
- `backtest_excess_summary.csv`
- `algorithm_audit.csv`

## 벤치마크 종류

현재 가격 CSV에 공식 KOSPI/KOSDAQ 지수 데이터가 없으므로, 다음 proxy를 쓴다.

- 동일가중 매수보유 · 백테스트 유니버스
- KOSPI 동일가중 proxy · CSV `market` 컬럼 기준
- KOSDAQ 동일가중 proxy · CSV `market` 컬럼 기준
- 동일가중 일별 리밸런싱 proxy

공식 지수와 완전히 같지는 않다. 다만 현재 전략이 같은 유니버스의 단순 보유 대비 잘했는지 판단하는 데 유용하다.

## 테스트 결과 요약

업로드된 5년치 `prices_daily.csv` 기준, 기본 설정인 거래대금 상위 500개/최근 3년 평가/리스크 오버레이 ON으로 실행 검증했다.

- 전략 총수익률: 약 +43.06%
- CAGR: 약 +12.69%
- MDD: 약 -15.51%
- 거래 수: 1015회
- 승률: 약 37.83%
- Profit Factor: 약 1.29

벤치마크 대비 해석:

- 동일가중 매수보유 벤치마크는 수익률이 훨씬 높았으나 MDD도 훨씬 컸다.
- 전략은 최근 강세장 수익률을 완전히 따라가지는 못했지만 낙폭은 크게 낮췄다.
- 따라서 현재 설정은 공격형 알파 전략이라기보다 방어형 스윙 포트폴리오에 가깝다.

## 실행

```powershell
python main.py backtest --strategies all
python main.py serve
```

웹에서 확인:

- `/backtest-report`
- `/backtest-explorer`
