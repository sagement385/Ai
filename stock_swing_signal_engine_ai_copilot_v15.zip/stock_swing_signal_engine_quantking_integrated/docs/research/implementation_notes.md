# Implementation Notes

1. This engine excludes themes/news/RL by design.
2. Papers are used as mathematical feature-design references, not as proof of profitability.
3. Institutional flow is only trusted when price remains in a sideways base and liquidity is sufficient.
4. Valuation is not a standalone signal. It is a secondary confirmation after price/supply structure.
5. Overheated stocks are not ranked highly even if momentum is strong.
6. The local web UI has only three actions: save API keys, download CSV, run analysis.
