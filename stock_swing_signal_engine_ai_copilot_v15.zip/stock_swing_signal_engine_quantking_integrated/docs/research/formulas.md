# Formulas

## Sideways
```text
range_width_60 = (high_60 - low_60) / close
range_width_120 = (high_120 - low_120) / close
ma_convergence = std(MA20, MA60, MA120) / close
box_position_120 = (close - low_120) / (high_120 - low_120)
```

## Support / Resistance
```text
price bins = linspace(120d low, 120d high, N)
cluster_strength = 0.55 * normalized_days + 0.45 * normalized_volume
support = strongest cluster below current close
support_distance = (close - support_level) / close
breakdown_failure_count = count(low < support*0.985 and close > support)
```

## Supply
```text
inst_buy_ratio_20 = sum(institution_net_buy_value, 20d) / sum(trading_value, 20d)
foreign_buy_ratio_20 = sum(foreign_net_buy_value, 20d) / sum(trading_value, 20d)
inst_persistence_20 = count(institution_net_buy_value > 0, 20d) / 20
```

## Quiet Accumulation
```text
quiet_accumulation = price_return_60 in [-12%, +18%]
                     and (inst_buy_ratio_20 + foreign_buy_ratio_20) > 0.5%
                     and OBV_MA20 > OBV_MA60
```

## Final Score
```text
final = 0.30*sideways + 0.20*support + 0.20*supply + 0.15*accumulation + 0.10*valuation + volatility_bonus - risk_penalty
```

Dependency caps:
```text
if sideways_score < 45: final <= 68
if support_score < 35: final <= 75
if risk_penalty >= 40: final <= 60
```

## Fibonacci / Angle Supplementary Features

피보나치와 빗각은 6순위 보조 확인으로만 사용한다.

### Fibonacci retracement zone

최근 120일 swing low `L`, swing high `H`를 기준으로 다음 level을 계산한다.

```text
level(r) = H - r × (H - L)
r ∈ {0.382, 0.500, 0.618, 0.786}
```

현재가가 가장 가까운 level에서 2.5% 이내일 때만 `fib_zone_score_raw`를 준다. 단독으로 최종 후보를 끌어올리지 않고, 횡보장과 지지·저항 조건이 일정 수준 이상일 때만 보조 가산한다.

### Diagonal trendline / angle support

최근 local lows에 선형회귀를 적용한다.

```text
low_line(t) = a_low × t + b_low
low_trend_slope_norm = a_low / close
low_trend_distance = (close - low_line(today)) / close
```

장기 스윙 관점에서는 저점선이 완만히 상승하거나 평탄하고, 현재가가 저점선에서 0~8% 위에 있을 때 보조 점수를 준다. 고점선이 평탄/하락하고 저점선이 유지되면 수렴형 압축으로 소폭 가산한다.
