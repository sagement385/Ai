# Paper Map

## 1. Return Distribution / Risk
- Mandelbrot, "The Variation of Certain Speculative Prices"
- Cont, "Empirical Properties of Asset Returns"
- Used in: `features/return_distribution_features.py`, `filters/sudden_spike_filter.py`, `filters/overheat_filter.py`, `scoring/risk_score.py`
- Implementation: log return, 20/60 day returns, volatility clustering, extreme days, kurtosis.
- Use type: risk penalty, not a buy signal.

## 2. Sideways / Trading Range
- Brock, Lakonishok & LeBaron, "Simple Technical Trading Rules and the Stochastic Properties of Stock Returns"
- Lo, Mamaysky & Wang, "Foundations of Technical Analysis"
- Used in: `features/sideways_features.py`, `scoring/sideways_score.py`
- Implementation: 60/120 day range width, moving-average convergence, box position, box persistence.

## 3. Support / Resistance
- De Angelis & Peskir, "Optimal Prediction of Resistance and Support Levels"
- Tengelin & Sopasakis, "Tick Based Clustering Methodologies Establishing Support and Resistance Levels"
- Used in: `features/support_resistance_features.py`, `scoring/support_resistance_score.py`
- Implementation: price-volume clusters, support distance, support strength, breakdown failure count.

## 4. Supply / Institutional Accumulation
- Lakonishok, Shleifer & Vishny, "The Impact of Institutional Trading on Stock Prices"
- Chordia, Roll & Subrahmanyam, "Order Imbalance, Liquidity, and Market Returns"
- Gabaix et al., "A Theory of Power-Law Distributions in Financial Market Fluctuations"
- Used in: `features/supply_features.py`, `features/accumulation_features.py`, `scoring/supply_score.py`, `scoring/accumulation_score.py`
- Implementation: institutional/foreign net-buy ratio over turnover, persistence, quiet accumulation.

## 5. Data Snooping / Validation
- Sullivan, Timmermann & White, "Data-Snooping, Technical Trading Rule Performance, and the Bootstrap"
- Used in: `validation/feature_validity_checker.py`, `validation/data_snooping_checker.py`, `backtest/walk_forward_tester.py`
- Implementation: future return table, feature IC, permutation check, walk-forward date split.

## Fibonacci / Angle Supplement

### Tsinaslanidis & Guijarro — Automatic Identification and Evaluation of Fibonacci Retracements
- Module: `features/fibonacci_angle_features.py`
- Use: 자동 swing high/low 기반 피보나치 되돌림 zone 계산
- Restriction: 단독 추천 신호가 아니라 지지·저항/횡보 구조와 겹칠 때만 보조 확인

### Lo, Mamaysky & Wang — Foundations of Technical Analysis
- Module: `features/fibonacci_angle_features.py`, `features/sideways_features.py`
- Use: local high/low 구조를 이용한 추세선·수렴 구조 계량화
- Restriction: 빗각 추세선은 거래량·수급·지지선 유지와 결합할 때만 의미 부여
