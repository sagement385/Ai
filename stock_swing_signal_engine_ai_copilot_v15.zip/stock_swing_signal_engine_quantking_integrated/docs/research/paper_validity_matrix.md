# Paper Validity Matrix

| Paper | Use as | Do not use as | Current-market risk | Validation |
|---|---|---|---|---|
| Mandelbrot | Extreme return risk concept | Buy signal | Low | Check extreme return frequency by Korean stock data |
| Cont | Stylized facts, volatility clustering | Direct prediction | Low-Medium | Rolling volatility and outlier tests |
| Brock et al. | Trading range and MA concepts | Modern profitability proof | High | Walk-forward test after 2020 |
| Lo et al. | Pattern extraction method | Pattern=profit guarantee | Medium | Out-of-sample pattern performance |
| De Angelis & Peskir | S/R as latent barrier | Standalone entry rule | Medium | Support reaction rate test |
| Tengelin & Sopasakis | Clustered S/R | Tick-perfect S/R on daily data | Medium | Compare daily-bin clusters vs future drawdown |
| LSV | Institutional flow concept | Institution buy always bullish | Medium | Supply signal by liquidity bucket |
| Chordia et al. | Imbalance/liquidity relation | Exact order-book model | Medium | Net-buy-to-turnover validation |
| Sullivan et al. | Data snooping warning | Signal creation | Low | Permutation and walk-forward |
