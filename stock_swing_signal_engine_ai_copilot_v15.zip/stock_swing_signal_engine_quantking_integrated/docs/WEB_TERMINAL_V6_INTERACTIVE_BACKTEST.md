# Web Terminal v6: Interactive Terminal + Backtest Audit

## 목표
v5의 링크형 UI를 보완해 웹에서 종목을 선택하면 같은 화면에서 즉시 차트, 진입가, 손절가, 목표가, 전략 근거, 백테스트 거래내역을 확인할 수 있게 만들었다.

## 핵심 변경

- `/terminal`을 인터랙티브 터미널로 교체
  - 왼쪽 후보 리스트에서 종목을 체크/클릭하면 오른쪽 패널이 즉시 갱신
  - 종목명/코드/전략 검색 가능
  - 캔들 차트에 현재 신호 기준 진입가, 손절가, 목표가, 피벗 표시
  - 백테스트 거래가 있는 종목은 차트에 과거 진입/청산 마커 표시

- JSON API 추가
  - `/api/terminal`: 후보 종목 표 데이터
  - `/api/stock?code=005930`: 개별 종목 차트/신호/거래내역/재무/수급 데이터
  - `/api/backtest-audit`: 백테스트 검증 요약

- `/backtest-explorer` 추가
  - 백테스트 평가 시작/종료일
  - 총 거래 수
  - 연도별 거래 수
  - 연도·전략별 신호 수
  - 통계 신뢰도 판단 문구

- 백테스트 감사 파일 추가
  - `reports/output/backtest_audit.csv`
  - 신호 수, 첫 신호일, 마지막 신호일, 첫 진입일, 마지막 진입일, 체결 규칙 기록

## 백테스트 방식 확인
백테스트는 현재 포트폴리오 후보만 단순 비교하는 방식이 아니라, 과거 전체 평가구간에서 매일 과거 신호를 생성한다.

기본 방식:

1. 과거 5년 가격 데이터로 이동평균, 고점/저점, ATR, 상대강도 등 지표 계산
2. 최근 3년 평가구간에서 매일 4개 전략의 과거 신호 생성
3. 신호일 종가 확정 후 다음 거래일 시가에 진입
4. 일봉 저가/고가로 손절/익절 체결 판단
5. 같은 날 손절과 익절이 모두 닿으면 손절 우선
6. 수수료, 거래세, 슬리피지 반영

## 성능 확인
업로드된 2712개 종목 5년치 `prices_daily.csv` 기준 테스트:

- 분석 대상 기본값: 최근 거래대금 상위 500개
- 분석 실행: 약 20~30초 구간
- 백테스트 실행: 약 27초
- 백테스트 평가 구간: 2023-05-30 ~ 2026-05-29
- 거래 수: 1015회

## 실행

```powershell
cd "D:\stock_swing_signal_engine_quantking_integrated"
.\.venv\Scripts\Activate.ps1
python main.py analyze --strategies all
python main.py backtest --strategies all
python main.py serve
```

브라우저:

```text
http://127.0.0.1:8765/terminal
```
