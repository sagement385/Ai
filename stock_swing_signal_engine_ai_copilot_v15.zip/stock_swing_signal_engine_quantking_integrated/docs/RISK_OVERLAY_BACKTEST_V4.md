# 리스크 오버레이 백테스트 v4 설명

## 설계 원칙
기존 4전략의 매수 후보 생성 알고리즘은 그대로 둔다. v4는 종목 선정 신호를 바꾸지 않고 다음 단계만 조정한다.

1. 신규 진입 허용 비중
2. 종목별 매수 수량
3. 보유 중 손절선 조정
4. 시장 약세 구간에서의 현금 비중
5. 동일 종목 반복 손절 방지

## 왜 이렇게 했나
기존 백테스트는 Profit Factor가 양호했지만 MDD가 컸다. 따라서 진입 조건을 바꾸기보다 포트폴리오 위험 노출을 낮추는 방향이 더 안전하다.

## 구현 파일
- `backtest/multi_strategy_backtester.py`
- `configs/backtest_config.json`
- `configs/backtest_config_no_overlay.json`

## 주요 설정
```json
"risk_overlay": {
  "enabled": true,
  "market_exposure_multiplier": {"risk_on": 1.0, "neutral": 0.8, "risk_off": 0.5},
  "use_risk_position_sizing": true,
  "risk_per_trade_pct_of_strategy_equity": {
    "vcp": 0.018,
    "canslim": 0.018,
    "stage2": 0.016,
    "darvas": 0.015
  },
  "trailing_stop_enabled": true,
  "atr_trailing_multiple": {
    "vcp": 2.5,
    "canslim": 3.0,
    "stage2": 3.5,
    "darvas": 2.5
  }
}
```

## 시장 프록시
KOSPI/KOSDAQ 지수 CSV가 없어도 작동하도록, 백테스트 대상 종목들의 일별 수익률 중앙값으로 equal-weight 시장 프록시를 만든다. 이 프록시는 종목 점수에는 쓰지 않고 신규진입 비중 제한에만 사용한다.

## 백테스트 비교
리스크 오버레이를 끄고 비교하려면:

```powershell
python main.py backtest --config configs/backtest_config_no_overlay.json
```

기본 리스크 오버레이 버전:

```powershell
python main.py backtest
```

## 산출물
- `reports/output/backtest_report.html`
- `reports/output/backtest_equity_curve.csv`
- `reports/output/backtest_trades.csv`
- `reports/output/backtest_summary.csv`
- `reports/output/backtest_strategy_summary.csv`
- `reports/output/backtest_market_regime.csv`
```
