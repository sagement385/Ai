# Web Terminal v5

이 버전은 기존 CLI 중심 워크플로우를 웹 UI 중심으로 바꾼 버전입니다. 셸은 서버를 시작할 때만 사용하고, 이후 데이터 수집, 전략 선택 분석, 백테스트 설정, 리포트 확인은 웹에서 조작합니다.

## 실행

```powershell
cd "D:\stock_swing_signal_engine_quantking_integrated"
.\.venv\Scripts\Activate.ps1
python main.py serve
```

브라우저에서 `http://127.0.0.1:8765` 접속.

## 주요 기능

### 1. 데이터 상태
홈 화면에서 가격, 종목목록, 재무, 수급, 주봉, 전략 후보, 백테스트 파일의 존재 여부와 크기, 수정시간을 확인합니다.

### 2. yfinance 가격 CSV 수집
웹에서 다음 값을 직접 조정합니다.

- 수집 기간: 1년, 3년, 5년, 10년
- 테스트 종목 수 제한: 비우면 전체, 테스트는 20 또는 100 추천
- 배치 크기: 한 번에 요청할 종목 수
- 요청 간격: 네트워크 불안정 시 1.0~1.5초 권장
- KRX 종목목록 재생성 여부

### 3. 4전략 체크 분석
VCP, CANSLIM, Stage2, Darvas 중 원하는 전략만 체크해서 분석합니다. 선택된 전략 비중은 자동으로 100%로 재분배됩니다.

### 4. 웹 백테스트 설정
웹에서 아래 값을 직접 입력합니다.

- 초기자금
- 평가기간(년)
- 백테스트 종목 수
- 최소 거래대금
- 매수/매도 수수료
- 매도 거래세
- 슬리피지
- 전체 최대 보유종목 수
- 손절 후 재진입 제한일
- 리스크 오버레이 사용 여부
- 위험장 신규진입 차단 여부

입력값은 `reports/output/web_backtest_config.json`에 저장되어 해당 백테스트에 사용됩니다.

### 5. 종목 상세 화면
전략 터미널에서 종목명을 클릭하면 `/stock?code=종목코드` 상세 화면으로 이동합니다.

- 캔들 차트
- 거래량 바
- MA20 / MA60 / MA200
- 진입가: 초록선
- 손절가: 빨간선
- 목표가: 보라선
- 피벗: 주황선
- 전략별 점수와 근거
- 재무/수급 요약

### 6. 백그라운드 작업
DART, 수급, yfinance 같은 긴 작업은 웹 요청 뒤 로컬 백그라운드 스레드로 실행됩니다. 단, `python main.py serve`를 실행한 터미널을 닫으면 작업도 종료됩니다.

## 검증

개발 중 샘플 가격 CSV로 다음을 확인했습니다.

```powershell
python main.py build-derived
python main.py analyze --strategies vcp,stage2
python main.py backtest --strategies vcp,stage2
```

세 명령 모두 정상 완료되었습니다.
