# UI 체크박스 전략 분석 + Bloomberg식 터미널 + 실전형 백테스트

## 핵심 변경

- UI에서 4개 알고리즘을 체크박스로 선택해서 분석 가능
  - VCP
  - CANSLIM
  - Weinstein Stage2
  - Darvas Box
- 선택한 전략만 사용하면 기존 20/30/40/10 비중을 선택 전략 안에서 100%로 재정규화
- `전략 터미널(/terminal)` 추가
  - 전략 후보 종목 표
  - 종목명 클릭 시 `/stock?code=종목코드` 상세 화면
- 종목 상세 화면 추가
  - 가격 차트
  - MA20/MA60/MA200
  - 진입가/손절가/목표가/피벗 라인
  - 전략별 점수/신호/근거
  - 재무/수급 CSV 요약
- 백테스트 개선
  - 기본 최근 3년 평가
  - 과거 전체 5년 데이터는 지표 계산 warm-up에 사용
  - 신호일 종가 확정 후 다음 거래일 시가 진입
  - 수수료, 거래세, 슬리피지 반영
  - 같은 날 손절/익절 동시 도달 시 손절 우선
  - 기본 최근 거래대금 상위 500개만 테스트

## 왜 백테스트 기본값이 상위 500개인가?

업로드된 가격 CSV는 약 2712종목, 약 301만 행이었다. 전체 종목을 그대로 백테스트하면 저유동성 종목이 성과를 왜곡하고 연산도 무거워진다.
따라서 기본값은 최근 80개 거래일 median trading_value 상위 500개다.

설정 파일:

```json
configs/backtest_config.json
```

```json
"max_backtest_symbols": 500,
"liquidity_lookback_rows": 80
```

전체 종목을 강제로 테스트하려면 `max_backtest_symbols`를 0으로 바꾸면 된다. 다만 시간이 오래 걸릴 수 있다.

## 실행

```powershell
cd "D:\stock_swing_signal_engine_quantking_integrated"
.\.venv\Scripts\Activate.ps1

python main.py analyze
python main.py backtest
python main.py serve
```

전략 일부만 실행:

```powershell
python main.py analyze --strategies vcp,stage2
python main.py backtest --strategies vcp,stage2
```

UI:

```text
http://127.0.0.1:8765
```

## 주요 결과 파일

```text
reports/output/multi_strategy_portfolio.html
reports/output/multi_strategy_portfolio.csv
reports/output/multi_strategy_signals_all.csv
reports/output/backtest_report.html
reports/output/backtest_summary.csv
reports/output/backtest_trades.csv
reports/output/backtest_equity_curve.csv
```

## 검증 결과

실제 업로드된 `prices_daily.csv` 기준으로 백테스트가 정상 완료되는지 확인했다.

조건:

- 5년 가격 CSV 약 301만 행
- 전체 2712종목 중 최근 거래대금 상위 500개 사용
- 최근 3년 평가
- 4전략 전체 사용
- 수수료/세금/슬리피지 반영

기능 검증 결과:

- `backtest_summary.csv` 생성 성공
- `backtest_trades.csv` 생성 성공
- `backtest_equity_curve.csv` 생성 성공
- `backtest_report.html` 생성 성공

샘플 실행에서 거래 996건, 승률 약 40.96%, MDD 약 -32.78%가 계산됐다. 이 수치는 투자 성과 보장이 아니라, 백테스트 엔진이 실제 CSV로 끝까지 계산되는지 확인한 기능 검증값이다.
