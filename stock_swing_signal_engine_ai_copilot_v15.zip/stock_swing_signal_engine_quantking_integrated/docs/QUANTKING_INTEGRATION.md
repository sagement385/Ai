# QuantKingSetup 분석 및 통합 내용

## 1. 업로드 파일에서 확인한 점

`QuantKingSetup(1).zip`은 파이썬 소스가 아니라 Windows 설치 패키지입니다.
내부에는 다음 요소가 있었습니다.

- `QuantKing.exe`, `program.msi`
- `KHOpenAPI.ocx`, `Interop.KHOpenAPILib.dll`, `AxInterop.KHOpenAPILib.dll`
- `System.Data.SQLite.dll`, `SQLite.Interop.dll`
- `Newtonsoft.Json.dll`, Azure Storage 관련 DLL
- exe 문자열상 `axKHOpenAPI1`, Kiwoom OpenAPI 설치 URL, CSV 저장, SQLite 쿼리, 백테스트/MDD/월별 성과, PER/PBR/ROE류 화면 요소 확인

즉 QuantKing은 **Kiwoom OpenAPI + 로컬 SQLite DB + CSV/엑셀 + 백테스트 UI** 구조에 가깝습니다.
소스코드는 포함되어 있지 않아 실행파일 내부 로직을 그대로 가져오지는 않았습니다.
대신 stock_swing_signal_engine에 필요한 형태로 아래 브리지를 새로 작성했습니다.

## 2. 이번에 추가한 파일

### `data_sources/kiwoom_openapi.py`

Windows에서 Kiwoom OpenAPI+ COM을 직접 호출해 CSV를 만드는 선택형 모듈입니다.

- 가격 일봉: `opt10081`
- 투자자 수급: `opt10059`
- 출력 형식은 기존 엔진의 `prices_daily.csv`, `supply_daily.csv`와 맞춤
- Windows + Kiwoom OpenAPI+ + `pywin32` 필요

실행 예시:

```bash
pip install pywin32
python main.py download --source kiwoom --days 250 --limit 20
```

### `data_sources/quantking_sqlite_importer.py`

QuantKing이 만든 것으로 보이는 SQLite DB를 발견했을 때, 기존 엔진 CSV로 변환하는 모듈입니다.
업로드 zip에는 DB가 없었으므로 DB 파일은 사용자가 PC에서 직접 찾아야 합니다.

먼저 DB 테이블 확인:

```bash
python main.py inspect-quantking-db --db "C:/path/to/quantking.db"
```

변환:

```bash
python main.py import-quantking-db --db "C:/path/to/quantking.db" --output-dir data/csv_import
```

컬럼이 맞지 않으면 `configs/quantking_column_map.example.json`을 복사해서 c번호를 수정한 뒤:

```bash
python main.py import-quantking-db --db "C:/path/to/quantking.db" --column-map configs/my_quantking_map.json
```

### `backtest/quantking_metrics.py`

QuantKing에서 확인되는 백테스트 관점인 MDD, 월별/연도별 성과, profit factor, win rate를 별도 모듈로 추가했습니다.

## 3. QuantKing에서 가져올 수 있는 데이터 요구사항

현재 엔진에 가장 필요한 데이터는 아래 순서입니다.

1. **일봉 OHLCV**: `stock_code, stock_name, date, open, high, low, close, volume, trading_value`
2. **투자자 수급**: `institution_net_buy_value, foreign_net_buy_value, pension_net_buy_value, individual_net_buy_value`
3. **재무/밸류**: `PER, PBR, ROE, debt_ratio, operating_profit, net_income, market_cap`
4. **백테스트 검증용 결과**: 날짜별 수익률, 월별 수익률, MDD
5. **종목 유니버스**: 관심종목/시장구분/섹터

QuantKing zip 자체에는 이 데이터 CSV/DB가 들어있지 않았습니다. 실제 데이터는 QuantKing 실행 후 사용자 PC 어딘가의 DB나 CSV로 저장되어 있을 가능성이 큽니다.

## 4. 주의

- `KHOpenAPI.ocx` 같은 DLL/OCX는 저작권·설치환경 문제가 있어 새 프로젝트 zip에는 복사하지 않았습니다.
- Kiwoom OpenAPI는 Windows/로그인/요청제한이 강하게 묶여 있어 서버나 Colab에서는 실행되지 않습니다.
- `quantking_sqlite_importer`의 기본 c컬럼 매핑은 추정입니다. 변환 후 삼성전자 같은 대형주 1~2개로 실제 일봉과 맞는지 검증하세요.
