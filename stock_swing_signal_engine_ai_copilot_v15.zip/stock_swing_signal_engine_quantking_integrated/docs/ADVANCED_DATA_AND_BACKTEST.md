# 고급 데이터 수집 + 4전략 백테스트 사용법

## 1. 파생 데이터 생성

현재 `prices_daily.csv`만 있으면 주봉 30주선과 섹터 강도는 바로 생성됩니다.

```powershell
python main.py build-derived
```

생성 파일:

```text
data/csv_import/prices_weekly.csv
data/csv_import/sector_strength.csv
```

`sector_map.csv`가 있으면 섹터 기준으로 계산하고, 없으면 market 단위로 계산합니다.

---

## 2. DART 분기 재무 데이터 수집

`.env`에 DART 키를 저장합니다.

```text
DART_API_KEY=여기에_키
```

전체 종목 5년치를 3분할로 나누어 수집합니다.

```powershell
python main.py download-dart --years 5 --parts 3 --part 1
python main.py download-dart --years 5 --parts 3 --part 2
python main.py download-dart --years 5 --parts 3 --part 3
```

생성 파일:

```text
data/csv_import/financial_quarterly.csv
data/csv_import/financials.csv
data/csv_import/dart_parts/financial_quarterly_part1_of_3.csv
```

`financials.csv`는 최신 분기 요약이고, CANSLIM 점수에 매출/영업이익/순이익/EPS YoY를 반영합니다.

---

## 3. 기관/외국인 수급 분할 수집

pykrx 기반입니다. 전체 5년치는 느릴 수 있으니 분할 실행을 권장합니다.

```powershell
python main.py download-supply-part --days 1250 --parts 3 --part 1
python main.py download-supply-part --days 1250 --parts 3 --part 2
python main.py download-supply-part --days 1250 --parts 3 --part 3
```

생성 파일:

```text
data/csv_import/supply_daily.csv
data/csv_import/supply_parts/supply_daily_part1_of_3.csv
```

---

## 4. 분석 실행

```powershell
python main.py analyze
```

고급 데이터가 있으면 자동 반영됩니다.

- CANSLIM: `financials.csv`의 매출/영업이익/순이익/EPS YoY 반영
- Stage2: `prices_weekly.csv`의 주봉 30주선/기울기 반영
- 기존 점수: `supply_daily.csv`가 있으면 기관/외국인 수급 점수 반영

---

## 5. 백테스트 실행

```powershell
python main.py backtest
```

생성 파일:

```text
reports/output/backtest_report.html
reports/output/backtest_equity_curve.csv
reports/output/backtest_trades.csv
reports/output/backtest_summary.csv
reports/output/backtest_strategy_summary.csv
reports/output/backtest_signals.csv
```

백테스트 체결 규칙:

- 신호 발생: 당일 종가 기준 돌파 확정
- 실제 진입: 다음 거래일 시가
- 손절/익절: 일봉 저가/고가로 체결 판단
- 같은 날 손절과 익절이 모두 닿으면 손절 우선
- 수수료, 거래세, 슬리피지 반영

설정 파일:

```text
configs/backtest_config.json
```

---

## 6. UI 실행

```powershell
python main.py serve
```

브라우저:

```text
http://127.0.0.1:8765
```

UI에서 할 수 있는 것:

- DART API 키 저장
- DART 분할 수집 시작
- 기관/외국인 수급 분할 수집 시작
- 주봉/섹터 파생 데이터 생성
- 분석 실행
- 백테스트 실행
- 차트 대시보드 확인

주의: UI의 DART/수급 수집은 로컬 프로세스의 백그라운드 스레드로 실행됩니다. 터미널 창을 닫으면 작업도 종료됩니다.
