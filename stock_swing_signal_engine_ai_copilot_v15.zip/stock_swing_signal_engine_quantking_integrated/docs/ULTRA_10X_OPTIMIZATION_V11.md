# Ultra Aggressive 10x v11

## 목적
기존 4개 알고리즘과 Deep Turnaround를 갈아엎지 않고, 고위험·고수익 집중형 백테스트 프로필을 추가한다.

## 핵심 원칙
- 수익률이 나올 때까지 같은 테스트 구간을 반복 튜닝하지 않는다.
- train / validation / test를 시간순으로 분리한다.
- 후보 프로필은 validation 점수로 선택한다.
- test 구간은 선택 후 1회만 확인한다.
- full-period 결과는 참고용이며 선택에 쓰면 과최적화다.

## 추가 명령
```powershell
python main.py optimize-ultra10x
```

빠른 테스트:
```powershell
python main.py optimize-ultra10x --max-candidates 3
```

## 결과 파일
- `reports/output/ultra10x_optimization_report.csv`
- `reports/output/ultra10x_optimization_report_partial.csv`
- `reports/output/ultra10x_selected_config.json`
- `reports/output/ultra10x_selected_oos_summary.csv`
- `reports/output/ultra10x_test_backtest_report.html`
- `reports/output/ultra10x_full_backtest_report.html`

## 기본 후보군
- VCP 중심 집중형
- VCP/CANSLIM 집중형
- VCP + Deep Turnaround 옵션형
- 더 넓은 추가투입형
- Risk-on 공격형
- VCP 단독 집중형

## 주의
이 프로필은 연 50~400% 같은 고수익 목표를 탐색하기 위한 실험 프로필이다. 실전 안정형이 아니다. 총수익률보다 총투입원금 기준 수익률과 OOS 테스트 결과를 우선 확인해야 한다.
