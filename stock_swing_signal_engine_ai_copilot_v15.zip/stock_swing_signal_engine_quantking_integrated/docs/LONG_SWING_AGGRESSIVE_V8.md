# Long Swing Aggressive v8

목표: 기존 4개 알고리즘의 종목 선정/진입 신호는 유지하고, 백테스트 청산·보유·포지션 사이징만 장기 스윙형으로 바꾼다.

## 핵심 원칙

- 진입 신호: VCP, CANSLIM, Stage2, Darvas 기존 규칙 유지
- 진입 체결: 신호일 종가 확정 후 다음 거래일 시가
- 목표가: 2~3배 가격 배수 목표
- 손절: 기존보다 넓게, 전략별 12~18%
- 보유기간: 220~504 거래일 수준
- 트레일링 스탑: 초기 수익 구간에서는 너무 빨리 잘리지 않게 늦게 활성화
- 리스크: 종목 수는 줄이고, 종목당 위험 허용치는 높임

## 실행

```powershell
python main.py backtest --config configs/backtest_config_long_swing_aggressive.json --strategies all
```

웹 UI에서는 백테스트 프로필에서 `장기 스윙 2~3배 목표`를 선택하면 동일한 설정이 적용된다.
