# yfinance 국내 전체 주식 1년 데이터 다운로드

이 프로젝트의 기본 가격 데이터는 `data/csv_import/prices_daily.csv`입니다.  
국내 전체 주식의 최근 1년 일봉은 아래 노트북으로 생성할 수 있습니다.

```bash
jupyter notebook notebooks/download_krx_yfinance_1y.ipynb
```

또는 터미널에서 바로 실행할 수도 있습니다.

```bash
python main.py download --source yfinance --days 250 --skip-supply --skip-financials
```

## 생성 파일

- `data/csv_import/universe.csv`
- `data/csv_import/prices_daily.csv`
- `data/csv_import/yfinance_download_failures.csv`

## 데이터 흐름

1. `pykrx`로 KOSPI/KOSDAQ 전체 종목 목록을 생성합니다.
2. 종목코드를 Yahoo Finance 티커로 변환합니다.
   - KOSPI: `005930` → `005930.KS`
   - KOSDAQ: `035720` → `035720.KQ`
3. `yfinance`에서 최근 1년 일봉을 다운로드합니다.
4. 엔진 표준 컬럼으로 변환합니다.

```text
stock_code, stock_name, date, open, high, low, close, volume, trading_value
```

## 주의사항

- yfinance/Yahoo Finance는 일부 국내 종목을 제공하지 않을 수 있습니다.
- 거래대금은 Yahoo에서 직접 제공하지 않으므로 `close * volume`으로 추정합니다.
- 최근 상장주, 거래정지 종목, 일부 우선주/스팩은 누락될 수 있습니다.
- 실패 종목은 `yfinance_download_failures.csv`에서 확인할 수 있습니다.

## 추천 사용법

처음에는 노트북에서 아래처럼 테스트합니다.

```python
LIMIT = 20
```

정상적으로 CSV가 생성되면 전체 다운로드로 바꿉니다.

```python
LIMIT = None
```

다운로드 후 분석은 아래 명령으로 실행합니다.

```bash
python main.py analyze
```
